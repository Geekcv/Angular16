import MySQLdb
import psycopg2

# Connect to MySQL
mysql_conn = MySQLdb.connect(host="localhost", user="root", passwd="root", db="shtecaoh_jain_board")
mysql_cursor = mysql_conn.cursor()

# Connect to PostgreSQL
pg_conn = psycopg2.connect("dbname=shtecaoh_jain_board user=postgres password=Admin")
pg_cursor = pg_conn.cursor()

# Fetch data from MySQL
mysql_cursor.execute("SELECT * FROM branch")
rows = mysql_cursor.fetchall()

# Insert data into PostgreSQL
for row in rows:
    pg_cursor.execute("INSERT INTO branch (column1, column2) VALUES (%s, %s)", row)

# Commit changes
pg_conn.commit()

# Close connections
mysql_cursor.close()
pg_cursor.close()
mysql_conn.close()
pg_conn.close()

print("Data migration complete!")
