--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8
-- Dumped by pg_dump version 16.8

-- Started on 2025-05-09 17:34:22

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS shikshanboard;
--
-- TOC entry 5066 (class 1262 OID 45959)
-- Name: shikshanboard; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE shikshanboard WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_India.1252';


ALTER DATABASE shikshanboard OWNER TO postgres;

\connect shikshanboard

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 6 (class 2615 OID 45960)
-- Name: shikshanboard; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA shikshanboard;


ALTER SCHEMA shikshanboard OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 221 (class 1259 OID 46128)
-- Name: attendance; Type: TABLE; Schema: shikshanboard; Owner: postgres
--

CREATE TABLE shikshanboard.attendance (
    id integer NOT NULL,
    row_id text NOT NULL,
    student_row_id text,
    exam_session text,
    class text,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    status integer,
    center_code text,
    faculty integer,
    remarks text
);


ALTER TABLE shikshanboard.attendance OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 46127)
-- Name: attendance_id_seq; Type: SEQUENCE; Schema: shikshanboard; Owner: postgres
--

CREATE SEQUENCE shikshanboard.attendance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE shikshanboard.attendance_id_seq OWNER TO postgres;

--
-- TOC entry 5067 (class 0 OID 0)
-- Dependencies: 220
-- Name: attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: shikshanboard; Owner: postgres
--

ALTER SEQUENCE shikshanboard.attendance_id_seq OWNED BY shikshanboard.attendance.id;


--
-- TOC entry 239 (class 1259 OID 46321)
-- Name: bandals; Type: TABLE; Schema: shikshanboard; Owner: postgres
--

CREATE TABLE shikshanboard.bandals (
    id integer NOT NULL,
    row_id text NOT NULL,
    bandal_no integer NOT NULL,
    exam_session text,
    class text,
    copy_checker_id text,
    student_row_id text,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    faculty integer
);


ALTER TABLE shikshanboard.bandals OWNER TO postgres;

--
-- TOC entry 238 (class 1259 OID 46320)
-- Name: bandals_id_seq; Type: SEQUENCE; Schema: shikshanboard; Owner: postgres
--

CREATE SEQUENCE shikshanboard.bandals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE shikshanboard.bandals_id_seq OWNER TO postgres;

--
-- TOC entry 5068 (class 0 OID 0)
-- Dependencies: 238
-- Name: bandals_id_seq; Type: SEQUENCE OWNED BY; Schema: shikshanboard; Owner: postgres
--

ALTER SEQUENCE shikshanboard.bandals_id_seq OWNED BY shikshanboard.bandals.id;


--
-- TOC entry 235 (class 1259 OID 46273)
-- Name: branch; Type: TABLE; Schema: shikshanboard; Owner: postgres
--

CREATE TABLE shikshanboard.branch (
    id integer NOT NULL,
    row_id text NOT NULL,
    branch_name text,
    branch_head_name text,
    address text,
    city integer,
    mobile_no text,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE shikshanboard.branch OWNER TO postgres;

--
-- TOC entry 234 (class 1259 OID 46272)
-- Name: branch_id_seq; Type: SEQUENCE; Schema: shikshanboard; Owner: postgres
--

CREATE SEQUENCE shikshanboard.branch_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE shikshanboard.branch_id_seq OWNER TO postgres;

--
-- TOC entry 5069 (class 0 OID 0)
-- Dependencies: 234
-- Name: branch_id_seq; Type: SEQUENCE OWNED BY; Schema: shikshanboard; Owner: postgres
--

ALTER SEQUENCE shikshanboard.branch_id_seq OWNED BY shikshanboard.branch.id;


--
-- TOC entry 237 (class 1259 OID 46284)
-- Name: centers; Type: TABLE; Schema: shikshanboard; Owner: postgres
--

CREATE TABLE shikshanboard.centers (
    id integer NOT NULL,
    row_id text NOT NULL,
    branch_id text,
    center text NOT NULL,
    center_head_name text,
    email text,
    address text,
    date_of_birth date,
    state integer,
    city integer,
    std_code text,
    phone_no text,
    mobile_no text,
    account_no text,
    account_name text,
    bank_name text,
    branch_name text,
    ifsc_code text,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    center_code integer,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE shikshanboard.centers OWNER TO postgres;

--
-- TOC entry 236 (class 1259 OID 46283)
-- Name: centers_id_seq; Type: SEQUENCE; Schema: shikshanboard; Owner: postgres
--

CREATE SEQUENCE shikshanboard.centers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE shikshanboard.centers_id_seq OWNER TO postgres;

--
-- TOC entry 5070 (class 0 OID 0)
-- Dependencies: 236
-- Name: centers_id_seq; Type: SEQUENCE OWNED BY; Schema: shikshanboard; Owner: postgres
--

ALTER SEQUENCE shikshanboard.centers_id_seq OWNED BY shikshanboard.centers.id;


--
-- TOC entry 233 (class 1259 OID 46262)
-- Name: classes; Type: TABLE; Schema: shikshanboard; Owner: postgres
--

CREATE TABLE shikshanboard.classes (
    id integer NOT NULL,
    row_id text NOT NULL,
    faculty integer,
    class_name text NOT NULL,
    first_price real,
    second_price real,
    third_price real,
    merit_list_upto_10_price real,
    marks_greater_equal_to_90 real,
    marks_70_to_less_then_90 real,
    marks_50_to_less_then_70 real,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE shikshanboard.classes OWNER TO postgres;

--
-- TOC entry 232 (class 1259 OID 46261)
-- Name: classes_id_seq; Type: SEQUENCE; Schema: shikshanboard; Owner: postgres
--

CREATE SEQUENCE shikshanboard.classes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE shikshanboard.classes_id_seq OWNER TO postgres;

--
-- TOC entry 5071 (class 0 OID 0)
-- Dependencies: 232
-- Name: classes_id_seq; Type: SEQUENCE OWNED BY; Schema: shikshanboard; Owner: postgres
--

ALTER SEQUENCE shikshanboard.classes_id_seq OWNED BY shikshanboard.classes.id;


--
-- TOC entry 223 (class 1259 OID 46144)
-- Name: copy_checkers; Type: TABLE; Schema: shikshanboard; Owner: postgres
--

CREATE TABLE shikshanboard.copy_checkers (
    id integer NOT NULL,
    row_id text NOT NULL,
    name text,
    address text,
    mobile text,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    account_no text,
    account_name text,
    bank_name text,
    branch_name text,
    ifsc_code text
);


ALTER TABLE shikshanboard.copy_checkers OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 46143)
-- Name: copy_checkers_id_seq; Type: SEQUENCE; Schema: shikshanboard; Owner: postgres
--

CREATE SEQUENCE shikshanboard.copy_checkers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE shikshanboard.copy_checkers_id_seq OWNER TO postgres;

--
-- TOC entry 5072 (class 0 OID 0)
-- Dependencies: 222
-- Name: copy_checkers_id_seq; Type: SEQUENCE OWNED BY; Schema: shikshanboard; Owner: postgres
--

ALTER SEQUENCE shikshanboard.copy_checkers_id_seq OWNED BY shikshanboard.copy_checkers.id;


--
-- TOC entry 247 (class 1259 OID 46610)
-- Name: event; Type: TABLE; Schema: shikshanboard; Owner: postgres
--

CREATE TABLE shikshanboard.event (
    id integer NOT NULL,
    row_id text NOT NULL,
    event_name text,
    event_date date,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE shikshanboard.event OWNER TO postgres;

--
-- TOC entry 246 (class 1259 OID 46609)
-- Name: event_id_seq; Type: SEQUENCE; Schema: shikshanboard; Owner: postgres
--

CREATE SEQUENCE shikshanboard.event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE shikshanboard.event_id_seq OWNER TO postgres;

--
-- TOC entry 5073 (class 0 OID 0)
-- Dependencies: 246
-- Name: event_id_seq; Type: SEQUENCE OWNED BY; Schema: shikshanboard; Owner: postgres
--

ALTER SEQUENCE shikshanboard.event_id_seq OWNED BY shikshanboard.event.id;


--
-- TOC entry 231 (class 1259 OID 46238)
-- Name: exam_sessions; Type: TABLE; Schema: shikshanboard; Owner: postgres
--

CREATE TABLE shikshanboard.exam_sessions (
    id integer NOT NULL,
    row_id text NOT NULL,
    session_name text,
    exam_date date,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE shikshanboard.exam_sessions OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 46237)
-- Name: exam_sessions_id_seq; Type: SEQUENCE; Schema: shikshanboard; Owner: postgres
--

CREATE SEQUENCE shikshanboard.exam_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE shikshanboard.exam_sessions_id_seq OWNER TO postgres;

--
-- TOC entry 5074 (class 0 OID 0)
-- Dependencies: 230
-- Name: exam_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: shikshanboard; Owner: postgres
--

ALTER SEQUENCE shikshanboard.exam_sessions_id_seq OWNED BY shikshanboard.exam_sessions.id;


--
-- TOC entry 225 (class 1259 OID 46171)
-- Name: marks; Type: TABLE; Schema: shikshanboard; Owner: postgres
--

CREATE TABLE shikshanboard.marks (
    id integer NOT NULL,
    row_id text NOT NULL,
    student_row_id text,
    exam_session text,
    copy_checker_id text,
    marks integer,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    faculty integer,
    class_id text
);


ALTER TABLE shikshanboard.marks OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 46170)
-- Name: marks_id_seq; Type: SEQUENCE; Schema: shikshanboard; Owner: postgres
--

CREATE SEQUENCE shikshanboard.marks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE shikshanboard.marks_id_seq OWNER TO postgres;

--
-- TOC entry 5075 (class 0 OID 0)
-- Dependencies: 224
-- Name: marks_id_seq; Type: SEQUENCE OWNED BY; Schema: shikshanboard; Owner: postgres
--

ALTER SEQUENCE shikshanboard.marks_id_seq OWNED BY shikshanboard.marks.id;


--
-- TOC entry 227 (class 1259 OID 46192)
-- Name: merit_list; Type: TABLE; Schema: shikshanboard; Owner: postgres
--

CREATE TABLE shikshanboard.merit_list (
    id integer NOT NULL,
    row_id text NOT NULL,
    student_row_id text,
    marks integer,
    rank integer,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE shikshanboard.merit_list OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 46191)
-- Name: merit_list_id_seq; Type: SEQUENCE; Schema: shikshanboard; Owner: postgres
--

CREATE SEQUENCE shikshanboard.merit_list_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE shikshanboard.merit_list_id_seq OWNER TO postgres;

--
-- TOC entry 5076 (class 0 OID 0)
-- Dependencies: 226
-- Name: merit_list_id_seq; Type: SEQUENCE OWNED BY; Schema: shikshanboard; Owner: postgres
--

ALTER SEQUENCE shikshanboard.merit_list_id_seq OWNED BY shikshanboard.merit_list.id;


--
-- TOC entry 229 (class 1259 OID 46208)
-- Name: online_forms; Type: TABLE; Schema: shikshanboard; Owner: postgres
--

CREATE TABLE shikshanboard.online_forms (
    id integer NOT NULL,
    row_id text NOT NULL,
    student_row_id text,
    form_name text,
    form_data jsonb,
    status text,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE shikshanboard.online_forms OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 46207)
-- Name: online_forms_id_seq; Type: SEQUENCE; Schema: shikshanboard; Owner: postgres
--

CREATE SEQUENCE shikshanboard.online_forms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE shikshanboard.online_forms_id_seq OWNER TO postgres;

--
-- TOC entry 5077 (class 0 OID 0)
-- Dependencies: 228
-- Name: online_forms_id_seq; Type: SEQUENCE OWNED BY; Schema: shikshanboard; Owner: postgres
--

ALTER SEQUENCE shikshanboard.online_forms_id_seq OWNED BY shikshanboard.online_forms.id;


--
-- TOC entry 240 (class 1259 OID 46343)
-- Name: samplebook; Type: TABLE; Schema: shikshanboard; Owner: postgres
--

CREATE TABLE shikshanboard.samplebook (
    id integer NOT NULL,
    row_id text NOT NULL,
    title text,
    photo_path text,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE shikshanboard.samplebook OWNER TO postgres;

--
-- TOC entry 241 (class 1259 OID 46352)
-- Name: samplebook_id_seq; Type: SEQUENCE; Schema: shikshanboard; Owner: postgres
--

CREATE SEQUENCE shikshanboard.samplebook_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE shikshanboard.samplebook_id_seq OWNER TO postgres;

--
-- TOC entry 5078 (class 0 OID 0)
-- Dependencies: 241
-- Name: samplebook_id_seq; Type: SEQUENCE OWNED BY; Schema: shikshanboard; Owner: postgres
--

ALTER SEQUENCE shikshanboard.samplebook_id_seq OWNED BY shikshanboard.samplebook.id;


--
-- TOC entry 242 (class 1259 OID 46353)
-- Name: samplepaper; Type: TABLE; Schema: shikshanboard; Owner: postgres
--

CREATE TABLE shikshanboard.samplepaper (
    id integer NOT NULL,
    row_id text NOT NULL,
    class_id text,
    title text,
    photo_path text,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE shikshanboard.samplepaper OWNER TO postgres;

--
-- TOC entry 243 (class 1259 OID 46362)
-- Name: samplepaper_id_seq; Type: SEQUENCE; Schema: shikshanboard; Owner: postgres
--

CREATE SEQUENCE shikshanboard.samplepaper_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE shikshanboard.samplepaper_id_seq OWNER TO postgres;

--
-- TOC entry 5079 (class 0 OID 0)
-- Dependencies: 243
-- Name: samplepaper_id_seq; Type: SEQUENCE OWNED BY; Schema: shikshanboard; Owner: postgres
--

ALTER SEQUENCE shikshanboard.samplepaper_id_seq OWNED BY shikshanboard.samplepaper.id;


--
-- TOC entry 249 (class 1259 OID 46636)
-- Name: student_exam_mappings; Type: TABLE; Schema: shikshanboard; Owner: postgres
--

CREATE TABLE shikshanboard.student_exam_mappings (
    id integer NOT NULL,
    row_id text NOT NULL,
    student_row_id text NOT NULL,
    exam_session text NOT NULL,
    class_id text NOT NULL,
    center text NOT NULL,
    faculty text,
    roll_no integer,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE shikshanboard.student_exam_mappings OWNER TO postgres;

--
-- TOC entry 248 (class 1259 OID 46635)
-- Name: student_exam_mappings_id_seq; Type: SEQUENCE; Schema: shikshanboard; Owner: postgres
--

CREATE SEQUENCE shikshanboard.student_exam_mappings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE shikshanboard.student_exam_mappings_id_seq OWNER TO postgres;

--
-- TOC entry 5080 (class 0 OID 0)
-- Dependencies: 248
-- Name: student_exam_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: shikshanboard; Owner: postgres
--

ALTER SEQUENCE shikshanboard.student_exam_mappings_id_seq OWNED BY shikshanboard.student_exam_mappings.id;


--
-- TOC entry 219 (class 1259 OID 46117)
-- Name: students; Type: TABLE; Schema: shikshanboard; Owner: postgres
--

CREATE TABLE shikshanboard.students (
    id integer NOT NULL,
    row_id text NOT NULL,
    student_name text NOT NULL,
    father_name text NOT NULL,
    dob date,
    mobile_no text,
    address text,
    zip_code text,
    ahhar_no text,
    phone_r text,
    phone_o text,
    medium text,
    education text,
    account_no text,
    account_name text,
    bank_name text,
    branch_name text,
    ifsc_code text,
    remarks text,
    cr_on date DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    gender text,
    state integer,
    city integer,
    exam_sessions text,
    class_id text,
    roll_no integer,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    center text,
    faculty integer
);


ALTER TABLE shikshanboard.students OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 46116)
-- Name: students_id_seq; Type: SEQUENCE; Schema: shikshanboard; Owner: postgres
--

CREATE SEQUENCE shikshanboard.students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE shikshanboard.students_id_seq OWNER TO postgres;

--
-- TOC entry 5081 (class 0 OID 0)
-- Dependencies: 218
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: shikshanboard; Owner: postgres
--

ALTER SEQUENCE shikshanboard.students_id_seq OWNED BY shikshanboard.students.id;


--
-- TOC entry 245 (class 1259 OID 46588)
-- Name: test29branch; Type: TABLE; Schema: shikshanboard; Owner: postgres
--

CREATE TABLE shikshanboard.test29branch (
    id integer NOT NULL,
    row_id text NOT NULL,
    branch_name text,
    branch_head_name text,
    address text,
    city integer,
    mobile_no text,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    head_stdcode text,
    head_phone text,
    head_ophone text,
    head_mname text,
    head_maddress text,
    head_mstdcode text,
    head_mphone text,
    head_mophone text,
    head_mmobile text
);


ALTER TABLE shikshanboard.test29branch OWNER TO postgres;

--
-- TOC entry 244 (class 1259 OID 46587)
-- Name: test29branch_id_seq; Type: SEQUENCE; Schema: shikshanboard; Owner: postgres
--

CREATE SEQUENCE shikshanboard.test29branch_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE shikshanboard.test29branch_id_seq OWNER TO postgres;

--
-- TOC entry 5082 (class 0 OID 0)
-- Dependencies: 244
-- Name: test29branch_id_seq; Type: SEQUENCE OWNED BY; Schema: shikshanboard; Owner: postgres
--

ALTER SEQUENCE shikshanboard.test29branch_id_seq OWNED BY shikshanboard.test29branch.id;


--
-- TOC entry 217 (class 1259 OID 45962)
-- Name: users; Type: TABLE; Schema: shikshanboard; Owner: postgres
--

CREATE TABLE shikshanboard.users (
    id integer NOT NULL,
    row_id text NOT NULL,
    user_name text NOT NULL,
    user_password text NOT NULL,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE shikshanboard.users OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 45961)
-- Name: users_id_seq; Type: SEQUENCE; Schema: shikshanboard; Owner: postgres
--

CREATE SEQUENCE shikshanboard.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE shikshanboard.users_id_seq OWNER TO postgres;

--
-- TOC entry 5083 (class 0 OID 0)
-- Dependencies: 216
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: shikshanboard; Owner: postgres
--

ALTER SEQUENCE shikshanboard.users_id_seq OWNED BY shikshanboard.users.id;


--
-- TOC entry 4777 (class 2604 OID 46381)
-- Name: attendance id; Type: DEFAULT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.attendance ALTER COLUMN id SET DEFAULT nextval('shikshanboard.attendance_id_seq'::regclass);


--
-- TOC entry 4814 (class 2604 OID 46382)
-- Name: bandals id; Type: DEFAULT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.bandals ALTER COLUMN id SET DEFAULT nextval('shikshanboard.bandals_id_seq'::regclass);


--
-- TOC entry 4804 (class 2604 OID 46383)
-- Name: branch id; Type: DEFAULT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.branch ALTER COLUMN id SET DEFAULT nextval('shikshanboard.branch_id_seq'::regclass);


--
-- TOC entry 4809 (class 2604 OID 46384)
-- Name: centers id; Type: DEFAULT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.centers ALTER COLUMN id SET DEFAULT nextval('shikshanboard.centers_id_seq'::regclass);


--
-- TOC entry 4799 (class 2604 OID 46385)
-- Name: classes id; Type: DEFAULT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.classes ALTER COLUMN id SET DEFAULT nextval('shikshanboard.classes_id_seq'::regclass);


--
-- TOC entry 4780 (class 2604 OID 46386)
-- Name: copy_checkers id; Type: DEFAULT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.copy_checkers ALTER COLUMN id SET DEFAULT nextval('shikshanboard.copy_checkers_id_seq'::regclass);


--
-- TOC entry 4832 (class 2604 OID 46613)
-- Name: event id; Type: DEFAULT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.event ALTER COLUMN id SET DEFAULT nextval('shikshanboard.event_id_seq'::regclass);


--
-- TOC entry 4794 (class 2604 OID 46387)
-- Name: exam_sessions id; Type: DEFAULT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.exam_sessions ALTER COLUMN id SET DEFAULT nextval('shikshanboard.exam_sessions_id_seq'::regclass);


--
-- TOC entry 4785 (class 2604 OID 46388)
-- Name: marks id; Type: DEFAULT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.marks ALTER COLUMN id SET DEFAULT nextval('shikshanboard.marks_id_seq'::regclass);


--
-- TOC entry 4788 (class 2604 OID 46389)
-- Name: merit_list id; Type: DEFAULT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.merit_list ALTER COLUMN id SET DEFAULT nextval('shikshanboard.merit_list_id_seq'::regclass);


--
-- TOC entry 4791 (class 2604 OID 46390)
-- Name: online_forms id; Type: DEFAULT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.online_forms ALTER COLUMN id SET DEFAULT nextval('shikshanboard.online_forms_id_seq'::regclass);


--
-- TOC entry 4817 (class 2604 OID 46391)
-- Name: samplebook id; Type: DEFAULT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.samplebook ALTER COLUMN id SET DEFAULT nextval('shikshanboard.samplebook_id_seq'::regclass);


--
-- TOC entry 4822 (class 2604 OID 46392)
-- Name: samplepaper id; Type: DEFAULT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.samplepaper ALTER COLUMN id SET DEFAULT nextval('shikshanboard.samplepaper_id_seq'::regclass);


--
-- TOC entry 4837 (class 2604 OID 46639)
-- Name: student_exam_mappings id; Type: DEFAULT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.student_exam_mappings ALTER COLUMN id SET DEFAULT nextval('shikshanboard.student_exam_mappings_id_seq'::regclass);


--
-- TOC entry 4772 (class 2604 OID 46393)
-- Name: students id; Type: DEFAULT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.students ALTER COLUMN id SET DEFAULT nextval('shikshanboard.students_id_seq'::regclass);


--
-- TOC entry 4827 (class 2604 OID 46591)
-- Name: test29branch id; Type: DEFAULT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.test29branch ALTER COLUMN id SET DEFAULT nextval('shikshanboard.test29branch_id_seq'::regclass);


--
-- TOC entry 4769 (class 2604 OID 46394)
-- Name: users id; Type: DEFAULT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.users ALTER COLUMN id SET DEFAULT nextval('shikshanboard.users_id_seq'::regclass);


--
-- TOC entry 5032 (class 0 OID 46128)
-- Dependencies: 221
-- Data for Name: attendance; Type: TABLE DATA; Schema: shikshanboard; Owner: postgres
--

INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (31, '1746072434646_cXif', '1745908872742_uMxz', '1745924133662_JsXo', '1746013817187_GwLg', '2025-04-30 21:07:14.611947', '2025-04-30 21:07:14.611947', 2, '1745916652104_nBkM', 3, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (32, '1746072474406_apBK', '1745909351319_FXhs', '1745924133662_JsXo', '1746013817187_GwLg', '2025-04-30 21:07:54.403683', '2025-04-30 21:07:54.403683', 2, '1745916652104_nBkM', 3, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (33, '1746168480307_AKZK', '1745909351319_FXhs', '1745914455388_eqdJ', '1745917161766_y4sG', '2025-05-01 23:48:00.312893', '2025-05-01 23:48:00.312893', 0, '1745916652104_nBkM', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (34, '1746172111688_UhBT', '1745911145396_EtdM', '1745913882759_Muph', '1745917161766_y4sG', '2025-05-02 00:48:31.686457', '2025-05-02 00:48:31.686457', 0, '1745916652104_nBkM', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (30, '1745996500213_1aeW', '1745909570880_uHLR', '1745914455388_eqdJ', '1745917161766_y4sG', '2025-04-30 00:01:40.211141', '2025-04-30 00:01:40.211141', 2, '1745916652104_nBkM', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (35, '1746175992676_ld5h', '1745561869364_dnj1', '1745913882759_Muph', '1745917161766_y4sG', '2025-05-02 01:53:12.674445', '2025-05-02 01:53:12.674445', 0, '1745916652104_nBkM', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (41, '1746427233442_2aBM', '1746425916211_JIw5', '1746254533149_avX8', '1746426860804_UPg0', '2025-05-04 23:40:33.440622', '2025-05-04 23:40:33.440622', 2, '1746255290760_sJ6b', 0, 'more money have ') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (18, '1745578195214_gL95', '1745556624530_RYCo', '1745386590775_PlB7', '1745490037429_c1jy', '2025-04-25 03:49:55.218301', '2025-04-25 03:49:55.218301', 5, NULL, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (21, '1745933695812_eSiq', '1745847942352_zTqa', '1745914455388_eqdJ', '1745405722193_4pNh', '2025-04-29 06:34:55.796714', '2025-04-29 06:34:55.796714', 0, '1745408461239_rXWf', NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (22, '1745933897196_OY72', '1745904043327_zFcU', '1745924133662_JsXo', '1745405722193_4pNh', '2025-04-29 06:38:17.196353', '2025-04-29 06:38:17.196353', 0, '1745476357636_H7j1', NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (23, '1745985112676_IeHi', '1745561869364_dnj1', '1745904959485_a98x', '1745917161766_y4sG', '2025-04-29 20:51:52.674677', '2025-04-29 20:51:52.674677', 0, '1745916652104_nBkM', NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (24, '1745985269080_tMt1', '1745843533056_95ib', '1745904959485_a98x', '1745917161766_y4sG', '2025-04-29 20:54:29.077733', '2025-04-29 20:54:29.077733', 0, '1745916652104_nBkM', 2, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (25, '1745993295601_QYZD', '1745990715086_jE6N', NULL, '1745917161766_y4sG', '2025-04-29 23:08:15.598351', '2025-04-29 23:08:15.598351', 0, '1745408461239_rXWf', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (26, '1745994093129_q4rw', '1745990715086_jE6N', NULL, '1745917161766_y4sG', '2025-04-29 23:21:33.128136', '2025-04-29 23:21:33.128136', 0, '1745408461239_rXWf', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (27, '1745994721950_odm5', '1745904742569_7leg', '1745904959485_a98x', '1745917161766_y4sG', '2025-04-29 23:32:01.946581', '2025-04-29 23:32:01.946581', 0, '1745408461239_rXWf', 2, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (28, '1745995387461_4XmP', '1745904742569_7leg', '', '1745917161766_y4sG', '2025-04-29 23:43:07.457027', '2025-04-29 23:43:07.457027', 0, '1745408461239_rXWf', 3, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (29, '1745995531579_u7Db', '1745904742569_7leg', '1745904959485_a98x', '1745917161766_y4sG', '2025-04-29 23:45:31.574895', '2025-04-29 23:45:31.574895', 0, '1745408461239_rXWf', 3, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (42, '1746443645716_31bT', '1746443583743_fWE1', '1746254533149_avX8', '1746426860804_UPg0', '2025-05-05 04:14:05.714745', '2025-05-05 04:14:05.714745', 0, '1746255290760_sJ6b', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (43, '1746443667894_G5Z8', '1746443389168_wvVB', '1746254533149_avX8', '1746426860804_UPg0', '2025-05-05 04:14:27.892359', '2025-05-05 04:14:27.892359', 0, '1746255290760_sJ6b', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (37, '1746271838368_QXF8', '1746253859848_sDcB', '1746254533149_avX8', '1746255534831_uUSx', '2025-05-03 04:30:38.365957', '2025-05-03 04:30:38.365957', 0, '1746255290760_sJ6b', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (36, '1746256435701_DhAK', '1746253746367_4k5L', '1746254533149_avX8', '1746255534831_uUSx', '2025-05-03 00:13:55.697473', '2025-05-03 00:13:55.697473', 2, '1746255290760_sJ6b', 1, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (44, '1746444698641_aT6n', '1746444490504_qVIo', '1746254533149_avX8', '1746426860804_UPg0', '2025-05-05 04:31:38.639566', '2025-05-05 04:31:38.639566', 1, '1746255290760_sJ6b', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (45, '1746444760842_f66c', '1746444660804_396Z', '1746254533149_avX8', '1746426860804_UPg0', '2025-05-05 04:32:40.840974', '2025-05-05 04:32:40.840974', 2, '1746255290760_sJ6b', 0, 'bed ') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (46, '1746518631997_oOlj', '1746518617037_M5U2', '1746254533149_avX8', '1746426860804_UPg0', '2025-05-06 01:03:51.994952', '2025-05-06 01:03:51.994952', 0, '1745916652104_nBkM', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (49, '1746683534508_JUQ6', '1746683518400_MruS', '1746254533149_avX8', '1746426860804_UPg0', '2025-05-07 22:52:14.457829', '2025-05-07 22:52:14.457829', 0, '1746255290760_sJ6b', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (40, '1746427196588_Hlb2', '1746426071562_3jUC', '1746254533149_avX8', '1746426860804_UPg0', '2025-05-04 23:39:56.587055', '2025-05-04 23:39:56.587055', 1, '1746255290760_sJ6b', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (50, '1746688529190_W4o9', '1746687385730_2q28', '1746254533149_avX8', '1746426860804_UPg0', '2025-05-08 00:15:29.1863', '2025-05-08 00:15:29.1863', 0, '1746255290760_sJ6b', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (51, '1746690805508_AD7g', '1746690788331_5XU2', '1745924133662_JsXo', '1746426860804_UPg0', '2025-05-08 00:53:25.506459', '2025-05-08 00:53:25.506459', 0, '1745916652104_nBkM', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (52, '1746691000493_A0Ik', '1746690524056_6AAt', '1746254533149_avX8', '1746426860804_UPg0', '2025-05-08 00:56:40.492185', '2025-05-08 00:56:40.492185', 0, '1745916652104_nBkM', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (53, '1746691159067_WMUi', '1746691140067_JYcf', '1745914936065_eHuF', '1746426860804_UPg0', '2025-05-08 00:59:19.066334', '2025-05-08 00:59:19.066334', 0, '1745476357636_H7j1', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (54, '1746691514931_a5WQ', '1746691140067_JYcf', '1746254533149_avX8', '1746255534831_uUSx', '2025-05-08 01:05:14.929975', '2025-05-08 01:05:14.929975', 0, '1745408556650_JLad', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (47, '1746606454154_X9n8', '1746606411407_VgzJ', '1746254533149_avX8', '1746426860804_UPg0', '2025-05-07 01:27:34.121629', '2025-05-07 01:27:34.121629', 0, '1745408556650_JLad', 0, 'xyz res') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (48, '1746606497983_CLEH', '1746606283505_FkH7', '1746254533149_avX8', '1746426860804_UPg0', '2025-05-07 01:28:17.982334', '2025-05-07 01:28:17.982334', 0, '1745408556650_JLad', 0, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code, faculty, remarks) VALUES (55, '1746694942562_FivR', '1746694815096_sEZV', '1745914936065_eHuF', '1746255534831_uUSx', '2025-05-08 02:02:22.568625', '2025-05-08 02:02:22.568625', 0, '1745476357636_H7j1', 0, NULL) ON CONFLICT DO NOTHING;


--
-- TOC entry 5050 (class 0 OID 46321)
-- Dependencies: 239
-- Data for Name: bandals; Type: TABLE DATA; Schema: shikshanboard; Owner: postgres
--

INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (33, '1745582649327_lKhE', 500, '1745386590775_PlB7', '1745490037429_c1jy', '1745384758668_hWqc', '1745556713260_lKtR', '2025-04-25 05:04:09.333592', '2025-04-25 05:04:09.333592', NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (34, '1745582649330_fdpa', 500, '1745386590775_PlB7', '1745490037429_c1jy', '1745384758668_hWqc', '1745561869364_dnj1', '2025-04-25 05:04:09.336115', '2025-04-25 05:04:09.336115', NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (35, '1745935575109_eEXU', 501, NULL, '1745405722193_4pNh', '1745916841236_kxlr', '1745847942352_zTqa', '2025-04-29 07:06:15.123829', '2025-04-29 07:06:15.123829', NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (36, '1745935665249_ffSk', 502, NULL, '1745405722193_4pNh', '1745916841236_kxlr', '1745847942352_zTqa', '2025-04-29 07:07:45.250418', '2025-04-29 07:07:45.250418', NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (37, '1745935687229_7D2V', 503, NULL, '1745405722193_4pNh', '1745916841236_kxlr', '1745847942352_zTqa', '2025-04-29 07:08:07.230325', '2025-04-29 07:08:07.230325', NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (38, '1745985984421_eOXa', 504, '1745904959485_a98x', '1745917161766_y4sG', '1745585804493_zY2k', '1745843533056_95ib', '2025-04-29 21:06:24.425619', '2025-04-29 21:06:24.425619', 2) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (39, '1745999554488_x7XY', 505, NULL, '1745917161766_y4sG', '1745916841236_kxlr', '1745909570880_uHLR', '2025-04-30 00:52:34.489799', '2025-04-30 00:52:34.489799', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (42, '1746072637994_1jvV', 506, '1745924133662_JsXo', '1746013817187_GwLg', '1745585804493_zY2k', '1745908872742_uMxz', '2025-04-30 21:10:37.995689', '2025-04-30 21:10:37.995689', 3) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (43, '1746072637997_k1Uy', 506, '1745924133662_JsXo', '1746013817187_GwLg', '1745585804493_zY2k', '1745909351319_FXhs', '2025-04-30 21:10:37.998759', '2025-04-30 21:10:37.998759', 3) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (44, '1746172144898_ObGf', 507, NULL, '1745917161766_y4sG', '1745916841236_kxlr', '1745911145396_EtdM', '2025-05-02 00:49:04.905796', '2025-05-02 00:49:04.905796', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (45, '1746257080856_RHfa', 508, '1746254533149_avX8', '1746255534831_uUSx', '1746254260301_pnl4', '1746253746367_4k5L', '2025-05-03 00:24:40.856997', '2025-05-03 00:24:40.856997', 1) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (46, '1746272101396_lFqD', 509, '1746254533149_avX8', '1746255534831_uUSx', '1746254260301_pnl4', '1746253859848_sDcB', '2025-05-03 04:35:01.40198', '2025-05-03 04:35:01.40198', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (49, '1746427549546_n4WE', 510, '1746254533149_avX8', '1746426860804_UPg0', '1746254260301_pnl4', '1746426071562_3jUC', '2025-05-04 23:45:49.549072', '2025-05-04 23:45:49.549072', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (50, '1746427549549_8f4K', 510, '1746254533149_avX8', '1746426860804_UPg0', '1746254260301_pnl4', '1746425916211_JIw5', '2025-05-04 23:45:49.551599', '2025-05-04 23:45:49.551599', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (51, '1746443746111_jTVy', 511, '1746254533149_avX8', '1746426860804_UPg0', '1745585804493_zY2k', '1746443583743_fWE1', '2025-05-05 04:15:46.112821', '2025-05-05 04:15:46.112821', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (52, '1746443746113_oSiW', 511, '1746254533149_avX8', '1746426860804_UPg0', '1745585804493_zY2k', '1746443389168_wvVB', '2025-05-05 04:15:46.11473', '2025-05-05 04:15:46.11473', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (53, '1746444922155_6Njt', 512, '1746254533149_avX8', '1746426860804_UPg0', '1746254260301_pnl4', '1746444660804_396Z', '2025-05-05 04:35:22.167701', '2025-05-05 04:35:22.167701', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (54, '1746444922158_Xxl3', 512, '1746254533149_avX8', '1746426860804_UPg0', '1746254260301_pnl4', '1746444490504_qVIo', '2025-05-05 04:35:22.169927', '2025-05-05 04:35:22.169927', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (55, '1746518662588_TQNy', 513, '1746254533149_avX8', '1746426860804_UPg0', '1746254260301_pnl4', '1746518617037_M5U2', '2025-05-06 01:04:22.588747', '2025-05-06 01:04:22.588747', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (56, '1746606562359_qSTj', 514, '1746254533149_avX8', '1746426860804_UPg0', '1745835872064_h26b', '1746606283505_FkH7', '2025-05-07 01:29:22.35956', '2025-05-07 01:29:22.35956', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (57, '1746606562371_EXpo', 514, '1746254533149_avX8', '1746426860804_UPg0', '1745835872064_h26b', '1746606411407_VgzJ', '2025-05-07 01:29:22.372495', '2025-05-07 01:29:22.372495', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (58, '1746683568061_1X2i', 515, '1746254533149_avX8', '1746426860804_UPg0', '1746254260301_pnl4', '1746683518400_MruS', '2025-05-07 22:52:48.074256', '2025-05-07 22:52:48.074256', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on, faculty) VALUES (59, '1746694998388_hs10', 516, '1745914936065_eHuF', '1746255534831_uUSx', '1746531891824_m9lU', '1746694815096_sEZV', '2025-05-08 02:03:18.397355', '2025-05-08 02:03:18.397355', 0) ON CONFLICT DO NOTHING;


--
-- TOC entry 5046 (class 0 OID 46273)
-- Dependencies: 235
-- Data for Name: branch; Type: TABLE DATA; Schema: shikshanboard; Owner: postgres
--

INSERT INTO shikshanboard.branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted) VALUES (1, '1745407289560_6iar', 'new branch', 'head branch', 'mandore', 2, '9078563412', '2025-04-23 04:21:29.596263', '2025-04-23 04:21:29.596263', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted) VALUES (6, '1745914090455_kaM0', 'Branch One', 'Head One', 'Address One', 0, '1234567890', '2025-04-29 01:08:10.499284', '2025-04-29 01:08:10.499284', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted) VALUES (7, '1745914410688_HqVW', 'Branch Two', 'Head Two', 'Address Two', 0, '', '2025-04-29 01:13:30.72517', '2025-04-29 01:13:30.72517', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted) VALUES (8, '1745915853606_ospy', 'Test 1', 'Test Head 1', 'Test Address', 1, '', '2025-04-29 01:37:33.634207', '2025-04-29 01:37:33.634207', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted) VALUES (9, '1745915902877_NOhq', 'a', 'b', 'c', NULL, '', '2025-04-29 01:38:22.915645', '2025-04-29 01:38:22.915645', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted) VALUES (10, '1745915991878_yRoo', 'a', 'b', 'c', 3, '', '2025-04-29 01:39:52.019555', '2025-04-29 01:39:52.019555', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted) VALUES (11, '1746014032993_TcMf', 'new branch name1234', 'new head of branch name 500', 'hello 678', 33, '9078563412', '2025-04-30 04:53:53.027883', '2025-04-30 11:54:52.243', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted) VALUES (12, '1746254862424_yl3o', 'MY new branch', 'head of new branch', 'koto 123', 3, '9078563412', '2025-05-02 23:47:42.4637', '2025-05-02 23:47:42.4637', true, false) ON CONFLICT DO NOTHING;


--
-- TOC entry 5048 (class 0 OID 46284)
-- Dependencies: 237
-- Data for Name: centers; Type: TABLE DATA; Schema: shikshanboard; Owner: postgres
--

INSERT INTO shikshanboard.centers (id, row_id, branch_id, center, center_head_name, email, address, date_of_birth, state, city, std_code, phone_no, mobile_no, account_no, account_name, bank_name, branch_name, ifsc_code, cr_on, up_on, center_code, is_active, is_deleted) VALUES (1, '1745408461239_rXWf', NULL, 'head branch', 'mandore', 'email123', 'address123', '2020-06-12', 7, 3, '1234', '89', '55', 'sdfgsdf', 'sdfgsdf', 'strisfng', 'stdfring', 'strifgsng', '2025-04-23 04:41:01.37647', '2025-04-23 04:41:01.37647', NULL, true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.centers (id, row_id, branch_id, center, center_head_name, email, address, date_of_birth, state, city, std_code, phone_no, mobile_no, account_no, account_name, bank_name, branch_name, ifsc_code, cr_on, up_on, center_code, is_active, is_deleted) VALUES (5, '1745476357636_H7j1', '1745407289560_6iar', 'string12', 'string23 this head center', 'string', 'string', '2000-09-07', 1, 2, 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', '2025-04-23 23:32:37.6735', '2025-04-23 23:32:37.6735', 3755, true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.centers (id, row_id, branch_id, center, center_head_name, email, address, date_of_birth, state, city, std_code, phone_no, mobile_no, account_no, account_name, bank_name, branch_name, ifsc_code, cr_on, up_on, center_code, is_active, is_deleted) VALUES (3, '1745408556650_JLad', '1745407289560_6iar', 'head branch', 'mandore', 'email123', 'address123', '2020-06-12', 7, 3, '1234', '89', '55', 'sdfgsdf', 'sdfgsdf', 'strisfng', 'stdfring', 'strifgsng', '2025-04-23 04:42:36.678279', '2025-04-23 04:42:36.678279', 890, true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.centers (id, row_id, branch_id, center, center_head_name, email, address, date_of_birth, state, city, std_code, phone_no, mobile_no, account_no, account_name, bank_name, branch_name, ifsc_code, cr_on, up_on, center_code, is_active, is_deleted) VALUES (13, '1745916652104_nBkM', '1745915853606_ospy', 'Test Center', 'TEst Head', 'aafreen.fintech@gmail.com', 'STPI Jodpur aaaa', '1974-06-04', 28, 2, NULL, '87742529160', NULL, NULL, NULL, NULL, NULL, NULL, '2025-04-29 01:50:52.132208', '2025-04-29 01:50:52.132208', 5584, true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.centers (id, row_id, branch_id, center, center_head_name, email, address, date_of_birth, state, city, std_code, phone_no, mobile_no, account_no, account_name, bank_name, branch_name, ifsc_code, cr_on, up_on, center_code, is_active, is_deleted) VALUES (14, '1746255290760_sJ6b', '1746254862424_yl3o', 'my new center', 'head of center', 'abhi@newcenter.com', 'new mandore', '2000-09-12', 12, 3, '123', '9078564523', '67890452312', '89567890123', 'new accound', 'new bank', 'new branch', '123ifsc', '2025-05-02 23:54:50.804412', '2025-05-02 23:54:50.804412', 3717, true, false) ON CONFLICT DO NOTHING;


--
-- TOC entry 5044 (class 0 OID 46262)
-- Dependencies: 233
-- Data for Name: classes; Type: TABLE DATA; Schema: shikshanboard; Owner: postgres
--

INSERT INTO shikshanboard.classes (id, row_id, faculty, class_name, first_price, second_price, third_price, merit_list_upto_10_price, marks_greater_equal_to_90, marks_70_to_less_then_90, marks_50_to_less_then_70, cr_on, up_on, is_active, is_deleted) VALUES (2, '1745490037429_c1jy', 1, 'gh', 44, 55, 77, 88, 99, 11, 22, '2025-04-24 03:20:37.454411', '2025-04-24 03:20:37.454411', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.classes (id, row_id, faculty, class_name, first_price, second_price, third_price, merit_list_upto_10_price, marks_greater_equal_to_90, marks_70_to_less_then_90, marks_50_to_less_then_70, cr_on, up_on, is_active, is_deleted) VALUES (7, '1745917161766_y4sG', 0, 'Class 2', 10000, 8000, 7000, 5000, 3000, 1500, 1000, '2025-04-29 01:59:21.76726', '2025-04-29 01:59:21.76726', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.classes (id, row_id, faculty, class_name, first_price, second_price, third_price, merit_list_upto_10_price, marks_greater_equal_to_90, marks_70_to_less_then_90, marks_50_to_less_then_70, cr_on, up_on, is_active, is_deleted) VALUES (1, '1745405722193_4pNh', 1, '1st', 10000, 5000, 3000, 45, 78, 90, 22, '2025-04-23 03:55:22.226934', '2025-04-23 03:55:22.226934', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.classes (id, row_id, faculty, class_name, first_price, second_price, third_price, merit_list_upto_10_price, marks_greater_equal_to_90, marks_70_to_less_then_90, marks_50_to_less_then_70, cr_on, up_on, is_active, is_deleted) VALUES (8, '1746013817187_GwLg', 3, 'new class 9000', 15000, 16000, 65000, 67000, 13000, 21000, 1800, '2025-04-30 04:50:17.227282', '2025-04-30 04:50:17.227282', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.classes (id, row_id, faculty, class_name, first_price, second_price, third_price, merit_list_upto_10_price, marks_greater_equal_to_90, marks_70_to_less_then_90, marks_50_to_less_then_70, cr_on, up_on, is_active, is_deleted) VALUES (9, '1746255534831_uUSx', 0, 'bcoom', 12000, 10000, 8000, 7000, 6000, 5000, 4000, '2025-05-02 23:58:54.871663', '2025-05-02 23:58:54.871663', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.classes (id, row_id, faculty, class_name, first_price, second_price, third_price, merit_list_upto_10_price, marks_greater_equal_to_90, marks_70_to_less_then_90, marks_50_to_less_then_70, cr_on, up_on, is_active, is_deleted) VALUES (10, '1746426860804_UPg0', 0, 'MCA ', 10000, 8000, 6000, 5000, 4000, 3000, 2000, '2025-05-04 23:34:20.844245', '2025-05-04 23:34:20.844245', true, false) ON CONFLICT DO NOTHING;


--
-- TOC entry 5034 (class 0 OID 46144)
-- Dependencies: 223
-- Data for Name: copy_checkers; Type: TABLE DATA; Schema: shikshanboard; Owner: postgres
--

INSERT INTO shikshanboard.copy_checkers (id, row_id, name, address, mobile, cr_on, up_on, is_active, is_deleted, account_no, account_name, bank_name, branch_name, ifsc_code) VALUES (2, '1745384953440_iOLg', 'test1', 'test1@gmail.com', '8078563412', '2025-04-22 22:09:13.474312', '2025-04-22 22:09:13.474312', true, false, NULL, NULL, NULL, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.copy_checkers (id, row_id, name, address, mobile, cr_on, up_on, is_active, is_deleted, account_no, account_name, bank_name, branch_name, ifsc_code) VALUES (3, '1745584515663_bctD', 'Fintech', 'STPI', '9876543210', '2025-04-25 05:35:15.691987', '2025-04-25 05:35:15.691987', true, false, NULL, NULL, NULL, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.copy_checkers (id, row_id, name, address, mobile, cr_on, up_on, is_active, is_deleted, account_no, account_name, bank_name, branch_name, ifsc_code) VALUES (4, '1745585542101_4jji', 'CodeFlux', 'STPI 1st Floor', '9874563210', '2025-04-25 05:52:22.126524', '2025-04-25 05:52:22.126524', true, false, NULL, NULL, NULL, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.copy_checkers (id, row_id, name, address, mobile, cr_on, up_on, is_active, is_deleted, account_no, account_name, bank_name, branch_name, ifsc_code) VALUES (5, '1745585804493_zY2k', 'Abhishek', '9 mile', '9874561230', '2025-04-25 05:56:44.518464', '2025-04-25 05:56:44.518464', true, false, NULL, NULL, NULL, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.copy_checkers (id, row_id, name, address, mobile, cr_on, up_on, is_active, is_deleted, account_no, account_name, bank_name, branch_name, ifsc_code) VALUES (6, '1745660612642_Ah1Y', 'Canvas', 'FlutterCanvas.io', '7896541230', '2025-04-26 02:43:32.668049', '2025-04-26 02:43:32.668049', true, false, NULL, NULL, NULL, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.copy_checkers (id, row_id, name, address, mobile, cr_on, up_on, is_active, is_deleted, account_no, account_name, bank_name, branch_name, ifsc_code) VALUES (5, '1745827527173_XlLI', 'Vikas', 'Delhi', '9876543210', '2025-04-28 01:05:27.199181', '2025-04-28 01:05:27.199181', true, false, NULL, NULL, NULL, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.copy_checkers (id, row_id, name, address, mobile, cr_on, up_on, is_active, is_deleted, account_no, account_name, bank_name, branch_name, ifsc_code) VALUES (6, '1745830457859_rmHE', 'ds', 'sdf', '24352435234', '2025-04-28 01:54:17.903301', '2025-04-28 01:54:17.903301', true, false, NULL, NULL, NULL, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.copy_checkers (id, row_id, name, address, mobile, cr_on, up_on, is_active, is_deleted, account_no, account_name, bank_name, branch_name, ifsc_code) VALUES (7, '1745830457867_AOTV', 'ds', 'sdf', '24352435234', '2025-04-28 01:54:17.903482', '2025-04-28 01:54:17.903482', true, false, NULL, NULL, NULL, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.copy_checkers (id, row_id, name, address, mobile, cr_on, up_on, is_active, is_deleted, account_no, account_name, bank_name, branch_name, ifsc_code) VALUES (8, '1745835872064_h26b', 'new cheker600', 'jodhpur', '9078563412', '2025-04-28 03:24:32.102689', '2025-04-28 10:25:37.947', true, false, NULL, NULL, NULL, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.copy_checkers (id, row_id, name, address, mobile, cr_on, up_on, is_active, is_deleted, account_no, account_name, bank_name, branch_name, ifsc_code) VALUES (9, '1745905092521_NV26', 'Shrikant Garu', 'Tamil Nadu', '6985542213', '2025-04-28 22:38:12.547255', '2025-04-28 22:38:12.547255', true, false, NULL, NULL, NULL, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.copy_checkers (id, row_id, name, address, mobile, cr_on, up_on, is_active, is_deleted, account_no, account_name, bank_name, branch_name, ifsc_code) VALUES (10, '1745916841236_kxlr', 'Aafreen Ali', 'STPI Jodhpur', '7742529160', '2025-04-29 01:54:01.27118', '2025-04-29 08:54:51.262', true, false, NULL, NULL, NULL, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.copy_checkers (id, row_id, name, address, mobile, cr_on, up_on, is_active, is_deleted, account_no, account_name, bank_name, branch_name, ifsc_code) VALUES (1, '1745384758668_hWqc', 'riya23', 'riya@gmail.com', '9078563412', '2025-04-22 22:05:58.702487', '2025-04-22 22:05:58.702487', true, false, NULL, NULL, NULL, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.copy_checkers (id, row_id, name, address, mobile, cr_on, up_on, is_active, is_deleted, account_no, account_name, bank_name, branch_name, ifsc_code) VALUES (11, '1746254260301_pnl4', 'kundan123', 'mandore', '7891234567', '2025-05-02 23:37:40.345433', '2025-05-02 23:37:40.345433', true, false, NULL, NULL, NULL, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.copy_checkers (id, row_id, name, address, mobile, cr_on, up_on, is_active, is_deleted, account_no, account_name, bank_name, branch_name, ifsc_code) VALUES (12, '1746531891824_m9lU', 'test checker 110', 'test address checker 110', '9078563423', '2025-05-06 04:44:51.867164', '2025-05-06 04:44:51.867164', true, false, '907856341289', 'sbi account ', 'sbi bank ', 'sbi branch name', '7890') ON CONFLICT DO NOTHING;


--
-- TOC entry 5058 (class 0 OID 46610)
-- Dependencies: 247
-- Data for Name: event; Type: TABLE DATA; Schema: shikshanboard; Owner: postgres
--

INSERT INTO shikshanboard.event (id, row_id, event_name, event_date, cr_on, up_on, is_active, is_deleted) VALUES (1, '1746102066503_0lbK', 'new event 2025', '2025-04-12', '2025-05-01 05:21:06.542619', '2025-05-01 05:21:06.542619', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.event (id, row_id, event_name, event_date, cr_on, up_on, is_active, is_deleted) VALUES (2, '1746102106413_w9Y2', 'new event 2025 and 2030', '2025-04-12', '2025-05-01 05:21:46.440348', '2025-05-01 12:22:40.218', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.event (id, row_id, event_name, event_date, cr_on, up_on, is_active, is_deleted) VALUES (3, '1746260585341_X0MY', 'new event', '2025-05-23', '2025-05-03 01:23:05.368357', '2025-05-03 01:23:05.368357', true, false) ON CONFLICT DO NOTHING;


--
-- TOC entry 5042 (class 0 OID 46238)
-- Dependencies: 231
-- Data for Name: exam_sessions; Type: TABLE DATA; Schema: shikshanboard; Owner: postgres
--

INSERT INTO shikshanboard.exam_sessions (id, row_id, session_name, exam_date, cr_on, up_on, is_active, is_deleted) VALUES (1, '1745386443803_QBLg', 'Exam 2025', '2025-06-22', '2025-04-22 22:34:03.839244', '2025-04-22 22:34:03.839244', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.exam_sessions (id, row_id, session_name, exam_date, cr_on, up_on, is_active, is_deleted) VALUES (2, '1745386590775_PlB7', 'Exam 2026', '2025-06-22', '2025-04-22 22:36:30.80941', '2025-04-22 22:36:30.80941', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.exam_sessions (id, row_id, session_name, exam_date, cr_on, up_on, is_active, is_deleted) VALUES (3, '1745662651029_kyPx', 'Shanu', '2025-04-26', '2025-04-26 03:17:31.059861', '2025-04-26 03:17:31.059861', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.exam_sessions (id, row_id, session_name, exam_date, cr_on, up_on, is_active, is_deleted) VALUES (4, '1745665610848_lfAH', 'UPSC', '2025-04-22', '2025-04-26 04:06:50.878758', '2025-04-26 04:06:50.878758', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.exam_sessions (id, row_id, session_name, exam_date, cr_on, up_on, is_active, is_deleted) VALUES (6, '1745904959485_a98x', 'RPSC', '2025-04-29', '2025-04-28 22:35:59.523982', '2025-04-28 22:35:59.523982', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.exam_sessions (id, row_id, session_name, exam_date, cr_on, up_on, is_active, is_deleted) VALUES (7, '1745913882759_Muph', 'Exam 2025 May', '2025-05-07', '2025-04-29 01:04:42.787092', '2025-04-29 08:17:49.274', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.exam_sessions (id, row_id, session_name, exam_date, cr_on, up_on, is_active, is_deleted) VALUES (9, '1745914936065_eHuF', 'new exam ', '2025-12-05', '2025-04-29 01:22:16.091346', '2025-04-29 01:22:16.091346', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.exam_sessions (id, row_id, session_name, exam_date, cr_on, up_on, is_active, is_deleted) VALUES (22, '1745924090637_2Xiy', 'new exam 1700', '2022-03-22', '2025-04-29 03:54:50.665256', '2025-04-29 03:54:50.665256', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.exam_sessions (id, row_id, session_name, exam_date, cr_on, up_on, is_active, is_deleted) VALUES (23, '1745924133662_JsXo', 'new exam 1800', '2024-03-22', '2025-04-29 03:55:33.692193', '2025-04-29 03:55:33.692193', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.exam_sessions (id, row_id, session_name, exam_date, cr_on, up_on, is_active, is_deleted) VALUES (8, '1745914455388_eqdJ', 'Exam April 2025 ', '2025-05-15', '2025-04-29 01:14:15.414318', '2025-04-30 05:30:23.318', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.exam_sessions (id, row_id, session_name, exam_date, cr_on, up_on, is_active, is_deleted) VALUES (24, '1746254533149_avX8', 'EXAM 2027', '2027-05-23', '2025-05-02 23:42:13.19459', '2025-05-02 23:42:13.19459', true, false) ON CONFLICT DO NOTHING;


--
-- TOC entry 5036 (class 0 OID 46171)
-- Dependencies: 225
-- Data for Name: marks; Type: TABLE DATA; Schema: shikshanboard; Owner: postgres
--

INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (49, '1745998253071_rl4Z', '1745846237841_y8he', '1745904959485_a98x', '1745585804493_zY2k', 2900, '2025-04-30 00:30:53.072896', '2025-04-30 00:30:53.072896', 3, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (50, '1745998253075_3L0q', '1745561869364_dnj1', '1745904959485_a98x', '1745585804493_zY2k', 5500, '2025-04-30 00:30:53.076402', '2025-04-30 00:30:53.076402', 3, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (51, '1746000209542_QuZL', NULL, '1745914455388_eqdJ', '1745916841236_kxlr', 150, '2025-04-30 01:03:29.543726', '2025-04-30 01:03:29.543726', 0, '1745917161766_y4sG') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (52, '1746000450597_UZe3', '1745909570880_uHLR', '1745914455388_eqdJ', '1745916841236_kxlr', 100, '2025-04-30 01:07:30.598312', '2025-04-30 01:07:30.598312', 0, '1745917161766_y4sG') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (53, '1746072864831_qYxA', '1745908872742_uMxz', '1745924133662_JsXo', '1745585804493_zY2k', 1400, '2025-04-30 21:14:24.832225', '2025-04-30 21:14:24.832225', 3, '1746013817187_GwLg') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (54, '1746072864865_zqNk', '1745909351319_FXhs', '1745924133662_JsXo', '1745585804493_zY2k', 1500, '2025-04-30 21:14:24.866117', '2025-04-30 21:14:24.866117', 3, '1746013817187_GwLg') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (55, '1746172163828_v0my', '1745911145396_EtdM', '1745913882759_Muph', '1745916841236_kxlr', 100, '2025-05-02 00:49:23.835774', '2025-05-02 00:49:23.835774', 0, '1745917161766_y4sG') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (56, '1746257491012_Du2Q', '1746253746367_4k5L', '1746254533149_avX8', '1746254260301_pnl4', 490, '2025-05-03 00:31:31.013', '2025-05-03 00:31:31.013', 1, '1746255534831_uUSx') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (57, '1746422442247_ALOH', '1746253859848_sDcB', '1746254533149_avX8', '1746254260301_pnl4', 480, '2025-05-04 22:20:42.258074', '2025-05-04 22:20:42.258074', 0, '1746255534831_uUSx') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (58, '1746427614404_OB6y', '1746426071562_3jUC', '1746254533149_avX8', '1746254260301_pnl4', 460, '2025-05-04 23:46:54.405295', '2025-05-04 23:46:54.405295', 0, '1746426860804_UPg0') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (62, '1746445054055_iwQK', '1746444660804_396Z', '1746254533149_avX8', '1746254260301_pnl4', 350, '2025-05-05 04:37:34.056193', '2025-05-05 04:37:34.056193', 0, '1746426860804_UPg0') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (63, '1746445054057_Z87H', '1746444490504_qVIo', '1746254533149_avX8', '1746254260301_pnl4', 330, '2025-05-05 04:37:34.058774', '2025-05-05 04:37:34.058774', 0, '1746426860804_UPg0') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (60, '1746443797840_BiLE', '1746443583743_fWE1', '1746254533149_avX8', '1745585804493_zY2k', 390, '2025-05-05 04:16:37.841692', '2025-05-05 04:16:37.841692', 0, '1746426860804_UPg0') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (64, '1746518707832_e8bO', '1746518617037_M5U2', '1746254533149_avX8', '1746254260301_pnl4', 366, '2025-05-06 01:05:07.834998', '2025-05-06 01:05:07.834998', 0, '1746426860804_UPg0') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (59, '1746427614408_wbWL', '1746425916211_JIw5', '1746254533149_avX8', '1746254260301_pnl4', 460, '2025-05-04 23:46:54.409788', '2025-05-04 23:46:54.409788', 0, '1746426860804_UPg0') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (61, '1746443797843_tyLS', '1746443389168_wvVB', '1746254533149_avX8', '1745585804493_zY2k', 350, '2025-05-05 04:16:37.844539', '2025-05-05 04:16:37.844539', 0, '1746426860804_UPg0') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (65, '1746606598000_cElv', '1746606283505_FkH7', '1746254533149_avX8', '1745835872064_h26b', 370, '2025-05-07 01:29:58.001054', '2025-05-07 01:29:58.001054', 0, '1746426860804_UPg0') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (66, '1746606598011_MRi1', '1746606411407_VgzJ', '1746254533149_avX8', '1745835872064_h26b', 320, '2025-05-07 01:29:58.011835', '2025-05-07 01:29:58.011835', 0, '1746426860804_UPg0') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (67, '1746683585060_tudJ', '1746683518400_MruS', '1746254533149_avX8', '1746254260301_pnl4', 66, '2025-05-07 22:53:05.06633', '2025-05-07 22:53:05.06633', 0, '1746426860804_UPg0') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on, faculty, class_id) VALUES (68, '1746695017501_HBe6', '1746694815096_sEZV', '1745914936065_eHuF', '1746531891824_m9lU', 300, '2025-05-08 02:03:37.507004', '2025-05-08 02:03:37.507004', 0, '1746255534831_uUSx') ON CONFLICT DO NOTHING;


--
-- TOC entry 5038 (class 0 OID 46192)
-- Dependencies: 227
-- Data for Name: merit_list; Type: TABLE DATA; Schema: shikshanboard; Owner: postgres
--



--
-- TOC entry 5040 (class 0 OID 46208)
-- Dependencies: 229
-- Data for Name: online_forms; Type: TABLE DATA; Schema: shikshanboard; Owner: postgres
--



--
-- TOC entry 5051 (class 0 OID 46343)
-- Dependencies: 240
-- Data for Name: samplebook; Type: TABLE DATA; Schema: shikshanboard; Owner: postgres
--

INSERT INTO shikshanboard.samplebook (id, row_id, title, photo_path, cr_on, up_on, is_active, is_deleted) VALUES (1, '1745724277951_vpk4', 'new photo 1', 'uploads/application/1745724338812_Screenshot 2023-07-10 102532.png', '2025-04-27 03:24:37.953', '2025-04-27 03:26:22.402', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.samplebook (id, row_id, title, photo_path, cr_on, up_on, is_active, is_deleted) VALUES (2, '1746100169553_nE4R', 'new tilte', 'uploads/application/1746100046451_certificate .png', '2025-05-01 11:49:29.553', '2025-05-01 11:49:29.553', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.samplebook (id, row_id, title, photo_path, cr_on, up_on, is_active, is_deleted) VALUES (3, '1746260261662_g5ld', 'new title', 'uploads/application/1746260140588_Screenshot 2024-08-16 162408.png', '2025-05-03 08:17:41.662', '2025-05-03 08:17:41.662', true, false) ON CONFLICT DO NOTHING;


--
-- TOC entry 5053 (class 0 OID 46353)
-- Dependencies: 242
-- Data for Name: samplepaper; Type: TABLE DATA; Schema: shikshanboard; Owner: postgres
--

INSERT INTO shikshanboard.samplepaper (id, row_id, class_id, title, photo_path, cr_on, up_on, is_active, is_deleted) VALUES (1, '1745725150678_BcxS', '1745645378912_vbQE', 'screen shot', 'uploads/application/1745725109546_Screenshot 2023-07-14 105021.png', '2025-04-27 03:39:10.678', '2025-04-27 03:39:10.679', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.samplepaper (id, row_id, class_id, title, photo_path, cr_on, up_on, is_active, is_deleted) VALUES (2, '1746100999688_QxCn', '1746013817187_GwLg', 'new tilte 1234', 'uploads/application/1746100908794_upload.png', '2025-05-01 12:03:19.688', '2025-05-01 12:03:19.688', true, false) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.samplepaper (id, row_id, class_id, title, photo_path, cr_on, up_on, is_active, is_deleted) VALUES (3, '1746260423216_Ta1H', '1746255534831_uUSx', 'abhi 123 ', 'uploads/application/1746260392587_evenbooklogo.png', '2025-05-03 08:20:23.216', '2025-05-03 08:20:23.216', true, false) ON CONFLICT DO NOTHING;


--
-- TOC entry 5060 (class 0 OID 46636)
-- Dependencies: 249
-- Data for Name: student_exam_mappings; Type: TABLE DATA; Schema: shikshanboard; Owner: postgres
--



--
-- TOC entry 5030 (class 0 OID 46117)
-- Dependencies: 219
-- Data for Name: students; Type: TABLE DATA; Schema: shikshanboard; Owner: postgres
--

INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (17, '1745556713260_lKtR', 'string900', 'string', '2020-09-07', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', '2025-04-24', '2025-04-24 21:51:53.290394', 'string', 3, 4, NULL, NULL, 1002, true, false, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (16, '1745556649611_PbsH', 'string800', 'string', '2020-09-07', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', '2025-04-24', '2025-04-24 21:50:49.642025', 'string', 3, 4, '1745386443803_QBLg', '1745405722193_4pNh', 1001, true, false, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (15, '1745556624530_RYCo', 'string700', 'string', '2020-09-07', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', '2025-04-24', '2025-04-24 21:50:24.562832', 'string', 3, 4, '1745386590775_PlB7', '1745490037429_c1jy', NULL, true, false, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (25, '1745828590455_f659', 'rahui5670', 'father of rahul 700', '2022-08-12', '7078563412', 'koto', '5678', '12345678', '9078563412', '8078563412', 'Hindi', 'MCA', '9045678', 'HDFC', 'RAHUL', 'string', 'string', 'string', '2025-04-28', '2025-04-28 08:32:11.405', 'male', 2, 44, NULL, NULL, 1004, true, true, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (26, '1745830365685_wPe6', 'Ayush', 'A', '2000-04-28', '2752524', 'Test', '342001', '321564658522', '4252452', '4525254', 'hin', 'BSC', '1321657653254', 'Savings', 'SBI', 'Chopasani', 'BU2254', 'Test1', '2025-04-28', '2025-04-28 01:52:45.720848', 'm', 28, 20, NULL, NULL, 1005, true, false, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (34, '1745904742569_7leg', 'Example', 'Example Father', NULL, '', 'STPI', '', '', '', '', NULL, '', '', '', '', '', '', '', '2025-04-28', '2025-04-28 22:32:22.596721', 'f', 0, NULL, '1745904959485_a98x', '1745917161766_y4sG', 1013, true, false, '1745408461239_rXWf', 3) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (28, '1745846237841_y8he', 'Ayush', 'AAA', '2000-04-27', NULL, 'Test', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-04-28', '2025-04-28 06:17:17.871535', NULL, NULL, 20, NULL, NULL, 1007, true, false, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (31, '1745904260522_1Exn', 'Rama', 'Sama', '2025-04-29', '5587963214', 'ITI', '342008', '2658759632', '5489722111', '6665874223', 'hin', 'MSC', '554688771268', 'Current', 'IDFC', 'Mandore', 'B253HH45', '', '2025-04-28', '2025-04-28 22:24:20.556389', 'm', 28, 20, NULL, NULL, 1010, true, false, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (32, '1745904278386_O8v4', 'Rama', 'Sama', '2025-04-29', '', 'ITI', '', '2658759632', '5489722111', '6665874223', 'hin', 'MSC', '554688771268', 'Current', 'IDFC', 'Mandore', 'B253HH45', '', '2025-04-28', '2025-04-28 22:24:38.522205', 'm', 28, 20, NULL, NULL, 1011, true, false, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (33, '1745904297338_IVt0', '', '', NULL, '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '2025-04-28', '2025-04-28 22:24:57.340161', NULL, NULL, NULL, NULL, NULL, 1012, true, false, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (35, '1745908509870_RhGn', 'Meloni', 'Narendra', '2025-04-01', '154678654', 'Delhi', '645228', '324648251', '321658852', '13469852', 'guj', 'BA', '321155985528', 'Foriegn', 'CBI', 'Chandni Chowk', 'BB34399G', 'VIP Entry Test', '2025-04-28', '2025-04-28 23:35:09.910891', 'f', 9, 180, NULL, NULL, 1014, true, false, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (30, '1745904043327_zFcU', 'Rama', 'Sama', '2025-04-29', '5587963214', 'ITI', '342008', '2658759632', '5489722111', '6665874223', 'hin', 'MSC', '554688771268', 'Current', 'IDFC', 'Mandore', 'B253HH45', 'Working Test', '2025-04-28', '2025-04-28 22:20:43.355766', 'm', 28, 20, '1745924133662_JsXo', '1745405722193_4pNh', 1009, true, false, '1745476357636_H7j1', NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (46, '1746426620651_IpTE', 'test 802', 'father of test 802', '2000-03-07', '9078563412', 'mandore', '1234', '907856341234', '8901234567', '7812345678', 'english', 'MCA', '789012345678', 'sbi account ', 'sbi bank ', NULL, '555', NULL, '2025-05-04', '2025-05-04 23:30:20.801806', 'f', 28, 2, NULL, NULL, 1025, true, false, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (38, '1745909570880_uHLR', 'Chintu', 'Pintu', NULL, '', 'KNN', '', '', '', '', NULL, '', '', '', '', '', '', '', '2025-04-28', '2025-04-28 23:52:50.913951', 'f', NULL, NULL, '1745924133662_JsXo', '1745917161766_y4sG', 1017, true, false, '1745916652104_nBkM', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (48, '1746443583743_fWE1', 'test 804', 'father of test 804', '1996-05-08', '56367467467', 'test address 804', '5678', '7890123456', '387383745439', '2452345245', 'hindi', 'MCA', '7467472345245', 'sbi account ', 'sbi bank ', NULL, '4745', NULL, '2025-05-05', '2025-05-05 04:13:03.775912', 'm', 28, 5, '1746254533149_avX8', '1746426860804_UPg0', 1027, true, false, '1746255290760_sJ6b', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (29, '1745847942352_zTqa', 'aaaaaa', 'sdsa', '2022-01-31', NULL, 'dsfs', '342001', NULL, '7742529160', '6376952130', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-04-28', '2025-04-28 06:45:42.379931', 'm', NULL, NULL, '1745914455388_eqdJ', '1745405722193_4pNh', 1008, true, false, '1745408461239_rXWf', NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (37, '1745909351319_FXhs', 'Google', 'Sunder', '2005-04-13', '', 'Silicon Valley', '', '', '', '', NULL, '', '', '', '', '', '', '', '2025-04-28', '2025-04-28 23:49:11.345638', 'f', 7, 23, '1745914455388_eqdJ', '1745917161766_y4sG', 1016, true, false, '1745916652104_nBkM', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (39, '1745911145396_EtdM', 'Kamini', 'Bulla', NULL, '', 'Safari Park', '', '', '', '', NULL, '', '', '', '', '', '', '', '2025-04-29', '2025-04-29 00:19:05.437185', 'f', NULL, NULL, '1745913882759_Muph', '1745917161766_y4sG', 1018, true, false, '1745916652104_nBkM', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (44, '1746425916211_JIw5', 'test 800', 'father of test 800', '2000-05-02', '7812345679', 'new address test 800', '89067', '789012345678', '9078456723', '7812345679', 'english', 'MCA', '127803456712', 'SBI account name ', 'sbi bank name ', NULL, '9777', NULL, '2025-05-04', '2025-05-04 23:18:36.245095', 'm', 28, 0, '1746254533149_avX8', '1746426860804_UPg0', 1023, true, false, '1746255290760_sJ6b', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (40, '1745990715086_jE6N', 'safdsa', 'sdsa', '2004-02-05', NULL, 'STPI Jodpur', '342001', '907856342312', '7912345678', NULL, NULL, NULL, '907856341234', 'SBI', 'SBI head ', 'hello', '7890io', NULL, '2025-04-29', '2025-04-30 05:28:40.223', 'm', NULL, 0, NULL, '1745917161766_y4sG', 1019, true, false, '1745408461239_rXWf', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (18, '1745561869364_dnj1', 'Jay', 'JP', '2025-04-08', '1235647890', 'STPI', '342008', '2569874562', '9875641230', '8975642301', 'en', 'BSC', '1346579872224', 'Savings', 'Kotak', 'Something', 'VVF52158', 'Check', '2025-04-24', '2025-05-02 12:02:45.749', 'm', 28, 20, '1745913882759_Muph', '1745917161766_y4sG', 1003, true, false, '1745916652104_nBkM', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (36, '1745908872742_uMxz', 'Mark', 'Meta', '2002-04-01', '5569887426', 'Android', '', '', '', '', NULL, '', '', '', '', '', '', '', '2025-04-28', '2025-04-28 23:41:12.78229', 'm', 18, 22, '1745924133662_JsXo', '1745917161766_y4sG', 1015, true, false, '1745916652104_nBkM', 3) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (43, '1746253935410_1YWx', 'kirti', 'father of kirti', '2002-05-12', '6078563451', 'my address 12334', '1234', '5078563451', '6078563451', '7078563451', 'Hindi', 'MCA', '90456789231', 'yash ', 'yono', 'sbi branch_name', '5678jk', 'good', '2025-05-02', '2025-05-02 23:32:15.440277', 'f', 12, 5, NULL, NULL, 1022, true, false, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (27, '1745843533056_95ib', 'aaaaaa', 'sdsa', NULL, NULL, 'dsfs', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-04-28', '2025-04-28 05:32:13.095765', 'm', NULL, NULL, '1745904959485_a98x', '1745917161766_y4sG', 1006, true, false, '1745916652104_nBkM', 2) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (41, '1746253746367_4k5L', 'ankit sir', 'father of ankit sir', '2002-05-12', '6078563451', 'my address', '1234', '9078563451', '8078563451', '7078563451', 'English', 'MCA', '90456789231', 'ankit ', 'SBI', 'sbi branch_name', '45678', 'good', '2025-05-02', '2025-05-02 23:29:06.409589', 'm', 12, 5, '1746254533149_avX8', '1746255534831_uUSx', 1020, true, false, '1746255290760_sJ6b', 1) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (45, '1746426071562_3jUC', 'test 801', 'father of test 801', '2003-05-13', '8012345678', 'new address 801', '7890', '234567890123', '6734237819', '5678234579', 'english', 'MCA', '8912345678912', 'hdfc account', 'hdfc bank name', NULL, '4444', NULL, '2025-05-04', '2025-05-04 23:21:11.589723', 'f', 28, 1, '1746254533149_avX8', '1746426860804_UPg0', 1024, true, false, '1746255290760_sJ6b', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (47, '1746443389168_wvVB', 'test 803', 'father of test 803', '2004-05-02', '9078563412', 'new test 803 address', '8906', '789012345689', '4567890123', '7834512906', 'hindi', 'MCA', '89123456789056', 'hdfc account', 'hdfc bank', NULL, '7890', NULL, '2025-05-05', '2025-05-05 04:09:49.193916', 'f', 28, 4, '1746254533149_avX8', '1746426860804_UPg0', 1026, true, false, '1746255290760_sJ6b', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (42, '1746253859848_sDcB', 'yash sir', 'father of yash sir', '2002-05-12', '6078563451', 'my address 12334', '1234', '5078563451', '6078563451', '7078563451', 'Hindi', 'BCA', '90456789231', 'yash ', 'hdfc', 'sbi branch_name', '1234gh', 'good', '2025-05-02', '2025-05-03 07:37:01.478', 'f', 12, 5, '1746254533149_avX8', '1746255534831_uUSx', 1021, true, true, '1746255290760_sJ6b', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (49, '1746444490504_qVIo', 'test 805', 'father test 805', '2006-05-03', '12341234125', 'test 805 new address ', '905678', '655374567467', '52345245', '523462356245', 'gujrati', 'MCA', '45234514523462344', 'icci account', 'icci bank', NULL, '23462', NULL, '2025-05-05', '2025-05-05 04:28:10.529385', 'm', 28, 8, '1746254533149_avX8', '1746426860804_UPg0', 1028, true, false, '1746255290760_sJ6b', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (50, '1746444660804_396Z', 'test 806', 'father test 806', '2004-02-10', '234523642356', 'new test address 806', '1234', '45634563456346', '462536435634', '2345125423', 'hindi', 'MCA', '2435234356356', 'sbi account ', 'sbi bank ', NULL, '5678', NULL, '2025-05-05', '2025-05-05 04:31:00.831378', 'f', 28, 7, '1746254533149_avX8', '1746426860804_UPg0', 1029, true, false, '1746255290760_sJ6b', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (51, '1746518617037_M5U2', 'test 807', 'test of father 807', '2002-05-09', '34567846737', 'new address 807', '5678', '6578245135542346', '155634563467', '456743562', 'gujrati', 'MCA', '345631452345563', 'hdfc account ', 'hdfc bank ', NULL, '1234', NULL, '2025-05-06', '2025-05-06 01:03:37.100635', 'f', 28, 8, '1746254533149_avX8', '1746426860804_UPg0', 1030, true, false, '1745916652104_nBkM', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (53, '1746606411407_VgzJ', 'test 809', 'test father 809', '1995-08-17', '7890452310', 'new address test 809', '45678', '457890123456', '9078563412', '9078563423', 'english', 'MCA', '907856341278', 'sbi aacount name ', 'sbi bank', NULL, '6789', NULL, '2025-05-07', '2025-05-07 01:26:51.43214', 'f', 28, 8, '1746254533149_avX8', '1746426860804_UPg0', 1032, true, false, '1745408556650_JLad', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (52, '1746606283505_FkH7', 'test 808', 'test 808', '2005-03-24', '4578901234', 'address 808', '6789', '894567892345', '90778564534', '9834567890', 'english', 'MCA', '907834567812', 'test 808 account name ', 'sbi bank name ', NULL, '8234', NULL, '2025-05-07', '2025-05-07 01:24:43.531929', 'm', 28, 5, '1746254533149_avX8', '1746426860804_UPg0', 1031, true, false, '1745408556650_JLad', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (54, '1746678336813_nC66', 'test 809', 'father of test 809', '2025-05-08', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-05-07', '2025-05-07 21:25:36.874624', 'm', NULL, NULL, NULL, NULL, 1033, true, false, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (55, '1746683518400_MruS', 'test 810 test', 'father of test 810', '2006-06-07', '857394456830', 'new address 810', '8901', '8901234567', '7890123456', '9012345679', 'gujrati', 'MCA', '28799999999682344', 'sbi account ', 'sbi bank ', NULL, '5678', NULL, '2025-05-07', '2025-05-08 05:54:44.512', 'm', 28, 1, '1746254533149_avX8', '1746426860804_UPg0', 1034, true, false, '1746255290760_sJ6b', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (57, '1746687479462_vG8A', 'test 812', 'father 812', '2004-02-03', NULL, 'test address 812', '1234', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-05-07', '2025-05-07 23:57:59.494374', 'm', 28, 1, NULL, NULL, 1036, true, false, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (56, '1746687385730_2q28', 'test 811', 'father 811', '2002-05-03', '45678', 'mandore', '1234', '9078563423', '1234', '9078563423', 'english', 'MCA', '45678', 'sbi account ', 'sbi bank ', NULL, '8901', NULL, '2025-05-07', '2025-05-07 23:56:25.768314', 'm', 28, 3, '1746254533149_avX8', '1746426860804_UPg0', 1035, true, false, '1746255290760_sJ6b', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (59, '1746690788331_5XU2', 'test 821', 'father of 820', '2025-05-08', NULL, 'new test address 820', '1234', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-05-08', '2025-05-08 00:53:08.360634', 'm', 28, 5, '1745924133662_JsXo', '1746426860804_UPg0', 1038, true, false, '1745916652104_nBkM', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (58, '1746690524056_6AAt', 'test 820', 'father 820', '2004-06-09', NULL, 'test 820', '1234', '9078563423', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-05-08', '2025-05-08 00:48:44.094463', 'm', 28, 16, '1746254533149_avX8', '1746426860804_UPg0', 1037, true, false, '1745916652104_nBkM', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (60, '1746691140067_JYcf', 'test 821', 'father of 821', '2004-03-03', NULL, 'new address test 821', '1234', '9078563423', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-05-08', '2025-05-08 00:59:00.09477', 'f', 28, 2, '1746254533149_avX8', '1746255534831_uUSx', 1039, true, false, '1745408556650_JLad', 0) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (62, '1746694865935_LALz', 'test 823', 'father 823', '2025-05-09', '5678', 'STPI', '9078563423', '9078563423', '9078563423', '45678', 'gujrati', 'MCA', '9078563423', 'sbi account ', 'sbi bank ', NULL, '5678', NULL, '2025-05-08', '2025-05-08 02:01:05.97362', 'f', 12, 2, NULL, NULL, 1041, true, false, NULL, NULL) ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, roll_no, is_active, is_deleted, center, faculty) VALUES (61, '1746694815096_sEZV', 'test 822', 'test father 822', '2004-09-02', '467467256', 'new address 822', '5678', '34456234634', '356313563', '74567467', 'hindi', 'MCA', '66745675467', 'hdfc account ', 'hdfc bank ', NULL, '5678', NULL, '2025-05-08', '2025-05-08 02:00:15.132175', 'm', 28, 1, '1745914936065_eHuF', '1746255534831_uUSx', 1040, true, false, '1745476357636_H7j1', 0) ON CONFLICT DO NOTHING;


--
-- TOC entry 5056 (class 0 OID 46588)
-- Dependencies: 245
-- Data for Name: test29branch; Type: TABLE DATA; Schema: shikshanboard; Owner: postgres
--

INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (11, '1745912385996_J5fr', 'Banglore', 'Ramesh Ji Gundecha', 'Gundecha & Co.
No. 72, IInd Floor, Subhash Complex, Avenue Road
BANGLORE - 2 (Kar.)', 0, '9845499907, 990', '2017-10-30 14:18:33', '2025-04-29 07:39:45.996', true, false, '', '', '', 'Rakesh Ji Gundecha', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (12, '1745912386001_5tPB', 'Hyderabad', 'Shantilal Ji Gundecha', 'Andhra Jain Swadhyay Sangh
3-4-1022-1023, Punam Chand Jain Dharamshala
Opp. Kachigudda Station,  HYDERABAD (A.P.) - 500010
', 0, '9247199931', '2017-10-30 14:18:33', '2025-04-29 07:39:46.001', true, false, '040', '27567469', '27421322', 'Shantilal Ji', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (13, '1745912386002_2xA6', 'CHENNAI', 'Suresh Ji Chordia', 'chennai', 0, '', '2017-10-30 14:18:33', '2025-04-29 07:39:46.002', true, false, '', '', '', 'suresh', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (14, '1745912386003_CHxU', 'Jalgaon', 'Manoj Sanchati', 'Shri Mahaveer Jain Swadyay Vidhyapeet, Opp. Vanketesh Mandir, Ganpati Nagar, JALGAON - 425001 (Mah.)', 0, '9422591423', '2017-10-30 14:18:33', '2025-04-29 07:39:46.003', true, false, '0257', '2232315', '', 'Manoj ', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (15, '1745912386004_DfJY', 'Mumbai', 'Dilkush Ji Mehta', '7/101 Sidharth Nagar IV
GOREGAON (West)
Mumbai (Mah.) - 400062
', 0, '93244-55221', '2017-10-30 14:18:33', '2025-04-29 07:39:46.004', true, false, '022', '28755221', '', 'Dilkhush Ji Mehta', 'aby.d.jain@gmail.com', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (16, '1745912386005_NsRm', 'Nagpur', 'Lalita Ji Bafna', 'SMT. LALITA JI BAFNA
205, Jagat Chamber, Ambedkar Square,
Back Side Of Groba Ground
NAGPUR (Mah.) - 440002
', 0, '', '2017-10-30 17:38:24', '2017-10-30 12:04:42', true, false, '0712', '2730965', '', 'Lalita Ji', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (17, '1745912386005_Us8k', 'Dhuliya', 'Kantilal Ji Choudhary', 'SH. KANTILAL JI CHOUDHARY
1886, Kanti Complex, 4th Lane
DHULIA (Mah.) - 424001
', 0, '', '2017-10-30 14:18:33', '2025-04-29 07:39:46.005', true, false, '02562', '232094', '234309', 'Kantilal Ji Choudhary', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (18, '1745912386006_VILZ', 'Nashik', 'Sundeep Ji Chordia', 'SH. SANDEEP A CHORDIA
N-10-M-1/21/4 Rana Pratap Chowk, New Sidco
NASHIK (Mah.) - 422009
', 0, '98230-85969 ', '2017-10-30 14:18:33', '2025-04-29 07:39:46.006', true, false, '0253', '2393698', '2376949', 'Sundeep Ji Chordia', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (19, '1745912386007_mnLJ', 'AHMEDABAD', 'ASHA JI MEHTA', 'C/o Rajasthani Jain Sthanakvasi Upashrya
Opp. Hari Singh Jain Mandir
Dilli Darwaza, Shahibag, 
AHMEDABAD (Guj.) - 380004
', 0, '9898085547', '2017-10-30 14:18:33', '2025-04-29 07:39:46.007', true, false, '079', '22865547', '', 'ASHA JI MEHTA', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (20, '1745912386008_ns8x', 'Indore', 'Mandanlal Ji Bodana', 'SH. MADHYAPRADESH JAIN SWADHYAY SANGH
Sh. Madan Lal Ji Bodana, Bodana Enterprises
Gulab Kunj, 151/7  Imli Bazar
INDORE (M.P.) - 452004
', 0, '98270-90301', '2017-10-30 14:18:33', '2025-04-29 07:39:46.008', true, false, '0731', '2533017', '2534581', 'Madanlal Ji Bodana', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (21, '1745912386009_ZFxS', 'Chatisgarh', 'Manju Ji Surana', 'MRS. MANJU JI W/O SH. M.M.SURANA
2/5 Priyadarshini Parisar, 27 Civil Centre
Post - BHILAI
Dist. - Chatisgarh (Cg.) - 490006
', 0, '098932-73327', '2017-10-30 14:18:33', '2025-04-29 07:39:46.009', true, false, '0788', '2292327', '5033699', 'Manju Ji Surana', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (22, '1745912386009_JfTN', 'Hoshiyarpur', 'Kiran Ji Jain', 'SMT. KIRAN JI JAIN W/0 SH. NAVNEET KUMAR JI JAIN
Jain Colony
Bhairwai Road
Hoshiyarpur (Punjab) - 146001
', 0, '94630-10026', '2017-10-30 14:18:33', '2025-04-29 07:39:46.009', true, false, '01882', '232108', '238314', 'Kiran Ji Jain', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (23, '1745912386010_VrJ2', 'JODHPUR', 'A.S.Board', 'A.B.S. Jain Ratna A. S. Board
Goron Ka chowk, Jodhpur - 342001', 0, '9414128925', '2017-10-30 14:18:33', '2025-04-29 07:39:46.01', true, false, '0291', '2630490', '2636763', 'A.S.B.', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (24, '1745912386011_1NHq', 'JAIPUR', 'Ashok Ji Seth', 'SH. ASHOK JI SETH
2337, Ramlalla Ji Ka Rasta
Johari Bazar
JAIPUR (Raj.) - 302003
', 0, '9314517679', '2017-10-30 14:18:33', '2025-04-29 07:39:46.011', true, false, '0141', '2570214 ', '9414071655', 'Ashok Ji Seth', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (25, '1745912386012_Hqva', 'SAWAI MADHOPUR', 'Laloo Lal Ji Jain', '9460441587', 15, '9460441587', '2022-07-15 06:59:31', '2022-07-15 06:59:31', true, false, '07462', '234680', '', 'Laloo Lal Ji Jain', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (26, '1745912386012_kxX9', 'Mahaveer ji', 'Mahaveer Prasad Ji Jain', 'Jain Colony, Subhlaxmi Mills
Near Bhatte, 
Gangapurcity - 322201 
Dist. - Swaimadhopur (Raj.)', 0, '9460951507', '2017-10-30 14:18:33', '2025-04-29 07:39:46.012', true, false, '', '', '', 'Mahaveer Prasad Ji Jain', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (27, '1745912386013_ZkvF', 'Bharatpur', 'Mahaveer Prasad Ji Jain', 'Jain Colony, Subhlaxmi Mills
Near Bhatte, 
Gangapurcity - 322201 
Dist. - Swaimadhopur (Raj.)', 0, '9460951507', '2017-10-30 14:18:33', '2025-04-29 07:39:46.013', true, false, '', '', '', 'Mahaveer Prasad Ji Jain', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (28, '1745912386014_aSfj', 'Hindoncity', 'Mahaveer Prasad Ji Jain', 'Jain Colony, Subhlaxmi Mills
Near Bhatte, 
Gangapurcity - 322201 
Dist. - Swaimadhopur (Raj.)', 0, '9460951507', '2017-10-30 14:18:33', '2025-04-29 07:39:46.014', true, false, '', '', '', 'Mahaveer Prasad Ji Jain', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (29, '1745912386015_2sOe', 'Bhilwara', 'Kanhaiya Lal Ji Jain', 'Satyam Suiting, 
119 Murli Towar, Pur Road
BHILWARA (Raj.)', 0, '9351311812', '2017-10-30 14:18:33', '2025-04-29 07:39:46.015', true, false, '', '', '', 'Kanhaiya Lal Ji Jain', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (30, '1745912386015_KAiN', 'BEAWER', 'Laxmichand Ji Bhandari', 'SH. LAXMICHAND JI BHANDARI8, Naya Bas, Post - BEAWER (Raj.) - 305901', 237, '94142-89111', '2024-03-18 10:55:41', '2024-03-18 05:25:41', true, false, '01462', '257342(O)', '255243', 'Laxmichand Ji Bhandari', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (31, '1745912386016_hZUI', 'Kolahar Bhagwati', 'Jaishree Ji', 'SMT. JAISHREE, DHANSUKHLAL JI RANKA
C/o - Ravindra Medical Store
Post - KOLHAR
Tah. - Rahta, Dist. - Ahmednagar (Mah.) - 413710
', 0, '', '2017-10-30 14:18:33', '2025-04-29 07:39:46.016', true, false, '02422', '251718', '', 'Jaishree Ji', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (32, '1745912386017_AqV3', 'BALOTRA', 'Dharmesh Ji Chopra', 'SH. DHARMESH KUMAR JI CHOPRA
C/o - Sh. Roopkumar Mohanlal Ji Chopra
Kansaro Ka Bas
BALOTRA, Dist. - Barmer (Raj.) - 344022
', 0, '94141-08191', '2017-10-30 14:18:33', '2025-04-29 07:39:46.017', true, false, '02988', '220191', '', 'Dharmesh Ji Chopra', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (33, '1745912386018_dJiQ', 'Kanpur', 'Daulatram Ji Jain', 'Shri Jain Swetaber Sthanakwasi Sangh
Mata Rukmani Bhawan
46/73, Khoya Bazar, Hatia
Kanpur - 208001 (U.P.)', 0, '9336273301', '2017-10-30 14:18:33', '2025-04-29 07:39:46.018', true, false, '0512', '2612974', '9450347863', 'Daulatram Ji Jain', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (34, '1745912386020_rRVa', 'Ichalkaranji', 'JAWAHAR LAL JI', 'SH. / CHANDMAL JI BOHRA
Ajanta Fabrics ,9/507 Bohra Bhawan, Near Gayatri Bhawan
Post - ICHALKARANJI
Dist. - Kolhapur (Mah.) - 416115
', 0, '2433056 (Fax)', '2017-10-30 14:18:33', '2025-04-29 07:39:46.02', true, false, '0230', '2434249', '2436820', 'Jawaharlal Ji', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (35, '1745912386021_wXYY', 'Amrawati', '', '', 0, '', '2017-10-30 14:18:33', '2025-04-29 07:39:46.021', true, false, NULL, '', '', '', '', NULL, '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (36, '1745912386022_QZ8Y', 'Misc.', '', '', 0, '', '2017-10-30 14:18:33', '2025-04-29 07:39:46.022', true, false, '', '', '', '', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (37, '1745912386022_REar', 'Kerala', '', '', 0, '', '2017-10-30 14:18:33', '2025-04-29 07:39:46.022', true, false, '', '', '', '', '', '673006', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (38, '1745912386023_G31y', 'GangaKhed', '', '', 0, '', '2017-10-30 14:18:33', '2025-04-29 07:39:46.023', true, false, '', '', '', '', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (39, '1745912386023_EpDG', 'Udaipur', '', '', 0, '', '2017-10-30 14:18:33', '2025-04-29 07:39:46.023', true, false, '', '', '', '', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (40, '1745912386024_BTZM', 'U.S.A.', '', '', 0, '', '2017-11-27 09:30:38', '2017-11-27 09:30:38', true, false, '', '', '', '', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (41, '1745912386025_RMM6', 'Other', '', '', 0, '', '2017-10-30 14:18:33', '2025-04-29 07:39:46.025', true, false, '', '', '', '', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (42, '1745912386025_EaNA', 'Himachal Pradesh', '', '', 0, '', '2017-10-30 14:18:33', '2025-04-29 07:39:46.026', true, false, '', '', '', '', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (43, '1745912386026_meRq', 'Karnataka', '', '', 0, '', '2017-10-30 14:18:33', '2025-04-29 07:39:46.026', true, false, '', '', '', '', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (44, '1745912386027_bSIr', 'Pune', '', '', 0, '', '2017-10-30 14:18:33', '2025-04-29 07:39:46.027', true, false, '', '', '', '', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (45, '1745912386027_2C96', 'Delhi', '', '', 0, '', '2017-10-30 14:18:33', '2025-04-29 07:39:46.027', true, false, '', '', '', '', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (46, '1745912386028_Drye', 'Ahmed Nagar', '', '', 0, '', '2017-10-30 14:18:33', '2025-04-29 07:39:46.028', true, false, '', '', '', '', '', '', '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (47, '1745912386029_zB1F', 'HARYANA', '.', '.', 217, '', '2019-06-28 10:37:04', '2025-04-29 07:39:46.029', true, false, NULL, '', '', '', '', NULL, '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (48, '1745912386029_Tt4p', 'GUJRAT', '.', '.', 218, '', '2019-07-04 10:20:33', '2025-04-29 07:39:46.029', true, false, NULL, '', '', '', '', NULL, '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (49, '1745912386030_uDfw', 'AURANGABAD', '.', '.', 202, '', '2019-07-04 10:30:24', '2025-04-29 07:39:46.03', true, false, NULL, '', '', '', '', NULL, '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (50, '1745912386031_Wvq4', 'MANDI DABVALI', '.', '.', 109, '', '2024-03-18 08:36:41', '2024-03-18 03:06:41', true, false, NULL, '', '', '', '', NULL, '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (51, '1745912386032_DMy2', 'RATNAGIRI', '.', '.', 199, '', '2019-07-04 10:36:11', '2025-04-29 07:39:46.032', true, false, NULL, '', '', '', '', NULL, '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (52, '1745912386032_LEku', 'KOTA', '.', '.', 124, '', '2019-07-04 10:41:18', '2025-04-29 07:39:46.032', true, false, NULL, '', '', '', '', NULL, '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (53, '1745912386033_t4XS', 'YAVATMAL', '.', '.', 57, '', '2019-07-04 10:55:47', '2025-04-29 07:39:46.033', true, false, NULL, '', '', '', '', NULL, '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (54, '1745912386034_Ot4H', 'SHOLAPUR', '.', '.', 74, '', '2019-07-04 10:58:52', '2025-04-29 07:39:46.034', true, false, NULL, '', '', '', '', NULL, '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (55, '1745912386035_dx2J', 'BULDHANA', '.', '.', 65, '', '2019-07-04 11:19:08', '2025-04-29 07:39:46.035', true, false, NULL, '', '', '', '', NULL, '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (56, '1745912386035_UJm0', 'MADHYA PRADESH', '.', '.', 49, '.', '2019-07-06 10:15:17', '2025-04-29 07:39:46.035', true, false, NULL, '', '', '', '', NULL, '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (57, '1745912386036_T3eI', 'KARHI', '.', '.', 49, '', '2019-07-06 10:21:01', '2025-04-29 07:39:46.036', true, false, NULL, '', '', '', '', NULL, '', '', '') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.test29branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted, head_stdcode, head_phone, head_ophone, head_mname, head_maddress, head_mstdcode, head_mphone, head_mophone, head_mmobile) VALUES (58, '1745912386037_Vz5V', 'AKOLA', '.', '.', 87, '', '2019-07-06 10:44:51', '2025-04-29 07:39:46.037', true, false, NULL, '', '', '', '', NULL, '', '', '') ON CONFLICT DO NOTHING;


--
-- TOC entry 5028 (class 0 OID 45962)
-- Dependencies: 217
-- Data for Name: users; Type: TABLE DATA; Schema: shikshanboard; Owner: postgres
--

INSERT INTO shikshanboard.users (id, row_id, user_name, user_password, cr_on, up_on) VALUES (2, '1745746793263_tFfH', 'rahul', 'rahul123', '2025-04-27 15:09:53.466531', '2025-04-27 15:09:53.466531') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.users (id, row_id, user_name, user_password, cr_on, up_on) VALUES (1, '1745304026572_qLJa', 'abhishek', '1234', '2025-04-21 23:40:26.632186', '2025-04-28 08:00:37.831') ON CONFLICT DO NOTHING;
INSERT INTO shikshanboard.users (id, row_id, user_name, user_password, cr_on, up_on) VALUES (3, '1745836639992_vMdj', 'admin', 'Admin@2025', '2025-04-28 03:37:20.030278', '2025-05-03 07:34:07.674') ON CONFLICT DO NOTHING;


--
-- TOC entry 5084 (class 0 OID 0)
-- Dependencies: 220
-- Name: attendance_id_seq; Type: SEQUENCE SET; Schema: shikshanboard; Owner: postgres
--

SELECT pg_catalog.setval('shikshanboard.attendance_id_seq', 55, true);


--
-- TOC entry 5085 (class 0 OID 0)
-- Dependencies: 238
-- Name: bandals_id_seq; Type: SEQUENCE SET; Schema: shikshanboard; Owner: postgres
--

SELECT pg_catalog.setval('shikshanboard.bandals_id_seq', 59, true);


--
-- TOC entry 5086 (class 0 OID 0)
-- Dependencies: 234
-- Name: branch_id_seq; Type: SEQUENCE SET; Schema: shikshanboard; Owner: postgres
--

SELECT pg_catalog.setval('shikshanboard.branch_id_seq', 12, true);


--
-- TOC entry 5087 (class 0 OID 0)
-- Dependencies: 236
-- Name: centers_id_seq; Type: SEQUENCE SET; Schema: shikshanboard; Owner: postgres
--

SELECT pg_catalog.setval('shikshanboard.centers_id_seq', 14, true);


--
-- TOC entry 5088 (class 0 OID 0)
-- Dependencies: 232
-- Name: classes_id_seq; Type: SEQUENCE SET; Schema: shikshanboard; Owner: postgres
--

SELECT pg_catalog.setval('shikshanboard.classes_id_seq', 10, true);


--
-- TOC entry 5089 (class 0 OID 0)
-- Dependencies: 222
-- Name: copy_checkers_id_seq; Type: SEQUENCE SET; Schema: shikshanboard; Owner: postgres
--

SELECT pg_catalog.setval('shikshanboard.copy_checkers_id_seq', 12, true);


--
-- TOC entry 5090 (class 0 OID 0)
-- Dependencies: 246
-- Name: event_id_seq; Type: SEQUENCE SET; Schema: shikshanboard; Owner: postgres
--

SELECT pg_catalog.setval('shikshanboard.event_id_seq', 3, true);


--
-- TOC entry 5091 (class 0 OID 0)
-- Dependencies: 230
-- Name: exam_sessions_id_seq; Type: SEQUENCE SET; Schema: shikshanboard; Owner: postgres
--

SELECT pg_catalog.setval('shikshanboard.exam_sessions_id_seq', 24, true);


--
-- TOC entry 5092 (class 0 OID 0)
-- Dependencies: 224
-- Name: marks_id_seq; Type: SEQUENCE SET; Schema: shikshanboard; Owner: postgres
--

SELECT pg_catalog.setval('shikshanboard.marks_id_seq', 68, true);


--
-- TOC entry 5093 (class 0 OID 0)
-- Dependencies: 226
-- Name: merit_list_id_seq; Type: SEQUENCE SET; Schema: shikshanboard; Owner: postgres
--

SELECT pg_catalog.setval('shikshanboard.merit_list_id_seq', 1, false);


--
-- TOC entry 5094 (class 0 OID 0)
-- Dependencies: 228
-- Name: online_forms_id_seq; Type: SEQUENCE SET; Schema: shikshanboard; Owner: postgres
--

SELECT pg_catalog.setval('shikshanboard.online_forms_id_seq', 1, false);


--
-- TOC entry 5095 (class 0 OID 0)
-- Dependencies: 241
-- Name: samplebook_id_seq; Type: SEQUENCE SET; Schema: shikshanboard; Owner: postgres
--

SELECT pg_catalog.setval('shikshanboard.samplebook_id_seq', 3, true);


--
-- TOC entry 5096 (class 0 OID 0)
-- Dependencies: 243
-- Name: samplepaper_id_seq; Type: SEQUENCE SET; Schema: shikshanboard; Owner: postgres
--

SELECT pg_catalog.setval('shikshanboard.samplepaper_id_seq', 3, true);


--
-- TOC entry 5097 (class 0 OID 0)
-- Dependencies: 248
-- Name: student_exam_mappings_id_seq; Type: SEQUENCE SET; Schema: shikshanboard; Owner: postgres
--

SELECT pg_catalog.setval('shikshanboard.student_exam_mappings_id_seq', 1, false);


--
-- TOC entry 5098 (class 0 OID 0)
-- Dependencies: 218
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: shikshanboard; Owner: postgres
--

SELECT pg_catalog.setval('shikshanboard.students_id_seq', 62, true);


--
-- TOC entry 5099 (class 0 OID 0)
-- Dependencies: 244
-- Name: test29branch_id_seq; Type: SEQUENCE SET; Schema: shikshanboard; Owner: postgres
--

SELECT pg_catalog.setval('shikshanboard.test29branch_id_seq', 58, true);


--
-- TOC entry 5100 (class 0 OID 0)
-- Dependencies: 216
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: shikshanboard; Owner: postgres
--

SELECT pg_catalog.setval('shikshanboard.users_id_seq', 3, true);


--
-- TOC entry 4846 (class 2606 OID 46137)
-- Name: attendance attendance_pkey; Type: CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.attendance
    ADD CONSTRAINT attendance_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4864 (class 2606 OID 46330)
-- Name: bandals bandals_pkey; Type: CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.bandals
    ADD CONSTRAINT bandals_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4860 (class 2606 OID 46282)
-- Name: branch branch_pkey; Type: CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.branch
    ADD CONSTRAINT branch_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4862 (class 2606 OID 46293)
-- Name: centers centers_pkey; Type: CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.centers
    ADD CONSTRAINT centers_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4858 (class 2606 OID 46271)
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4848 (class 2606 OID 46153)
-- Name: copy_checkers copy_checkers_pkey; Type: CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.copy_checkers
    ADD CONSTRAINT copy_checkers_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4872 (class 2606 OID 46619)
-- Name: event event_pkey; Type: CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.event
    ADD CONSTRAINT event_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4856 (class 2606 OID 46247)
-- Name: exam_sessions exam_sessions_pkey; Type: CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.exam_sessions
    ADD CONSTRAINT exam_sessions_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4850 (class 2606 OID 46180)
-- Name: marks marks_pkey; Type: CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.marks
    ADD CONSTRAINT marks_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4852 (class 2606 OID 46201)
-- Name: merit_list merit_list_pkey; Type: CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.merit_list
    ADD CONSTRAINT merit_list_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4854 (class 2606 OID 46217)
-- Name: online_forms online_forms_pkey; Type: CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.online_forms
    ADD CONSTRAINT online_forms_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4866 (class 2606 OID 46378)
-- Name: samplebook samplebook_pkey; Type: CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.samplebook
    ADD CONSTRAINT samplebook_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4868 (class 2606 OID 46380)
-- Name: samplepaper samplepaper_pkey; Type: CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.samplepaper
    ADD CONSTRAINT samplepaper_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4874 (class 2606 OID 46646)
-- Name: student_exam_mappings student_exam_mappings_pkey; Type: CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.student_exam_mappings
    ADD CONSTRAINT student_exam_mappings_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4844 (class 2606 OID 46126)
-- Name: students students_pkey; Type: CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4870 (class 2606 OID 46599)
-- Name: test29branch test29branch_pkey; Type: CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.test29branch
    ADD CONSTRAINT test29branch_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4842 (class 2606 OID 45971)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4875 (class 2606 OID 46138)
-- Name: attendance attendance_student_row_id_fkey; Type: FK CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.attendance
    ADD CONSTRAINT attendance_student_row_id_fkey FOREIGN KEY (student_row_id) REFERENCES shikshanboard.students(row_id) ON DELETE CASCADE;


--
-- TOC entry 4881 (class 2606 OID 46331)
-- Name: bandals bandals_copy_checker_id_fkey; Type: FK CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.bandals
    ADD CONSTRAINT bandals_copy_checker_id_fkey FOREIGN KEY (copy_checker_id) REFERENCES shikshanboard.copy_checkers(row_id) ON DELETE SET NULL;


--
-- TOC entry 4882 (class 2606 OID 46336)
-- Name: bandals bandals_student_row_id_fkey; Type: FK CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.bandals
    ADD CONSTRAINT bandals_student_row_id_fkey FOREIGN KEY (student_row_id) REFERENCES shikshanboard.students(row_id) ON DELETE CASCADE;


--
-- TOC entry 4880 (class 2606 OID 46294)
-- Name: centers centers_branch_id_fkey; Type: FK CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.centers
    ADD CONSTRAINT centers_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES shikshanboard.branch(row_id) ON DELETE CASCADE;


--
-- TOC entry 4876 (class 2606 OID 46186)
-- Name: marks marks_copy_checker_id_fkey; Type: FK CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.marks
    ADD CONSTRAINT marks_copy_checker_id_fkey FOREIGN KEY (copy_checker_id) REFERENCES shikshanboard.copy_checkers(row_id) ON DELETE SET NULL;


--
-- TOC entry 4877 (class 2606 OID 46181)
-- Name: marks marks_student_row_id_fkey; Type: FK CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.marks
    ADD CONSTRAINT marks_student_row_id_fkey FOREIGN KEY (student_row_id) REFERENCES shikshanboard.students(row_id) ON DELETE CASCADE;


--
-- TOC entry 4878 (class 2606 OID 46202)
-- Name: merit_list merit_list_student_row_id_fkey; Type: FK CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.merit_list
    ADD CONSTRAINT merit_list_student_row_id_fkey FOREIGN KEY (student_row_id) REFERENCES shikshanboard.students(row_id) ON DELETE CASCADE;


--
-- TOC entry 4879 (class 2606 OID 46218)
-- Name: online_forms online_forms_student_row_id_fkey; Type: FK CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.online_forms
    ADD CONSTRAINT online_forms_student_row_id_fkey FOREIGN KEY (student_row_id) REFERENCES shikshanboard.students(row_id) ON DELETE CASCADE;


--
-- TOC entry 4883 (class 2606 OID 46647)
-- Name: student_exam_mappings student_exam_mappings_student_row_id_fkey; Type: FK CONSTRAINT; Schema: shikshanboard; Owner: postgres
--

ALTER TABLE ONLY shikshanboard.student_exam_mappings
    ADD CONSTRAINT student_exam_mappings_student_row_id_fkey FOREIGN KEY (student_row_id) REFERENCES shikshanboard.students(row_id) ON DELETE CASCADE;


-- Completed on 2025-05-09 17:34:23

--
-- PostgreSQL database dump complete
--

