import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';

@Component({
  selector: 'app-view-videonotes',
  imports: [MatDialogModule,MatButtonModule],
  templateUrl: './view-videonotes.component.html',
  styleUrl: './view-videonotes.component.scss'
})
export class ViewVideonotesComponent {

}
