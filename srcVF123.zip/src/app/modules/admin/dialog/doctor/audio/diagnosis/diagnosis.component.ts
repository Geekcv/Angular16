import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { FormPreviewComponent } from 'app/modules/admin/formBuilder/components/form-preview/form-preview.component';
import { config } from '../../../../../../../../config';

interface FormElement {
  type: string;
  label: string;
  placeholder?: string;
  rows?: any;
  cols?: any
  min?: any
  max?: any
  optionsdropdown?: Array<{ label: string, value: string }>;// Dropdown options,
  optionsradio?: Array<{ label: string, value: string }>;
  optionscheckbox?: Array<{ label: string, value: string }>
  layout?: 'vertical' | 'horizontal';
  required?: boolean;
  address?:any[];
  accept?:string;
  key?:any;
  searchText?:any;
  filteredOptions?:any;
    


}

interface FormsSchemaData {
  // forms_row_id:any;
  form_link: any;
}

@Component({
  selector: 'app-diagnosis',
  imports: [ MatDialogModule,MatButtonModule,FormPreviewComponent],
  templateUrl: './diagnosis.component.html',
  styleUrl: './diagnosis.component.scss'
})
export class DiagnosisComponent {

  formItems: FormElement[] = [];
  formsdata: FormsSchemaData[];


  tablename:string;
     config: string = config.apiBaseURL;
  

media_data:any

 constructor(
      @Inject(MAT_DIALOG_DATA) public data: {medialink: string,mediadata:any},
          private dialogRef: MatDialogRef<DiagnosisComponent>, // Inject MatDialogRef
                    private Apicontroller: ApicontrollerService
      
  ){
    this.showforms()
   this.media_data = data.mediadata
  }

  exitbtn(){

    this.dialogRef.close();
    this.media_data = this.data.mediadata

  }

  async showforms(){
    console.log('show forms data');

    const resp = await this.Apicontroller.loadForms('diagnosisforms');
    console.log("resp", resp[0].form_data)
    this.formItems = resp[0].form_data;

  }
}
