import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { ActivatedRoute, Router } from '@angular/router';
import { config } from '../../../../../../config';

@Component({
  selector: 'app-view-audiodetails',
  imports: [
     MatButtonModule,
        MatIconModule,
       CommonModule,
  ],
  templateUrl: './view-audiodetails.component.html'
})
export class ViewAudiodetailsComponent {
config: string = config.apiBaseURL;
    media_link:any;

    constructor(
      private router: Router,
                    private route: ActivatedRoute,
      
    ) {
      this.media_link = this.route.snapshot.paramMap.get('id');

    console.log("media_link",this.media_link)
    }

  goback(){
    // console.log("click this button")
    this.router.navigate(['/audionotestable'])
  }

  

}
