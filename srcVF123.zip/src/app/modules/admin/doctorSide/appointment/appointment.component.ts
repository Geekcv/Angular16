import { CommonModule } from '@angular/common';
import { Component, ViewEncapsulation } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTimepickerModule } from '@angular/material/timepicker';
import { ActivatedRoute } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

interface appointment {
    apt_row_id: string;
    date_of_apt: string;
    // date_of_req:string;
    doctor_name: string;
    user_contact_number: string;
    time_of_apt: string;
    // time_of_req:string;
    appointment_details: any;
    // appointment_details:{appt_status:any,appt_type:any,virtual_link:any};
    // updatedby_user_name:any
}

interface Patient {
    patient_age: string;
    patient_email: string;
    patient_gender: string;
    patient_name: string;
    user_contact_number: string;
    user_password: string;
    user_row_id: string;
}

@Component({
    selector: 'app-appointment',
    imports: [
        MatButtonModule,
        MatFormFieldModule,
        FormsModule,
        ReactiveFormsModule,
        MatInputModule,
        MatSelectModule,
        MatButtonModule,
        MatTimepickerModule,
        MatDatepickerModule,
        CommonModule,
    ],
    templateUrl: './appointment.component.html',
    encapsulation: ViewEncapsulation.None, // Add this line!
})
export class AppointmentComponent {
    value: Date;
    patients: Patient[] = [];

    selectedvalue: string;
    app_type: string = '';

    // slot: string = '';
    availableslot: string[] = ['Physical', 'Virtual'];

    isclicked = false;
    isviewbtn = false;

    row_id: any = '';
    toggle = false;

    timevalue: any;
    datevalue: any;

    isAddNewClicked: boolean = true;
    constructor(
        private route: ActivatedRoute,
        private apiController: ApicontrollerService
    ) {
        this.mydoctor();
    }

    async mydoctor() {
        try {
            const resp = await this.apiController.fetchPatients();

            //console.log("doctor", resp);
            this.patients = resp.data as Patient[]; // Type assert to Doctor[]
        } catch (error) {
            console.error('Error fetching doctors:', error);
        }
    }
    addnewbtn() {
        this.isclicked = true;
        this.isviewbtn = false; // Hide view when adding a new one
        //  this.toggle = true
        this.isAddNewClicked = !this.isAddNewClicked; // Toggle the button color
        this.selectedRow = null;
    }

    exitbtn() {
        this.isclicked = false;
        this.isviewbtn = false;

        this.isAddNewClicked = false;
    }

    selectedRow: any = null;

    viewbtn(appointmentdata: any, e: Event) {
        this.row_id = appointmentdata.apt_row_id;
        this.isviewbtn = true;
        this.isclicked = false; // Hide add new when viewing
        this.selectedRow = appointmentdata;

        this.isAddNewClicked = false;
    }

    patientsId!: string | null; // Holds the patientsId ID from the route
    appointmentdata: appointment[] = [];

    // appointment_details: appointmentDetails[]=[]

    appointmentColumns: string[] = [
        'apt_row_id',
        'date_of_apt',
        // 'date_of_req',
        'time_of_apt',
        // 'time_of_req',
        'appointment_status',
        'updatedby_user_type',

        'appointment_Type',
        'Action',
    ];

    patientDetails: Patient | null = null;
    patientdata: any;
    bookedDates: Date[] = [];
    selectedPatient: any;
    ngOnInit() {
        // console.log("patientsId",this.patientsId)
        this.patientsId = this.route.snapshot.paramMap.get('id');
    }

    selectedDate: Date;
    selectedTime: string;
    timeSlots: string[] = [
        '09:00 AM',
        '10:00 AM',
        '11:00 AM',
        '12:00 PM',
        '01:00 PM',
    ]; // Ensure this has values

    selectTime(slot: string) {
        console.log('Selected Slot:', slot, this.selectedDate);
        this.selectedTime = slot;
    }

    async requestAppointment() {
        // console.log("time value-",this.timevalue.toTimeString().split(' ')[0], "date value-",this.datevalue.toDateString())

        var data = {
            pat_row_id: this.patientdata.user_row_id,
            time_of_apt: this.selectedTime,
            date_of_apt: this.selectedDate,
            appt_type: this.app_type,
        };

        // console.log("patientdata--->",this,this.patientdata.us)

        console.log('data--->', data);
        const resp = await this.apiController.appointment(data);

        console.log('selectedDate:', this.selectedDate);
        console.log('bookedDateMap keys:', Object.keys(this.bookedDateMap));
        console.log('bookedTimeSlots:', this.bookedTimeSlots);
    }

    refresh() {
        console.log('refresh----');
        this.viewappointment();
        // window.location.reload();
    }

    bookedDateMap: { [key: string]: string[] } = {}; // slot times mapped to dates
    isAppointmentsLoaded: boolean = false;

    onPatientChange() {
        if (this.selectedPatient) {
            this.patientdata = this.selectedPatient;
            this.viewappointment(); // now reload appointments
        }
    }

    async viewappointment() {
        console.log(
            '          this.patientdata.user_row_id    ',
            this.patientdata
        );
        const resp1 = await this.apiController.fetchappointmentdoctor(
            this.patientdata
        );
        this.appointmentdata = resp1.data || [];
        this.bookedDateMap = {};

        for (const apt of this.appointmentdata) {
            const d = this.toLocalDateOnly(apt.date_of_apt);
            if (isNaN(d.getTime())) continue;

            const dateStr = d.toDateString();
            const formattedTime = this.formatTime(apt.time_of_apt);

            if (!this.bookedDateMap[dateStr]) {
                this.bookedDateMap[dateStr] = [];
            }
            this.bookedDateMap[dateStr].push(formattedTime);
        }

        console.log('✅ Loaded bookedDateMap:', this.bookedDateMap);

        this.isAppointmentsLoaded = true;
    }

    availableTimeSlots: string[] = [];
    bookedTimeSlots: string[] = [];

    // Called when user selects a date
    onDateChange(date: any): void {
        const d = this.toLocalDateOnly(date);
        this.selectedDate = d;

        const dateStr = d.toDateString();
        console.log('📅 Date changed to:', dateStr);
        console.log(
            '🔍 Booked slots for this date:',
            this.bookedDateMap[dateStr]
        );

        this.bookedTimeSlots = this.bookedDateMap?.[dateStr] || [];

        this.availableTimeSlots = this.timeSlots.filter(
            (slot) => !this.bookedTimeSlots.includes(slot)
        );
    }

    dateClass = (date: any): string => {
        const d = this.toLocalDateOnly(date);
        const str = d.toDateString();
        if (this.bookedDateMap[str]) {
            console.log('🎯 Highlighting date:', str);
            return 'booked-date';
        }
        return '';
    };

    // ✅ ADD this utility method
    toLocalDateOnly(dateInput: any): Date {
        const d = new Date(dateInput);
        return new Date(d.getFullYear(), d.getMonth(), d.getDate()); // strips time + timezone
    }

    // selectTime(slot: string) {
    //     if (!this.bookedTimeSlots.includes(slot)) {
    //         this.selectedTime = slot;
    //     }
    // }

    trackBySlot(index: number, item: string): string {
        return item;
    }

    formatTime(rawTime: string): string {
        const [hourStr, minuteStr] = rawTime.split(':');
        let hour = parseInt(hourStr, 10);
        const minutes = minuteStr?.padStart(2, '0') || '00';

        const ampm = hour >= 12 ? 'PM' : 'AM';
        hour = hour % 12 || 12;

        return `${hour.toString().padStart(2, '0')}:${minutes} ${ampm}`;
    }
}
