import { Component, inject } from '@angular/core';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonModule, NgFor } from '@angular/common';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { FormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { FormPreviewComponent } from '../components/form-preview/form-preview.component';

interface FormElement {
  type: string;
  label: string;
  placeholder?: string;
  rows?: any;
  cols?: any
  min?: any
  max?: any
  optionsdropdown?: Array<{ label: string, value: string }>;// Dropdown options,
  optionsradio?: Array<{ label: string, value: string }>;
  optionscheckbox?: Array<{ label: string, value: string }>
  layout?: 'vertical' | 'horizontal';
  required?: boolean;
  address?:any[];
  accept?:string;
  key?:any;
  searchText?:any;
  filteredOptions?:any;
    


}


interface formdata{
  form_data:any
}

interface FormsSchemaData {
  // forms_row_id:any;
  form_link: any;
}

@Component({
  selector: 'app-response',
  imports: [
     DragDropModule,
        CommonModule,
        FormsModule,
        MatInputModule,
        MatIconModule,
        FormPreviewComponent,
        MatTableModule
    
  ],
  templateUrl: './response.component.html',
  styleUrl: './response.component.scss'
})
export class ResponseComponent {
private _snackBar = inject(MatSnackBar);
  

   // Dropped elements in the form builder
   formItems: FormElement[] = [];

   formsdata: FormsSchemaData[];
  //  forms_row_id: FormsSchemaData[];


   formLinkInput: string;

   tablename:string;

   forms_response_numbers:string;

  formSubdata:formdata[] =[]; // Use MatTableDataSource for pagination

  currentUrlPath:any;

   constructor(
       private Apicontroller: ApicontrollerService,
           private route: ActivatedRoute,
       
     ) {
      this.loadForm()

    console.log("response:-",route)
    console.log("url get ",this.route.snapshot['_routerState'].url)
this.currentUrlPath = this.route.snapshot['_routerState'].url

console.log("currentUrlPath",this.currentUrlPath)

       

     }

    //  displayedColumns: any[] = [
    //   'form_row_id',
    //   'form_sub_data',   
    //   'phone',
    //   'username',
    //   'textField',
    //   // 'emailField',
    //   'phoneNumber',
    //   // 'description'


     
    // ];

    displayedColumns:any[];


    async formsdatasub(){
      const formsubresponse = await this.Apicontroller.showFormresponse(this.tablename)
      console.log("formsubresponse -->",formsubresponse)
      console.log("response form_data",formsubresponse)
      this.formSubdata = formsubresponse
      
      console.log("form res data of header",Object.keys(this.formSubdata[0].form_data))

      this.displayedColumns = Object.keys(this.formSubdata[0].form_data)

      console.log("disp",this.displayedColumns)
  
      console.log("forms data ",this.formSubdata)
    }

  /**
     * load forms (backend side).
     */

  async loadForm() {

    const resp = await this.Apicontroller.loadallForms();
    this.formsdata = resp as FormsSchemaData[]; // Type assert to Doctor[]
    // this.forms_row_id = resp as FormsSchemaData[]; // Type assert to Doctor[]

    console.log("resp---", resp)
//    console.log("formslinks ---", this.forms_row_id)

  }


  /**
   * new design window
   */

  newForm() {
    this.formItems = [];
  }


  formdata =[]


  async showforms(tablename: any) {
    console.log("tablename ", tablename)

    this.tablename = tablename
    // this.idx = this.idx +1;

    const formsubresponseCount = await this.Apicontroller.showFormresponseCount(this.tablename)
    console.log("formsubresponse count -->",formsubresponseCount)
    this.forms_response_numbers = formsubresponseCount


    // const formsubresponse = await this.Apicontroller.showFormresponse(this.forms_row_id)
    // console.log("formsubresponse -->",formsubresponse)
    // console.log("response form_data",formsubresponse)
    // this.formdata = formsubresponse

    // console.log("forms data ",this.formdata)

    this.formsdatasub()

    const resp = await this.Apicontroller.loadForms(tablename);
    console.log("resp", resp[0].form_data)
    this.formItems = resp[0].form_data;
  }

}
