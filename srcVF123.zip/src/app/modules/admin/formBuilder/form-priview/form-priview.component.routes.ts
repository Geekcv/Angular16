import { Routes } from '@angular/router';
import { FormPriviewComponent } from 'app/modules/admin/formBuilder/form-priview/form-priview.component'

export default [
    {
        path: '',
        component: FormPriviewComponent,
    },
] as Routes;
