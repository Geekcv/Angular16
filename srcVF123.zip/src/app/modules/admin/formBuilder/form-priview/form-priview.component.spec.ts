import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormPriviewComponent } from './form-priview.component';

describe('FormPriviewComponent', () => {
  let component: FormPriviewComponent;
  let fixture: ComponentFixture<FormPriviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormPriviewComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FormPriviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
