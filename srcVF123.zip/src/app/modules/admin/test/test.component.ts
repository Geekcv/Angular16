import { AsyncPipe, CommonModule } from '@angular/common';
import { Component, inject, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormControl, FormsModule, NgForm, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTableModule } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/Services/auth.service';
import { map, Observable, startWith } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { ViewVideonotesComponent } from '../dialog/doctor/view-videonotes/view-videonotes.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatIconModule } from '@angular/material/icon';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';






@Component({
  selector: 'app-test',
  standalone: true,
  templateUrl: './test.component.html',
  encapsulation: ViewEncapsulation.None,
  imports: [FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    ReactiveFormsModule,
    // AsyncPipe,
    CommonModule,
    MatTableModule,
    MatDividerModule,
    MatButtonModule,
     FormsModule,
        
        MatIconModule,
        MatCheckboxModule,
        MatProgressSpinnerModule,MatSelectModule
  ]
})
export class TestComponent {



  isclinicalbtn: boolean = false;
  isclinicaldiagnosisbtn: boolean = false
  isclinicalsummarybtn: boolean = false
  isclinicalscalesbtn: boolean = false

  isinsights: boolean = false;
  isaidiagnosisbtn: boolean = false
  isaisummarybtn: boolean = false
  isaiscalesbtn: boolean = false

  isprofilebtn: boolean = false;


  ischatsbtn: boolean = false

  isaudiobtn: boolean = false


  isvideobtn: boolean = false


  istelepsychiatrysessionsbtn: boolean = false

  isinpersonsession: boolean = false;

    constructor(     
      private _matDialog: MatDialog,
      private _formBuilder: UntypedFormBuilder,
      private _router: Router,
      private Apicontroller: ApicontrollerService,     
    ) { 
  
      this.role=  localStorage.getItem('role')
    
    }

  clinicalbtn() {
    this.isclinicalbtn = true;
    this.isinsights = false;
    this.isprofilebtn = false;
    this.isvideobtn = false
    this.isaudiobtn = false
    this.isinpersonsession = false
    this.istelepsychiatrysessionsbtn = false
  }



  clinicaldiagnosisbtn() {
    this.isclinicaldiagnosisbtn = true
    this.isclinicalsummarybtn = false;
    this.isclinicalscalesbtn = false
    this.ischatsbtn = false
  }


  clinicalsummarybtn() {
    this.isclinicalsummarybtn = true;
    this.isclinicaldiagnosisbtn = false
    this.isclinicalscalesbtn = false
  }

  clinicalscalesbtn() {
    this.isclinicalscalesbtn = true
    this.isclinicalsummarybtn = false;
    this.isclinicaldiagnosisbtn = false
  }


  aiinsightsbtn() {
    this.isinsights = true;
    this.isclinicalbtn = false;
    this.isprofilebtn = false;
    this.ischatsbtn = false
    this.isvideobtn = false
    this.isaudiobtn = false
    this.isinpersonsession = false
    this.istelepsychiatrysessionsbtn = false
  }



  aidiagnosisbtn() {
    this.isaidiagnosisbtn = true
    this.isaisummarybtn = false;
    this.isaiscalesbtn = false


  }


  aisummarybtn() {
    this.isaisummarybtn = true;
    this.isaidiagnosisbtn = false
    this.isaiscalesbtn = false


  }

  aiscalesbtn() {
    this.isaiscalesbtn = true
    this.isaisummarybtn = false;
    this.isaidiagnosisbtn = false


  }




  profilebtn() {
    this.isprofilebtn = true
    this.isclinicalbtn = false;
    this.isinsights = false;
    this.ischatsbtn = false
    this.isvideobtn = false
    this.isaudiobtn = false
    this.isinpersonsession = false
    this.istelepsychiatrysessionsbtn = false
  }


  chatsbtn() {
    this.ischatsbtn = true
    this.isprofilebtn = false
    this.isclinicalbtn = false;
    this.isinsights = false;
    this.isvideobtn = false
    this.isaudiobtn = false
    this.isinpersonsession = false
    this.istelepsychiatrysessionsbtn = false
  }


  audiobtn() {
    this.isaudiobtn = true
    this.isvideobtn = false
    this.ischatsbtn = false
    this.isprofilebtn = false
    this.isclinicalbtn = false;
    this.isinsights = false;
    this.isinpersonsession = false
    this.istelepsychiatrysessionsbtn = false
  }


  videobtn() {
    this.isvideobtn = true
    this.isaudiobtn = false
    this.ischatsbtn = false
    this.isprofilebtn = false
    this.isclinicalbtn = false;
    this.isinsights = false;
    this.isinpersonsession = false
    this.istelepsychiatrysessionsbtn = false
  }

  telepsychiatrysessionsbtn() {
    this.istelepsychiatrysessionsbtn = true
    this.isinpersonsession = false

    this.isvideobtn = false
    this.isaudiobtn = false
    this.ischatsbtn = false
    this.isprofilebtn = false
    this.isclinicalbtn = false;
    this.isinsights = false;
  }

  inpersonsession() {
    this.isinpersonsession = true
    this.istelepsychiatrysessionsbtn = false

    this.isvideobtn = false
    this.isaudiobtn = false
    this.ischatsbtn = false
    this.isprofilebtn = false
    this.isclinicalbtn = false;
    this.isinsights = false;

  }

  // viewaudiodialogboxbtn(){
  //   const dialogRef = this._matDialog.open(ViewAudionotesComponent);
  // }


  viewvieodialogboxbtn(){
      const dialogRef = this._matDialog.open(ViewVideonotesComponent);
    }


    @ViewChild('signUpNgForm') signUpNgForm: NgForm;
    
     
      signUpForm: UntypedFormGroup;
      showAlert: boolean = false;
      role :any ='';
    
      genders: string[] = ['Male', 'Female', 'Other']; // List of genders
      ages:string[]=[
        '1','2','3','4','5','6','7','8','9','10',
        '11','12','13','14','15','16','17','18','19','20',
        '21','22','23','24','25','26','27','28','29','30',
        '31','32','33','34','35','36','37','38','39','40',
        '41','42','43','44','45','46','47','48','49','50',
        '51','52','53','54','55','56','57','58','59','60',
        '61','62','63','64','65','66','67','68','69','70',
        '71','72','73','74','75','76','77','78','79','80',    
    
      ]
    
      private _snackBar = inject(MatSnackBar);
    
      
    
      
    
      // -----------------------------------------------------------------------------------------------------
      // @ Lifecycle hooks
      // -----------------------------------------------------------------------------------------------------
    
      /**
       * On init
       */
      ngOnInit(): void {
          // Create the form
          this.signUpForm = this._formBuilder.group({
            patient_name: ['', Validators.required],
            patient_email: ['', [Validators.required, Validators.email]],
            patient_number: ['', Validators.required],
            patient_password: ['', Validators.required],
            patient_age: ['', Validators.required],
            patient_gender: ['', Validators.required],
    
              //company: [''],
              //agreements: ['', Validators.requiredTrue],
          });
      }
    
      // -----------------------------------------------------------------------------------------------------
      // @ Public methods
      // -----------------------------------------------------------------------------------------------------
    
      /**
       * Sign up
       */ 
    
      async addresearchers(){
    
        console.log(this.signUpForm.value)
    
        const resp = await this.Apicontroller.AddPatients(this.signUpForm.value);
    
    
          // console.log("resp------------>",resp)
    
       
        if (resp.status === 0) {
    
          this._snackBar.open(resp.msg, '', {
            duration: 3000, // Duration in milliseconds (3 seconds)
            verticalPosition: 'top', // Position: 'top' | 'bottom'
            horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
          });
        
          this._router.navigate(['/Viewpatients'])
    
    
        }else{
         // this.messageService.add({ severity: 'error', summary: 'Error', detail: resp.msg });
         console.log("error ")
        } 
      }
}
