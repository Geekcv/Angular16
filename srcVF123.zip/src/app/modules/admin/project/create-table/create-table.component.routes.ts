import { Routes } from '@angular/router';
import { CreateTableComponent } from 'app/modules/admin/project/create-table/create-table.component'

export default [
    {
        path: '',
        component: CreateTableComponent,
    },
] as Routes;
