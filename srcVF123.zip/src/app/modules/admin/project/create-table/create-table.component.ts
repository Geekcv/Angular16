import {ChangeDetectionStrategy, Component} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {MatTimepickerModule} from '@angular/material/timepicker';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {provideNativeDateAdapter} from '@angular/material/core';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatSelectModule } from '@angular/material/select';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/Services/auth.service';
import { MatButtonModule } from '@angular/material/button';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-create-table',
  imports: [
      MatFormFieldModule,
      FormsModule,
      MatSelectModule, 
      MatInputModule, 
      MatButtonModule,],
  templateUrl: './create-table.component.html',
  styleUrl: './create-table.component.scss'
})
export class CreateTableComponent {

  project_name:any;


  constructor(
    private Apicontroller: ApicontrollerService
  ) {

  }

  async saveproject(){
    console.log("project_name:-",this.project_name)

    const resp = await this.Apicontroller.createTable(this.project_name);

    console.log("project_name",this.project_name)
    console.log("resp-",resp)


  }
}
