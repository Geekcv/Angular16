import { Routes } from '@angular/router';
import { ResponseComponent } from 'app/modules/admin/project/response/response.component'

export default [
    {
        path: '',
        component: ResponseComponent,
    },
] as Routes;
