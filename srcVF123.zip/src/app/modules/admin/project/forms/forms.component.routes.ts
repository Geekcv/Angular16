import { Routes } from '@angular/router';
import { FormsComponent } from 'app/modules/admin/project/forms/forms.component'

export default [
    {
        path: '',
        component: FormsComponent,
    },
] as Routes;
