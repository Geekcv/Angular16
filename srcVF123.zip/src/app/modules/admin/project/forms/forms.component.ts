import { Component } from '@angular/core';
import { FormPreviewComponent } from '../../components/form-preview/form-preview.component';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { ActivatedRoute } from '@angular/router';

interface FormElement {
  type: string;
  label: string;
  placeholder?: string;
  rows?: any;
  cols?: any
  min?: any
  max?: any
  optionsdropdown?: Array<{ label: string, value: string }>;// Dropdown options,
  optionsradio?: Array<{ label: string, value: string }>;
  optionscheckbox?: Array<{ label: string, value: string }>
  layout?: 'vertical' | 'horizontal';
  required?: boolean;
  address?:any[];
  accept?:string;
  key?:any;
  searchText?:any;
  filteredOptions?:any;
    


}

interface FormsSchemaData {
  // forms_row_id:any;
  form_link: any;
}

@Component({
  selector: 'app-forms',
  imports: [    FormPreviewComponent,
  ],
  templateUrl: './forms.component.html',
  styleUrl: './forms.component.scss'
})
export class FormsComponent {
  formItems: FormElement[] = [];

  forms_row_id:string;
  formslinks: FormsSchemaData[];
  currentUrlPath:any;

  constructor(
           private Apicontroller: ApicontrollerService  ,
                      private route: ActivatedRoute,
             
  ){
    this.loadForm()
this.currentUrlPath = this.route.snapshot['_routerState'].url
console.log("inside forms",this.currentUrlPath)

  }


  newForm(){
    this.formItems = [];

  }

  async showforms(link: any) {
    console.log("row id ", link)

    this.forms_row_id = link
    // this.idx = this.idx +1;   

    // this.formsdatasub()

    const resp = await this.Apicontroller.loadForms(link);
    console.log("resp", resp[0].form_data)
    this.formItems = resp[0].form_data;
  }

  async loadForm() {

    const resp = await this.Apicontroller.loadallForms();
    this.formslinks = resp as FormsSchemaData[]; // Type assert to Doctor[]

  }

}
