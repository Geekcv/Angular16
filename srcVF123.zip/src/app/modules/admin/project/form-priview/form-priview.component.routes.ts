import { Routes } from '@angular/router';
import { FormPriviewComponent } from 'app/modules/admin/project/form-priview/form-priview.component'

export default [
    {
        path: '',
        component: FormPriviewComponent,
    },
] as Routes;
