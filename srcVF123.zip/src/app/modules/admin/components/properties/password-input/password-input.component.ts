// filepath: d:\abhishek-ng\research-ng-form-builder\research-ng-form-builder\src\app\modules\admin\components\properties\password-input\password-input.component.ts
import { CommonModule, NgIf } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';

// --- Interface (Ensure this matches/extends the one in other components) ---
interface FormElement {
  type: string;
  label: string;
  placeholder?: string;
  required?: boolean;
  // Styling properties
  fontSize?: string;
  fontColor?: string;
  fontFamily?: string;
  fontWeight?: string;
  borderStyle?: string;
  borderWidth?:string;
  bordercolor?:string;
  padding?: string;
  margin?:string;
  bgColor?: string;
  width?: string;
  height?: string;
  invalid?: boolean; // For validation state
  key?:string
  // ... other properties from your base FormElement interface
}
// --- End Interface ---

@Component({
  selector: 'app-password-input',
  standalone: true, // Assuming standalone based on EmailFieldComponent
  imports: [
    CommonModule,
    FormsModule,
    NgIf,
    MatInputModule,
    MatCheckboxModule
  ],
  templateUrl: './password-input.component.html',
  styleUrls: ['./password-input.component.scss']
})
export class PasswordInputComponent implements OnInit {

  @Input() selectedElementIndex: number | null = null;
  @Input() formItems: FormElement[] = [];

  // --- Style & Config Properties ---
  fontSize: string = '14px';
  fontColor: string = '#000000';
  fontFamily: string = 'Arial';
  fontWeight: string = 'normal';
  borderStyle: string = 'solid';
  borderWidth: string= '1px';
  bordercolor: string= '#cccccc';
  padding: string = '8px';
  margin: string ='5px';
  bgColor: string = '#ffffff';
  width: string = '100%';
  height: string = '40px';
  required: boolean = false;
  // --- End Style & Config Properties ---

  ngOnInit(): void {
    this.updateLocalProperties();
  }

  // Load current element's properties
  updateLocalProperties(): void {
     if (this.selectedElementIndex !== null && this.formItems[this.selectedElementIndex]) {
       const selectedElement = this.formItems[this.selectedElementIndex];
       this.fontSize = selectedElement.fontSize || '14px';
       this.fontColor = selectedElement.fontColor || '#000000';
       this.fontFamily = selectedElement.fontFamily || 'Arial';
       this.fontWeight = selectedElement.fontWeight || 'normal';
       this.borderStyle = selectedElement.borderStyle || 'solid';
       this.borderWidth = selectedElement.borderWidth || '1px';
       this.bordercolor = selectedElement.bordercolor || '#cccccc';
       this.padding = selectedElement.padding || '8px';
       this.margin = selectedElement.margin || '5px';
       this.bgColor = selectedElement.bgColor || '#ffffff';
       this.width = selectedElement.width || '100%';
       this.height = selectedElement.height || '40px';
       this.required = selectedElement.required || false;
     }
   }

  // Update the main formItems array
  updateProperties(): void {
    if (this.selectedElementIndex !== null) {
      const selectedElement = this.formItems[this.selectedElementIndex];
      selectedElement.fontSize = this.fontSize;
      selectedElement.fontColor = this.fontColor;
      selectedElement.fontFamily = this.fontFamily;
      selectedElement.fontWeight = this.fontWeight;
      selectedElement.borderStyle = this.borderStyle;
      selectedElement.borderWidth = this.borderWidth;
      selectedElement.bordercolor = this.bordercolor;
      selectedElement.padding = this.padding;
      selectedElement.margin = this.margin;
      selectedElement.bgColor = this.bgColor;
      selectedElement.width = this.width;
      selectedElement.height = this.height;
      selectedElement.required = this.required;

      // Directly update label and placeholder via ngModel binding
      this.validateLabel();
      // this.validatePlaceholder(); // Placeholder validation might be optional
    }
  }

   // --- Validation (similar to TextBoxComponent) ---
   isLabelInvalid(): boolean {
    return this.selectedElementIndex !== null &&
           !this.formItems[this.selectedElementIndex]?.label?.trim();
  }

  isPlaceholderInvalid(): boolean {
    // Placeholder might be optional for email, adjust logic if needed
    return this.selectedElementIndex !== null &&
           !this.formItems[this.selectedElementIndex]?.placeholder?.trim();
  }

  validateLabel() {
    if (this.selectedElementIndex !== null) {
      const element = this.formItems[this.selectedElementIndex];
      element.invalid = !element.label?.trim(); // Basic required validation
    }
  }

  validatePlaceholder() {
     // Placeholder validation might not be strictly necessary for email fields
      if (this.selectedElementIndex !== null) {
        const element = this.formItems[this.selectedElementIndex];
        // Decide if placeholder is required and update element.invalid accordingly
        // For now, let's assume it's optional:
        // element.invalid = element.invalid || !element.placeholder?.trim();
      }
  }
  // --- End Validation ---
  syncLabelToKey(): void {
    // Sync label to key in real-time
    this.formItems[this.selectedElementIndex].key = this.formItems[this.selectedElementIndex].label;
  }
}