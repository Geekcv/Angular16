import { CommonModule,  NgIf } from '@angular/common';
import { Component, Input } from '@angular/core';
import { FormsModule, NgModel } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';

interface FormElement {
  type: string;
  label: string;
  placeholder?: string;
  required?: boolean; // Added required property
  // Styling properties
  fontSize?: string;
  fontColor?: string;
  fontFamily?: string;
  fontWeight?: string;
  borderStyle?: string;
  borderWidth?:string;
  bordercolor?:string;
  padding?: string;
  margin?:string;
  bgColor?: string;
  width?: string;
  height?: string;
  max?:string;
  min?:string;
  key?:string
  invalid?: boolean; // For validation state
  // ... other properties from your base FormElement interface
}

@Component({
  selector: 'app-date',
  imports: [
    CommonModule,
    FormsModule,
    NgIf,
    MatIconModule, // Import MatIconModule,
    MatCheckboxModule
  ],
  templateUrl: './date.component.html',
  styleUrl: './date.component.scss'
})
export class DateComponent {
   @Input() selectedElementIndex:any; 
   @Input() formItems:FormElement[]; 



   fontSize: string = '16px';
 fontColor: string = '#000000';
 fontFamily: string = 'Arial';
 fontWeight: string = 'normal';
 borderStyle: string = 'solid';
 padding: string = '1px';
 bgColor: string = '#ffffff';
 borderWidth:string= '1px'
 margin:string ='1px'
 height:string = '40px';
 width:string = '500px';
 bordercolor:string= 'blue'
 max:string='2025-01-01'
 min:string='2023-01-01'
 required: boolean = false; // Added required property


 ngOnInit(): void {
  this.updateLocalProperties();
}



// Load current element's properties
updateLocalProperties(): void {
  if (this.selectedElementIndex !== null && this.formItems[this.selectedElementIndex]) {
    const selectedElement = this.formItems[this.selectedElementIndex];
    this.fontSize = selectedElement.fontSize || '14px';
    this.fontColor = selectedElement.fontColor || '#000000';
    this.fontFamily = selectedElement.fontFamily || 'Arial';
    this.fontWeight = selectedElement.fontWeight || 'normal';
    this.borderStyle = selectedElement.borderStyle || 'solid';
    this.borderWidth = selectedElement.borderWidth || '1px';
    this.bordercolor = selectedElement.bordercolor || '#cccccc';
    this.padding = selectedElement.padding || '8px';
    this.margin = selectedElement.margin || '5px';
    this.bgColor = selectedElement.bgColor || '#ffffff';
    this.width = selectedElement.width || '100%';
    this.height = selectedElement.height || '40px';
    this.required = selectedElement.required || false; // Load required status
  }
}

// Update the main formItems array
updateProperties(): void {
 if (this.selectedElementIndex !== null) {
   const selectedElement = this.formItems[this.selectedElementIndex];
   selectedElement.fontSize = this.fontSize;
   selectedElement.fontColor = this.fontColor;
   selectedElement.fontFamily = this.fontFamily;
   selectedElement.fontWeight = this.fontWeight;
   selectedElement.borderStyle = this.borderStyle;
   selectedElement.borderWidth = this.borderWidth;
   selectedElement.bordercolor = this.bordercolor;
   selectedElement.padding = this.padding;
   selectedElement.margin = this.margin;
   selectedElement.bgColor = this.bgColor;
   selectedElement.width = this.width;
   selectedElement.height = this.height;
   selectedElement.max = this.max;
   selectedElement.min = this.min
   selectedElement.required = this.required; // Update required status
   // Directly update label and placeholder via ngModel binding
   this.validateLabel();
 }
}

// --- Validation ---
isLabelInvalid(): boolean {
  return this.selectedElementIndex !== null &&
         !this.formItems[this.selectedElementIndex]?.label?.trim();
}

validateLabel() {
  if (this.selectedElementIndex !== null) {
    const element = this.formItems[this.selectedElementIndex];
    element.invalid = !element.label?.trim();
  }
}
// --- End Validation ---

syncLabelToKey(): void {
  // Sync label to key in real-time
  this.formItems[this.selectedElementIndex].key = this.formItems[this.selectedElementIndex].label;
}
   

}