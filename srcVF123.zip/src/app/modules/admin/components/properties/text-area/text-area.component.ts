import { CommonModule, NgIf } from '@angular/common';
import { Component, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';

interface FormElement {
  rows: string;
  cols: string;
  type: string;
  label: string;
  placeholder?: string;
  fontSize?: string;
  fontColor?: string;
  fontFamily?: string;
  fontWeight?: string;
  borderStyle?: string;
  padding?: string;
  bgColor?: string;
  invalid?: boolean; // Added to indicate validation state
  borderWidth?:string;
  margin?:string;
  width?: string;
  height?: string;
  bordercolor?:string; 
  min?:any
  max?:any
  key?:string;
  required?: boolean;

}

@Component({
  selector: 'app-text-area',
  imports: [
      NgIf,
             
               CommonModule, 
               FormsModule,          
               MatInputModule,
            MatIconModule,
            MatCheckboxModule
  ],
  templateUrl: './text-area.component.html',
  styleUrl: './text-area.component.scss'
})
export class TextAreaComponent {
@Input() selectedElementIndex:any; 
 @Input() formItems:FormElement[]; 

 fontSize: string = '16px';
 fontColor: string = '#000000';
 fontFamily: string = 'Arial';
 fontWeight: string = 'normal';
 borderStyle: string = 'solid';
 padding: string = '1px';
 bgColor: string = '#ffffff';
 borderWidth:string= '1px'
 margin:string ='1px'
 height:string = '40px';
 width:string = '500px';
 bordercolor:string= 'blue'
 rows:any='5'
 cols:any='5'
 required: boolean = false;




  /**
   * Select an element for editing.
   */
  selectElement(index: number) {
    this.selectedElementIndex = index;
    const selectedElement = this.formItems[index];

    console.log("selectedElement",selectedElement)

    const selectedElementtype = this.formItems[index].type;
    console.log("type-",this.formItems[index].type)


    this.fontSize = selectedElement.fontSize || '16px';
 
    console.log("fontsize",this.fontSize)
    this.fontColor = selectedElement.fontColor || '#000000';
    this.fontFamily = selectedElement.fontFamily || 'Arial';
    this.fontWeight = selectedElement.fontWeight || 'normal';
    this.borderStyle = selectedElement.borderStyle || 'solid';
    this.padding = selectedElement.padding || '1px';
    this.bgColor = selectedElement.bgColor || '#ffffff';
    this.borderWidth = selectedElement.borderWidth || '1px'
    this.margin = selectedElement.margin || '1px'
    this.width = selectedElement.width || '500px';
    this.height = selectedElement.height || '40px';
    this.bordercolor = selectedElement.bordercolor;   
    this.rows = selectedElement.rows|| '5'
    this.cols = selectedElement.cols || '5'

  }
 


 /**
   * Validate label (required field)
   */
 isLabelInvalid(): boolean {
 
  return this.selectedElementIndex !== null &&
    !this.formItems[this.selectedElementIndex].label.trim();
}

/**
 * Validate placeholder (required field)
 */
isPlaceholderInvalid(): boolean {
  return this.selectedElementIndex !== null &&
    !this.formItems[this.selectedElementIndex].placeholder?.trim();
}

/**
 * Validate all fields and mark as invalid if needed
 */
validateLabel() {
  const label = this.formItems[this.selectedElementIndex!].label;
  if (!label || label.trim().length === 0) {
    this.formItems[this.selectedElementIndex!].invalid = true;

  } else {
    this.formItems[this.selectedElementIndex!].invalid = false;

  }
}

validatePlaceholder() {
  const placeholder = this.formItems[this.selectedElementIndex!].placeholder;
  if (!placeholder || placeholder.trim().length === 0) {
    this.formItems[this.selectedElementIndex!].invalid = true;
  } else {
    this.formItems[this.selectedElementIndex!].invalid = false;
  }
}


 updateStyles() {
  // console.log("bac color",this.bgColor)
  if (this.selectedElementIndex !== null) {
    const selectedElement = this.formItems[this.selectedElementIndex];
    selectedElement.fontSize = this.fontSize;
    selectedElement.fontColor = this.fontColor;
    selectedElement.fontFamily = this.fontFamily;
    selectedElement.fontWeight = this.fontWeight;
    selectedElement.borderStyle = this.borderStyle;
    selectedElement.padding = this.padding;
    selectedElement.bgColor = this.bgColor;
    selectedElement.borderWidth= this.borderWidth;
    selectedElement.margin = this.margin
    selectedElement.width = this.width
    selectedElement.height = this.height
    selectedElement.bordercolor = this.bordercolor

    selectedElement.rows = this.rows
    selectedElement.cols = this.cols
    selectedElement.required = this.required

  }
}

syncLabelToKey(): void {
  // Sync label to key in real-time
  this.formItems[this.selectedElementIndex].key = this.formItems[this.selectedElementIndex].label;
}

}
