import { CommonModule, NgIf } from '@angular/common';
import { Component, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';

interface FormElement {
  type: string;
  label: string;
  placeholder?: string;
  fontSize?: string;
  fontColor?: string;
  fontFamily?: string;
  fontWeight?: string;
  borderStyle?: string;
  padding?: string;
  bgColor?: string;
  invalid?: boolean; // Added to indicate validation state
  borderWidth?:string;
  margin?:string;
  width?: string;
  height?: string;
  bordercolor?:string; 
  min?:number
  max?:number;
  key?:string;
}

@Component({
  selector: 'app-number-input',
  imports: [
     NgIf,
             
               CommonModule, 
               FormsModule,          
               MatInputModule,
            MatIconModule,
  ],
  templateUrl: './number-input.component.html',
  styleUrl: './number-input.component.scss'
})
export class NumberInputComponent {
 @Input() selectedElementIndex:any; 
 @Input() formItems:FormElement[]; 

 fontSize: string = '16px';
 fontColor: string = '#000000';
 fontFamily: string = 'Arial';
 fontWeight: string = 'normal';
 borderStyle: string = 'solid';
 padding: string = '1px';
 bgColor: string = '#ffffff';
 borderWidth:string= '1px'
 margin:string ='1px'
 height:string = '40px';
 width:string = '500px';
 bordercolor:string= 'blue'  
 min:number=0
 max:number=5



  /**
   * Select an element for editing.
   */
  selectElement(index: number) {
    this.selectedElementIndex = index;
    const selectedElement = this.formItems[index];

    console.log("forms items",this.formItems[index])


    console.log("selectedElement",selectedElement)

    const selectedElementtype = this.formItems[index].type;
    console.log("type-1",this.formItems[index].type)


    console.log("forms items",this.formItems[index])


    this.fontSize = selectedElement.fontSize || '16px';
 
    console.log("fontsize",this.fontSize)
    this.fontColor = selectedElement.fontColor || '#000000';
    this.fontFamily = selectedElement.fontFamily || 'Arial';
    this.fontWeight = selectedElement.fontWeight || 'normal';
    this.borderStyle = selectedElement.borderStyle || 'solid';
    this.padding = selectedElement.padding || '1px';
    this.bgColor = selectedElement.bgColor || '#ffffff';
    this.borderWidth = selectedElement.borderWidth || '1px'
    this.margin = selectedElement.margin || '1px'
    this.width = selectedElement.width || '500px';
    this.height = selectedElement.height || '40px';
    this.bordercolor = selectedElement.bordercolor;   

    this.min = selectedElement.min || 0
    this.max = selectedElement.max || 10
  }
 


 /**
   * Validate label (required field)
   */
 isLabelInvalid(): boolean {
  
  return this.selectedElementIndex !== null &&
    !this.formItems[this.selectedElementIndex].label.trim();
}

/**
 * Validate placeholder (required field)
 */
isPlaceholderInvalid(): boolean {
  return this.selectedElementIndex !== null &&
    !this.formItems[this.selectedElementIndex].placeholder?.trim();
}

/**
 * Validate all fields and mark as invalid if needed
 */
validateLabel() {
  const label = this.formItems[this.selectedElementIndex!].label;
  if (!label || label.trim().length === 0) {
    this.formItems[this.selectedElementIndex!].invalid = true;

  } else {
    this.formItems[this.selectedElementIndex!].invalid = false;

  }
}

validatePlaceholder() {
  const placeholder = this.formItems[this.selectedElementIndex!].placeholder;
  if (!placeholder || placeholder.trim().length === 0) {
    this.formItems[this.selectedElementIndex!].invalid = true;
  } else {
    this.formItems[this.selectedElementIndex!].invalid = false;
  }
}


 updateStyles() {
  // console.log("bac color",this.bgColor)
  if (this.selectedElementIndex !== null) {
    const selectedElement = this.formItems[this.selectedElementIndex];
    selectedElement.fontSize = this.fontSize;
    selectedElement.fontColor = this.fontColor;
    selectedElement.fontFamily = this.fontFamily;
    selectedElement.fontWeight = this.fontWeight;
    selectedElement.borderStyle = this.borderStyle;
    selectedElement.padding = this.padding;
    selectedElement.bgColor = this.bgColor;
    selectedElement.borderWidth= this.borderWidth;
    selectedElement.margin = this.margin
    selectedElement.width = this.width
    selectedElement.height = this.height
    selectedElement.bordercolor = this.bordercolor
    selectedElement.min = this.min
    selectedElement.max = this.max

  }
}

syncLabelToKey(): void {
  // Sync label to key in real-time
  this.formItems[this.selectedElementIndex].key = this.formItems[this.selectedElementIndex].label;
}

}
