import { CommonModule,  NgIf } from '@angular/common';
import { Component, Input } from '@angular/core';
import { FormsModule, NgModel } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';

interface FormElement {
  type: string;
  label: string;
  placeholder?: string;
  fontSize?: string;
  fontColor?: string;
  fontFamily?: string;
  fontWeight?: string;
  borderStyle?: string;
  padding?: string;
  bgColor?: string;
  invalid?: boolean; // Added to indicate validation state
  borderWidth?:string;
  margin?:string;
  width?: string;
  height?: string;
 
  checked?:string;
  key?:string;
}

@Component({
  selector: 'app-single-checkbox',
  imports: [
     CommonModule,
        FormsModule,
        NgIf,
        MatIconModule, // Import MatIconModule,
  ],
  templateUrl: './single-checkbox.component.html',
  styleUrl: './single-checkbox.component.scss'
})
export class SingleCheckboxComponent {
@Input() selectedElementIndex:any; 
   @Input() formItems:FormElement[]; 

   
   fontSize: string = '16px';
 fontColor: string = '#000000';
 fontFamily: string = 'Arial';
 fontWeight: string = 'normal';
 borderStyle: string = 'solid';
 padding: string = '1px';
 bgColor: string = '#ffffff';
 borderWidth:string= '1px'
 margin:string ='1px'
 height:string = '40px';
 width:string = '500px';
 bordercolor:string= 'blue'

 checked:string='checked'



   selectElement(index: number) {
    this.selectedElementIndex = index;
    const selectedElement = this.formItems[index];

    console.log("selectedElement",selectedElement)

    const selectedElementtype = this.formItems[index].type;
    console.log("type-",this.formItems[index].type)


    this.fontSize = selectedElement.fontSize || '16px';
 
    console.log("fontsize",this.fontSize)
    this.fontColor = selectedElement.fontColor || '#000000';
    this.fontFamily = selectedElement.fontFamily || 'Arial';
    this.fontWeight = selectedElement.fontWeight || 'normal';
    this.borderStyle = selectedElement.borderStyle || 'solid';
    this.padding = selectedElement.padding || '1px';
    this.bgColor = selectedElement.bgColor || '#ffffff';
    this.borderWidth = selectedElement.borderWidth || '1px'
    this.margin = selectedElement.margin || '1px'
    this.width = selectedElement.width || '500px';
    this.height = selectedElement.height || '40px';

    

    this.checked = selectedElement.checked || 'checked'

    console.log("checked",this.checked)
  }
   
 /**
   * Validate label (required field)
   */
 isLabelInvalid(): boolean {
 
  return this.selectedElementIndex !== null &&
    !this.formItems[this.selectedElementIndex].label.trim();
}

/**
 * Validate placeholder (required field)
 */
isPlaceholderInvalid(): boolean {
  return this.selectedElementIndex !== null &&
    !this.formItems[this.selectedElementIndex].placeholder?.trim();
}

/**
 * Validate all fields and mark as invalid if needed
 */
validateLabel() {
  const label = this.formItems[this.selectedElementIndex!].label;
  if (!label || label.trim().length === 0) {
    this.formItems[this.selectedElementIndex!].invalid = true;

  } else {
    this.formItems[this.selectedElementIndex!].invalid = false;

  }
  

}


updateStyles() {
  // console.log("bac color",this.bgColor)
  if (this.selectedElementIndex !== null) {
    const selectedElement = this.formItems[this.selectedElementIndex];
    selectedElement.fontSize = this.fontSize;
    selectedElement.fontColor = this.fontColor;
    selectedElement.fontFamily = this.fontFamily;
    selectedElement.fontWeight = this.fontWeight;
    selectedElement.borderStyle = this.borderStyle;
    selectedElement.padding = this.padding;
    selectedElement.bgColor = this.bgColor;
    selectedElement.borderWidth= this.borderWidth;
    selectedElement.margin = this.margin
    selectedElement.width = this.width
    selectedElement.height = this.height



    selectedElement.checked = this.checked;
  

  }
}

syncLabelToKey(): void {
  // Sync label to key in real-time
  this.formItems[this.selectedElementIndex].key = this.formItems[this.selectedElementIndex].label;
}
}
