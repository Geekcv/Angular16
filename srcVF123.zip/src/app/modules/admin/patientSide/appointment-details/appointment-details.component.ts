import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/Services/auth.service';

@Component({
  selector: 'app-appointment-details',
  imports: [MatButtonModule, MatFormFieldModule, FormsModule,
    ReactiveFormsModule, MatInputModule, MatSelectModule],
  templateUrl: './appointment-details.component.html'
})
export class AppointmentDetailsComponent {

  patientsId: string = '';
  appo_row_id:string ='';

  selectedvalue: string;
  app_status: string = '';

  // slot: string = '';
  // availableslot: string[] = ['pending', 'accept', 'reject'];

  // availablestatus: number[] = [0, 1, 2];

  availablestatus: any[] = [
    {id: 0,value :'Pending'},
    {id:1,value:'Accept'},
    {id:2,value:'Reject'},
    {id:3,value:'Complete'},
    {id:4,value:'Cancel'},
    {id:5,value:'Reschedule'}



  ];


  role: any = '';
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private apiController: ApicontrollerService,
    private authService: AuthService,

  ) {
    this.patientsId = this.route.snapshot.paramMap.get('id');
    this.appo_row_id = this.route.snapshot.paramMap.get('appid');
    this.role = Number(localStorage.getItem('role')) || 0; // Convert role to a number

  }


  goback() {
    // console.log("click this button")
    this.router.navigate(['/patientpanel', this.patientsId])
  }

  goback1(){
    // console.log("click this button")
    this.router.navigate(['/myappointment'])
  }


  async editappointment(){


    const data = {
      row_id: this.appo_row_id,
      appointment_request_status: this.app_status,
      
    };

    const resp = await this.apiController.updateAppointment(data);

    //console.log("resp",resp)

    
    
    if (resp.status === 0) {
         if (this.role === 1) {
          this.router.navigate(['/patientDetails', this.patientsId])
         }else{
          this.router.navigate(['/myappointment'])
         }
    }


   


  }

}
