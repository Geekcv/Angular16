import { HttpClient } from '@angular/common/http';
import { Component, ElementRef, input, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../config';


interface mediaMetadata {
  date: string;
  description: string;
  filename: string;
  filesize: string;
  time: string;
  media_link: string;
}


interface Patient {

  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name: string;
  user_contact_number: string;
  user_password: string;
  row_id: string;
}


interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  doctor_name: string;
  user_contact_number: string;
  user_password: string;
  row_id: string;
}


@Component({
  selector: 'app-audio-notes',
  imports: [
    MatButtonModule,
    MatIconModule,
    MatDividerModule,
    FormsModule,
    MatInputModule,
    MatTableModule,
    MatPaginatorModule
  ],
  templateUrl: './audio-notes.component.html'
})
export class AudioNotesComponent {

  file_name: any;
  file_description: any;

  isclicked = false;
  isviewbtn = false;

  row_id: any = '';
  media_link: any = '';
  toggle = false;

  isAddNewClicked: boolean = false;
  selectedRow: any = null;

  role: any;
  errorMessage: string = '';
  userrowId: any;

  patientsId!: string | null; // Holds the patientsId ID from the route
  audiomediadata: mediaMetadata[] = [];

  patientDetails: Patient | null = null;

  config: string = config.apiBaseURL;

  filename: string = '';
  filepath: string = '';
  mediatype: string = '';
  file: any;
  size: string = '';

  userDetails: Doctor | null = null;


  @ViewChild('audioPlayer') audioPlayer!: ElementRef<HTMLAudioElement>

  addnewbtn() {
    this.isclicked = true;
    this.isviewbtn = false; // Hide view when adding a new one
    //  this.toggle = true
    this.isAddNewClicked = !this.isAddNewClicked; // Toggle the button color
    this.selectedRow = null;

  }


  exitbtn() {
    this.isclicked = false;
    this.isAddNewClicked = false;
    this.isviewbtn = !this.isviewbtn;

  }



  viewbtn(media: any, e: Event) {
    console.log("media-", media)
    this.row_id = media.media_row_id;
    this.media_link = media.media_link
    this.isviewbtn = true;
    this.isclicked = false; // Hide add new when viewing
    this.selectedRow = media;

    this.isAddNewClicked = false;


    setTimeout(() => {
      this.audioPlayer.nativeElement.load()
    })

  }



  // appointment_details: appointmentDetails[]=[]

  mediaColumns: string[] = [
    'date',
    'time',
    'filename',
    'filesize',
    'description',
    'Action'


  ];


  constructor(
    private route: ActivatedRoute,
    private apiController: ApicontrollerService,
    private http: HttpClient

  ) {

    let rowId = this.role === 1 ? this.userDetails?.row_id : this.patientDetails?.row_id;
    this.userrowId = rowId
  }

  ngOnInit() {
    // console.log("patientsId",this.patientsId)   
    this.patientsId = this.route.snapshot.paramMap.get('id');
    this.viewaudiometadata();

    const userData = localStorage.getItem('userDeatials');

    this.patientDetails = JSON.parse(userData);

  }







  async viewaudiometadata() {

    const data = {
      row_id: this.userrowId,
      media_type: 'audio/mpeg',
    };

    console.log("data",data)

    const resp1 = await this.apiController.fetchmedia(data);
    this.audiomediadata = resp1.data || []
    console.log(" all media data ----", resp1)
  }


  refresh() {
    console.log("refresh----")
    this.viewaudiometadata();
    // window.location.reload();
  }


  onFileSelected(event: Event): void {
    // console.log("click this event 1")
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {

      const files = Array.from(input.files); // Handle multiple files

      files.forEach((files) => {
        this.file = input.files[0];
        const formData = new FormData();
        formData.append('file', this.file);

        console.log("selected file", this.file)

        this.file_name = this.file.name

        input.value = ''

      })


    }
    else {
      console.warn('No files selected.');
    }
  }


  uploadaudio() {

    const formData = new FormData();
    formData.append('file', this.file);

    this.http.post(`${this.config}/common/upload`, formData).subscribe({
      next: async (response: any) => {
        if (response) {
          this.filename = response.data.name;
          this.filepath = response.data.foPa || response.data.filePath; // Ensure correct key name
          this.mediatype = response.data.mimetype;
          this.size = response.data.size;

          console.log('Uploaded File:', this.filename, this.filepath, this.mediatype);

          const rowId = this.role === 1 ? this.userDetails?.row_id : this.patientDetails?.row_id;
          if (!rowId) {
            // this.errorMessage = 'User ID not found.';
            return;
          }
          // console.log("row_id",rowId)
          const data = {
            receiver_row_id: null,
            file_name: this.filename,
            file_path: this.filepath,
            media_type: this.mediatype,
            filename: this.file_name,
            description: this.file_description,
            filesize: this.size

          };

          try {
            //console.log("click this event before upload api hit 2")

            const resp = await this.apiController.uploadmedia(data);
            this.file_name = " ";
            this.file_description = " "
            this.file = 0

            console.log("Upload Response:", resp);
            // this.successMessage = 'File uploaded successfully!';
            //  console.log("click this event after upload api hit 3")
            //  input.value = ''

          } catch (error) {
            // console.error("Upload failed:", error);
            // this.errorMessage = 'File upload failed. Please try again.';

          }
        } else {
          // this.errorMessage = 'Invalid server response.';
        }
      },
      error: (error) => {
        //console.error('Upload failed:', error);
        // this.errorMessage = 'File upload failed. Please try again.';
      },
    });


  }


  delaudiobtn() {
    this.file = 0;
    this.file_name = ''

  }


}