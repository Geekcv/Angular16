import { Routes } from '@angular/router';
import { AudioNotesComponent } from 'app/modules/admin/patientSide/audio-notes/audio-notes.component';

export default [
    {
        path: '',
        component: AudioNotesComponent,
    },
] as Routes;
