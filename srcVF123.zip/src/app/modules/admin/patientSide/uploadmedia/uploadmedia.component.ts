import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/Services/auth.service';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { HttpClient } from '@angular/common/http';
import { config } from '../../../../../../config';
import { MatGridListModule } from '@angular/material/grid-list';


interface Patient {
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name: string;
  user_contact_number: string;
  user_password: string;
  row_id: string;
}

interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  doctor_name: string;
  user_contact_number: string;
  user_password: string;
  row_id: string;
}

@Component({
  selector: 'app-uploadmedia',
  imports: [MatFormFieldModule, MatSelectModule, FormsModule, MatButtonModule, MatCardModule,MatGridListModule],
  templateUrl: './uploadmedia.component.html'
})
export class UploadmediaComponent {
  role: number;
  errorMessage: string = '';
  successMessage: string = '';
  config: string = config.apiBaseURL;

  userDetails: Doctor | null = null;
  patientDetails: Patient | null = null;

  uploadedFiles: { filePath: string; mediaType: string,sender:string; time:string }[] = [];
  Formate: string = '';
  // availableFormate: string[] = ['video/mp4', 'audio/mpeg'];


  availableFormate: any[] = [
    {value :'video/mp4',show:'video'},
    {value:'audio/mpeg',show:'audio'},

  ];

  filename: string = '';
  filepath: string = '';
  mediatype: string = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private apiController: ApicontrollerService,
    private authService: AuthService,
    private http: HttpClient
  ) {
    this.role = Number(localStorage.getItem('role')) || 0; // Convert role to a number
    this.loadUserDetails();
  }

  /** Load User Details from localStorage */
  private loadUserDetails(): void {
    const userData = localStorage.getItem('userDeatials');
    if (userData) {
      if (this.role === 1) {
        this.userDetails = JSON.parse(userData);
      } else {
        this.patientDetails = JSON.parse(userData);
      }
    }
  }



  // onFileSelected(event: Event): void {
  //   const input = event.target as HTMLInputElement;
  
  //   if (input.files && input.files.length > 0) {
  //     const files = Array.from(input.files); // Handle multiple files
  
  //     files.forEach((file) => {
  //       // Check for duplicates in uploadedFiles1 array
  //       const isDuplicate = this.uploadedFiles1.some(
  //         (uploadedFile) => uploadedFile.name === file.name && uploadedFile.size === file.size
  //       );
  
  //       if (isDuplicate) {
  //         // console.warn(`File "${file.name}" is already uploaded.`);
  //         this.uploadErrorMessage = `File "${file.name}" is already uploaded.`;
  //         setTimeout(() => (this.uploadErrorMessage = ''), 5000);
  //         return;
  //       }
  
  //       const formData = new FormData();
  //       formData.append('file', file);
  
  //       this.http.post(config.apiBaseURL + '/common/uploads' , formData).subscribe({
  //         next: (response: any) => {
  //           // console.log('Upload successful:', response);
  
  //           // Extract file path from server response
  //           const filePath = response?.rsp?.data?.filesInfo?.[0]?.foPa;
  //           if (filePath) {
  //             const newFile = { name: file.name, size: file.size, photourl: filePath };
  
  //             // Add file details to uploadedFiles1 array
  //             this.uploadedFiles1.push(newFile);
  //             this.uploadSuccessMessage = `File "${file.name}" uploaded successfully!`;
  
  //             // Prepare client data for database
  //             const clientData = {
  //               user_id: this.userId,
  //               client_id: this.clientId,
  //               project_id: this.projectId,
  //               documentsConfig: [newFile], // Push only the newly uploaded file
  //             };
  
  //             this.Apicontroller.createImportDoc(clientData)
  //               .then(async () => {
  //                 // console.log(`File "${file.name}" added to the database successfully.`);
  //                 await this.fetchDocumentsconfig(); // Refresh document list
  //               })
  //               .catch((error) => {
  //                 console.error('Failed to update client data in the database:', error);
  //               });
  
  //             setTimeout(() => (this.uploadSuccessMessage = ''), 5000);
  //           } else {
  //             // console.error('Unexpected response format:', response);
  //             this.uploadErrorMessage = `File "${file.name}" upload failed. Invalid server response.`;
  //             setTimeout(() => (this.uploadErrorMessage = ''), 5000);
  //           }
  //         },
  //         error: (error) => {
  //           // console.error('Upload failed:', error);
  //           this.uploadErrorMessage = `Failed to upload "${file.name}". Please try again.`;
  //           setTimeout(() => (this.uploadErrorMessage = ''), 5000);
  //         },
  //       });
  //     });
  //   } else {
  //     // console.warn('No files selected.');
  //   }
  // }
  

  /** Handle File Selection & Upload */
  // onFileSelected(event: Event): void {
  //   console.log("click this event 1")
  //   const input = event.target as HTMLInputElement;
  //   if (input.files && input.files.length === 0) 
  //     return;

  //     let file = input.files[0];
  //     const formData = new FormData();
  //     formData.append('file', file);

  //   console.log("click this event before api hit 2")

  //     this.http.post(`${this.config}/common/upload`, formData).subscribe({
  //       next: async (response: any) => {
  //         if (response) {
  //           this.filename = response.data.name;
  //           this.filepath = response.data.foPa || response.data.filePath; // Ensure correct key name
  //           this.mediatype = response.data.mimetype;

  //           console.log('Uploaded File:', this.filename, this.filepath, this.mediatype);

  //           const rowId = this.role === 1 ? this.userDetails?.row_id : this.patientDetails?.row_id;
  //           if (!rowId) {
  //             this.errorMessage = 'User ID not found.';
  //             return;
  //           }
  //           console.log("row_id",rowId)
  //           const data = {
  //             receiver_row_id: null,
  //             file_name: this.filename,
  //             file_path: this.filepath,
  //             media_type: this.mediatype,
  //           };

  //           try {
  //   console.log("click this event before upload api hit 2")

  //             const resp = await this.apiController.uploadmedia(data);
  //             console.log("Upload Response:", resp);
  //             this.successMessage = 'File uploaded successfully!';
  //   console.log("click this event after upload api hit 3")
  //   input.value = ''

  //           } catch (error) {
  //             console.error("Upload failed:", error);
  //             this.errorMessage = 'File upload failed. Please try again.';
             
  //           }
  //         } else {
  //           this.errorMessage = 'Invalid server response.';
  //         }
  //       },
  //       error: (error) => {
  //         console.error('Upload failed:', error);
  //         this.errorMessage = 'File upload failed. Please try again.';
  //       },
  //     });
  //   }



   /** Handle File Selection & Upload */
   onFileSelected(event: Event): void {
    // console.log("click this event 1")
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {

      const files = Array.from(input.files); // Handle multiple files

      files.forEach((files) => {
        let file = input.files[0];
        const formData = new FormData();
        formData.append('file', file);
  
     // console.log("click this event before api hit 2")
  
        this.http.post(`${this.config}/common/upload`, formData).subscribe({
          next: async (response: any) => {
            if (response) {
              this.filename = response.data.name;
              this.filepath = response.data.foPa || response.data.filePath; // Ensure correct key name
              this.mediatype = response.data.mimetype;
  
             console.log('Uploaded File:', this.filename, this.filepath, this.mediatype);
  
              const rowId = this.role === 1 ? this.userDetails?.row_id : this.patientDetails?.row_id;
              if (!rowId) {
                this.errorMessage = 'User ID not found.';
                return;
              }
             // console.log("row_id",rowId)
              const data = {
                receiver_row_id: null,
                file_name: this.filename,
                file_path: this.filepath,
                media_type: this.mediatype,
              };
  
              try {
      //console.log("click this event before upload api hit 2")
  
                const resp = await this.apiController.uploadmedia(data);
              //  console.log("Upload Response:", resp);
                this.successMessage = 'File uploaded successfully!';
    //  console.log("click this event after upload api hit 3")
      input.value = ''
  
              } catch (error) {
               // console.error("Upload failed:", error);
                this.errorMessage = 'File upload failed. Please try again.';
               
              }
            } else {
              this.errorMessage = 'Invalid server response.';
            }
          },
          error: (error) => {
            //console.error('Upload failed:', error);
            this.errorMessage = 'File upload failed. Please try again.';
          },
        });
      })
    
   
    }
    else{
       console.warn('No files selected.');
    }
   }

  /** Fetch Media from Server */
  async fetchFiles() {


    if(this.role==2){
      this.patientDetails = JSON.parse(localStorage.getItem("userDeatials"));   


    }else{
      
      this.userDetails = JSON.parse(localStorage.getItem("userDeatials"));
      
    }


    const rowId = this.role === 1 ? this.userDetails?.row_id : this.patientDetails?.row_id;
    if (!rowId) {
      this.errorMessage = 'User ID not found.';
      return;
    }

    const data = {
      row_id: rowId,
      media_type: this.Formate,
    };

    try {
      const resp = await this.apiController.fetchmedia(data);
      this.uploadedFiles = resp.data.map((file: any) => ({
        filePath: file.media_link,
        mediaType: file.media_type,
        sender:file.sender,
        time:file.time
      }));

     // console.log("Fetched media:", this.uploadedFiles);
    } catch (error) {
    //  console.error("Fetch error:", error);
      this.errorMessage = "Failed to fetch media.";
    }
  }
}
