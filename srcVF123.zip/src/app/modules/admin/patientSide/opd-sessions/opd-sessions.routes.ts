import { Routes } from '@angular/router';
import { OpdSessionsComponent } from 'app/modules/admin/patientSide/opd-sessions/opd-sessions.component';

export default [
    {
        path: '',
        component: OpdSessionsComponent,
    },
] as Routes;
