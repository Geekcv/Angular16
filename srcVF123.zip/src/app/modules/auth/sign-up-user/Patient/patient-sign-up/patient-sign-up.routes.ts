import { Routes } from '@angular/router';
import { PatientSignUpComponent } from 'app/modules/auth/sign-up-user/Patient/patient-sign-up/patient-sign-up.component';

export default [
    {
        path: '',
        component: PatientSignUpComponent,
    },
] as Routes;
