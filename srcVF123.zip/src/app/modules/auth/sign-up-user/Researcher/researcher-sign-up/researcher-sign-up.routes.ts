import { Routes } from '@angular/router';
import { ResearcherSignUpComponent } from 'app/modules/auth/sign-up-user/Researcher/researcher-sign-up/researcher-sign-up.component';

export default [
    {
        path: '',
        component: ResearcherSignUpComponent,
    },
] as Routes;
