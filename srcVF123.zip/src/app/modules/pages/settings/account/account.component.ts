

import { TextFieldModule } from '@angular/cdk/text-field';
import {
    ChangeDetectionStrategy,
    Component,
    OnInit,
    ViewEncapsulation,
} from '@angular/core';
import {
    FormsModule,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';

interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  doctor_name: string;
  user_contact_number: string;
  user_password: string;
  user_row_id: string;
}

interface Patient{
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name: string;
  user_password: string;
  user_contact_number: string;
}

@Component({
    selector: 'settings-account',
    templateUrl: './account.component.html',
    encapsulation: ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush,
    imports: [
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        TextFieldModule,
        MatSelectModule,
        MatOptionModule,
        MatButtonModule,
        
    ],
})
export class SettingsAccountComponent implements OnInit {
    accountForm: UntypedFormGroup;
      userDeatials: Doctor = {
        doctor_email: '',
        doctor_gender: '',
        doctor_name: '',
        user_contact_number: '',
        user_password: '',
        user_row_id: ''
      };
      role :any ='';
    
      patientDeatials: Patient = {
        patient_age: '',
      patient_email: '',
      patient_gender: '',
      patient_name: '',
      user_password: '',
      user_contact_number: ''
      };
    
    
      constructor(private _formBuilder: UntypedFormBuilder) {
        this.role=  localStorage.getItem('role')
    
        if(this.role==2){
          this.patientDeatials = JSON.parse(localStorage.getItem("userDeatials"));
    
        }else{
          
          this.userDeatials = JSON.parse(localStorage.getItem("userDeatials"));
        }
    
        // console.log("my userDeatials", this.userDeatials);
      }
    
      ngOnInit(): void {
        if (this.role==2) {
          this.accountForm = this._formBuilder.group({
            name: [this.patientDeatials.patient_name],
            email: [this.patientDeatials.patient_email, Validators.email],
            phone: [this.patientDeatials.user_contact_number],
            gender: [this.patientDeatials.patient_gender]
    
          });
          
        }else{
          this.accountForm = this._formBuilder.group({
            name: [this.userDeatials.doctor_name],
            email: [this.userDeatials.doctor_email, Validators.email],
            phone: [this.userDeatials.user_contact_number],
            gender: [this.userDeatials.doctor_gender]
    
          });
        }
       
      }
    
    
}
