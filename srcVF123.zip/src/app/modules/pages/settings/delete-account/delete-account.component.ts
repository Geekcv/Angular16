import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { DeldialogComponent } from 'app/modules/admin/dialog/deldialog/deldialog.component';

@Component({
  selector: 'app-delete-account',
  imports: [  MatIconModule],
  templateUrl: './delete-account.component.html',
})
export class DeleteAccountComponent {

  constructor(
     
        private _matDialog: MatDialog
    ) { 
 
  
    }
  

 deletebtn(){
      
          const dialogRef = this._matDialog.open(DeldialogComponent);
          // dialogRef.afterClosed().subscribe((result) => {
          //     console.log('dialog was closed!');
          // });
      
          console.log("delete.....")
        }

}
