import { HttpClient } from '@angular/common/http';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { DiagnosisComponent } from 'app/modules/admin/dialog/doctor/video/diagnosis/diagnosis.component';
import { FormulationComponent } from 'app/modules/admin/dialog/doctor/video/formulation/formulation.component';
import { HistoryComponent } from 'app/modules/admin/dialog/doctor/video/history/history.component';
import { RateComponent } from 'app/modules/admin/dialog/doctor/video/rate/rate.component';
import { config } from '../../../../../../config';
import { FormsModule } from '@angular/forms';


interface mediaMetadata {
  date: string;
  description: string;
  filename: string;
  filesize: string;
  time: string;
  media_link: string;
}

interface Patient {

  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name: string;
  user_contact_number: string;
  user_password: string;
  row_id: string;
}


interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  doctor_name: string;
  user_contact_number: string;
  user_password: string;
  row_id: string;
}


@Component({
  selector: 'app-telepsychiatry-sessions',
  imports: [
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatInputModule,
    MatPaginatorModule, FormsModule
  ],
  templateUrl: './telepsychiatry-sessions.component.html',
  styleUrl: './telepsychiatry-sessions.component.css'
})
export class TelepsychiatrySessionsComponent {


  file: any;
  size: string = '';
  file_name: any;
  file_description: any;
  config: string = config.apiBaseURL;
  filename: string = '';
  filepath: string = '';
  mediatype: string = '';
  userDetails: Doctor | null = null;
  role: any;
  patientDetails: Patient | null = null;
  videomediadata: mediaMetadata[] = [];



  uploadbtn() {
    this.isclicked = true;

    this.isratebtn = false;
    this.isdiagnosisbtn = false;
    this.isformulationbtn = false;
    this.ishistorybtn = false;
    this.isviewvideoboxbtn = false;

    // const dialogRef = this._matDialog.open(UploadComponent);

  }


  patient: any;
  patientname: any;
  row_id: any;
  media_link: any;
   mediaData:any;
  isclicked = false;

  @ViewChild('videoPlayer') videoPlayer!: ElementRef<HTMLVideoElement>


  constructor(
    private _matDialog: MatDialog,
    private Apicontroller: ApicontrollerService,
    private route: ActivatedRoute,
    private apiController: ApicontrollerService,
    private router: Router, private http: HttpClient,


  ) {
    this.patientsId = this.route.snapshot.paramMap.get('id');

    this.FetchAudioMedia()

  }


  displayedColumns: string[] = [
    // 'user_row_id',
    'time',
    // 'patient_email',
    // 'user_contact_number',
    // 'patient_gender',    


    'actions'
  ];


  patientsId!: string | null; // Holds the patientsId ID from the route

  isviewbtn: any = false;


  isviewvideoboxbtn: any = false;
  ishistorybtn: any = false;
  isformulationbtn: any = false
  isdiagnosisbtn: any = false;
  isratebtn: any = false;

  selectedRow: any = null;
  selectedAction: string | null = null; // Store selected action separately

  viewvideoboxbtn(media: any) {
    this.selectedRow = media;
    this.selectedAction = 'view';

    this.isviewvideoboxbtn = true;
    this.ishistorybtn = false;
    this.isformulationbtn = false;
    this.isdiagnosisbtn = false;
    this.isratebtn = false;

    this.isclicked = false;


    this.media_link = media.media_link;
setTimeout(() => {
      this.videoPlayer.nativeElement.load()
    })

  }

  historybtn(media: any) {
    this.selectedRow = media;
    this.selectedAction = 'history';

    this.ishistorybtn = true;
    this.isviewvideoboxbtn = false;
    this.isformulationbtn = false;
    this.isdiagnosisbtn = false;
    this.isratebtn = false;

    this.isclicked = false;
    this.mediaData = media

       this.media_link = media.media_link;
setTimeout(() => {
      this.videoPlayer.nativeElement.load()
    })


  }

  formulationbtn(media: any) {
    this.selectedRow = media;
    this.selectedAction = 'formulation';

    this.isformulationbtn = true;
    this.ishistorybtn = false;
    this.isviewvideoboxbtn = false;
    this.isdiagnosisbtn = false;
    this.isratebtn = false;
    this.isclicked = false;

    this.mediaData = media

   this.media_link = media.media_link;
setTimeout(() => {
      this.videoPlayer.nativeElement.load()
    })


  }

  diagnosisbtn(media: any) {
    this.selectedRow = media;
    this.selectedAction = 'diagnosis';

    this.isdiagnosisbtn = true;
    this.isformulationbtn = false;
    this.ishistorybtn = false;
    this.isviewvideoboxbtn = false;
    this.isratebtn = false;
    this.isclicked = false;
    this.mediaData = media


    this.media_link = media.media_link;
setTimeout(() => {
      this.videoPlayer.nativeElement.load()
    })
  }

  ratebtn(media: any) {
    this.selectedRow = media;
    this.selectedAction = 'rate';

    this.isratebtn = true;
    this.isdiagnosisbtn = false;
    this.isformulationbtn = false;
    this.ishistorybtn = false;
    this.isviewvideoboxbtn = false;
    this.isclicked = false;
    this.mediaData = media


    this.media_link = media.media_link;
setTimeout(() => {
      this.videoPlayer.nativeElement.load()
    })
  }


 



  onFileSelected(event: Event): void {
    // console.log("click this event 1")
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {

      const files = Array.from(input.files); // Handle multiple files

      files.forEach((files) => {
        this.file = input.files[0];
        const formData = new FormData();
        formData.append('file', this.file);

        console.log("selected file", this.file)

        this.file_name = this.file.name

        input.value = ''

      })


    }
    else {
      console.warn('No files selected.');
    }
  }



  ngOnInit(): void {
    this.FetchAudioMedia();

    this.patientsId = this.route.snapshot.paramMap.get('id');
    // console.log("patientsId",this.patientsId)

    this.fetchSefesficpatients();
    const userData = localStorage.getItem('userDeatials');

    this.patientDetails = JSON.parse(userData);
  }


  async fetchSefesficpatients(): Promise<void> {
    try {
      const response = await this.Apicontroller.fetchSefesficpatients(this.patientsId);
      this.patientname = response.data[0].patient_name || []; // Ensure `data` exists in the API response
      console.log("patient----", response.data[0].patient_name)

    } catch (error) {
      // console.error('Error fetching clients:', error);
    }
  }

  page: number = 1; // Default to first page
  async Patients() {
    try {
      const resp = await this.Apicontroller.fetchPatients('common', this.page);
      //  console.log("Patients", resp);
      this.patient = resp.data as Patient[]; // Type assert to Doctor[]
    } catch (error) {
      console.error("Error fetching doctors:", error);
    }

  }

  

  videodata: any;
  async FetchAudioMedia() {
    try {
      const data = {
        row_id: this.patientsId,
        media_type: 'video/mp4',
      };

      console.log("data", data)

      const resp = await this.Apicontroller.fetchteleSessionMedia(data);
      console.log("audio medi-------------a", resp);
      this.videomediadata = resp as mediaMetadata[]; // Type assert to Doctor[]
    } catch (error) {
      console.error("Error fetching audio media:", error);
    }

  }


  viewchatsdialogboxbtn() {
    //  const dialogRef = this._matDialog.open(ViewChatComponent,{data: {patient:  this.row_id}});
  }

  historychatsdialogboxbtn() {
    const dialogRef = this._matDialog.open(HistoryComponent, { data: { medialink: this.media_link,mediadata:this.mediaData} });

  }

  formulationdialogboxbtn() {
    const dialogRef = this._matDialog.open(FormulationComponent, { data: { medialink: this.media_link,mediadata:this.mediaData} });

  }

  diagnosisdialogboxbtn() {
    const dialogRef = this._matDialog.open(DiagnosisComponent, { data: { medialink: this.media_link,mediadata:this.mediaData} });

  }

  ratedialogboxbtn() {
    const dialogRef = this._matDialog.open(RateComponent, { data: { medialink: this.media_link,mediadata:this.mediaData} });

  }
  goback() {
    // console.log("click this button")
    this.router.navigate(['/Viewpatients'])
  }

  uploadaudio() {

    const formData = new FormData();
    formData.append('file', this.file);

    this.http.post(`${this.config}/common/upload`, formData).subscribe({
      next: async (response: any) => {
        if (response) {
          this.filename = response.data.name;
          this.filepath = response.data.foPa || response.data.filePath; // Ensure correct key name
          this.mediatype = response.data.mimetype;
          this.size = response.data.size;

          console.log('Uploaded File:', this.filename, this.filepath, this.mediatype);

          const rowId = this.role === 1 ? this.userDetails?.row_id : this.patientDetails?.row_id;
          if (!rowId) {
            // this.errorMessage = 'User ID not found.';
            console.log("User ID not found")
            return;
          }
          // console.log("row_id",rowId)
          const data = {
            pat_row_id: this.patientsId,
            file_name: this.filename,
            file_path: this.filepath,
            media_type: this.mediatype,
            filename: this.file_name,
            description: this.file_description,
            filesize: this.size

          };

          try {
            console.log("click this event before upload api hit 2")

            const resp = await this.apiController.uploadmediatelepsychiatrySessions(data);
            this.file_name = " ";
            this.file_description = " "
            this.file = 0

            console.log("Upload Response:", resp);
            // this.successMessage = 'File uploaded successfully!';
            //  console.log("click this event after upload api hit 3")
            //  input.value = ''

          } catch (error) {
            console.error("Upload failed:", error);
            // this.errorMessage = 'File upload failed. Please try again.';

          }
        } else {
          // this.errorMessage = 'Invalid server response.';
          console.log("Invalid server response")

        }
      },
      error: (error) => {
        console.error('Upload failed:', error);
        // this.errorMessage = 'File upload failed. Please try again.';
      },
    });


  }

  delaudiobtn() {
    this.file = 0;
    this.file_name = ''

  }
}
