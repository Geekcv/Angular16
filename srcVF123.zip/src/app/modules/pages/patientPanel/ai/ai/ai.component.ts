import { CurrencyPipe, NgClass } from '@angular/common';
import {
    ChangeDetectionStrategy,
    Component,
    OnDestroy,
    OnInit,
    ViewEncapsulation,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatRippleModule } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslocoModule } from '@jsverse/transloco';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
// import { ProjectService } from 'app/modules/admin/dashboards/project/project.service';
import { ApexOptions, NgApexchartsModule } from 'ng-apexcharts';
import { Subject, takeUntil } from 'rxjs';

interface Doctor {
    doctor_email: string;
    doctor_gender: string;
    doctor_name: string;
    user_contact_number: string;
    user_password: string;
    user_row_id: string;
  }
  
  interface Patient{
    patient_age: string;
    patient_email: string;
    patient_gender: string;
    patient_name: string;
    user_password: string;
    user_contact_number: string;
  }



@Component({
  selector: 'app-ai',
  imports: [
    TranslocoModule,
        MatIconModule,
        MatButtonModule,
        MatRippleModule,
        MatMenuModule,
        MatTabsModule,
        MatButtonToggleModule,
        NgApexchartsModule,
        MatTableModule,
  ],
  templateUrl: './ai.component.html'
})
export class AiComponent {

   patientsId: string;
    patientname: any;
  
        userDeatials: Doctor = {
        doctor_email: '',
        doctor_gender: '',
        doctor_name: '',
        user_contact_number: '',
        user_password: '',
        user_row_id: ''
      };
      role :any ='';
    
      patientDeatials: Patient = {
        patient_age: '',
      patient_email: '',
      patient_gender: '',
      patient_name: '',
      user_password: '',
      user_contact_number: ''
      };

      names :any = '';

  
      constructor(     
              private _matDialog: MatDialog,
                   private Apicontroller: ApicontrollerService,
                    private route: ActivatedRoute,
                           private router: Router,
              
            ) {      
            
                this.role=  localStorage.getItem('role')

    if(this.role==2){
      this.patientDeatials = JSON.parse(localStorage.getItem("userDeatials"));

      this.names = this.patientDeatials.patient_name

      //console.log("name--",name)

    }else{
      
      this.userDeatials = JSON.parse(localStorage.getItem("userDeatials"));

      this.names = this.userDeatials.doctor_name
    }
            }
  
  
    ngOnInit(): void {
     
      this.patientsId = this.route.snapshot.paramMap.get('id');
      // console.log("patientsId",this.patientsId)
  
      this.fetchSefesficpatients();  
    }
  
  
    async fetchSefesficpatients(): Promise<void> {
      try {
        const response = await this.Apicontroller.fetchSefesficpatients(this.patientsId);
        this.patientname = response.data[0].patient_name || []; // Ensure `data` exists in the API response
        console.log("patient----",response.data[0].patient_name)
  
      } catch (error) {
        // console.error('Error fetching clients:', error);
      }
    }

    goback(){
      // console.log("click this button")
      this.router.navigate(['/Viewpatients'])
    }

}
