import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { EditPatientsInfoComponent } from 'app/modules/admin/dialog/edit-patients-info/edit-patients-info.component';
import { SchedulePatientsappointComponent } from 'app/modules/admin/dialog/schedule-patientsappoint/schedule-patientsappoint.component';
import { SuspendPatientComponent } from 'app/modules/admin/dialog/suspend-patient/suspend-patient.component';


interface Doctor {
    doctor_email: string;
    doctor_gender: string;
    doctor_name: string;
    user_contact_number: string;
    user_password: string;
    user_row_id: string;
  }
  
  interface Patient{
    patient_age: string;
    patient_email: string;
    patient_gender: string;
    patient_name: string;
    user_password: string;
    user_contact_number: string;
  }


  
@Component({
  selector: 'app-profile',
  imports: [
     MatButtonModule,
         MatIconModule,
        CommonModule,
        MatTableModule,
        MatFormFieldModule, MatSelectModule,FormsModule,MatGridListModule,MatCardModule,
  ],
  templateUrl: './profile.component.html'
})
export class ProfileComponent {

  patient: Patient[] = [];
   
  displayedColumns: string[] = [
    // 'user_row_id',
    'patient_name',
    'patient_email',
    'user_contact_number',
    'patient_gender',
    'patient_age',
    'user_password','actions'

  ];
  role: number;
  userDetails: Doctor | null = null;
      patientDetails: Patient | null = null;
  patientsId!: string | null; // Holds the patientsId ID from the route
  patientname: any;
  patientStatus: any;


    userDeatials: Doctor = {
        doctor_email: '',
        doctor_gender: '',
        doctor_name: '',
        user_contact_number: '',
        user_password: '',
        user_row_id: ''
      };
      // role :any ='';
    
      patientDeatials: Patient = {
        patient_age: '',
      patient_email: '',
      patient_gender: '',
      patient_name: '',
      user_password: '',
      user_contact_number: ''
      };

      names :any = '';



   constructor(
        private route: ActivatedRoute,
        private router: Router,
        private apiController: ApicontrollerService,
                    private _matDialog: MatDialog
        
        
      ) {
    this.patientsId = this.route.snapshot.paramMap.get('id');

        this.role = Number(localStorage.getItem('role')) || 0; // Convert role to a number
      this.loadUserDetails();
      this.refresh()

      //  this.role=  localStorage.getItem('role')

    if(this.role==2){
      this.patientDeatials = JSON.parse(localStorage.getItem("userDeatials"));

      this.names = this.patientDeatials.patient_name

      //console.log("name--",name)

    }else{
      
      this.userDeatials = JSON.parse(localStorage.getItem("userDeatials"));

      this.names = this.userDeatials.doctor_name
    }

      }
  
  
      /** Load User Details from localStorage */
    private loadUserDetails(): void {
      const userData = localStorage.getItem('userDeatials');
      if (userData) {
        if (this.role === 1) {
          this.userDetails = JSON.parse(userData);
        } else {
          this.patientDetails = JSON.parse(userData);
        }
      }
    }


    ngOnInit() {
      this.patientsId = this.route.snapshot.paramMap.get('id');
      // console.log("patientsId",this.patientsId)
  
      this.fetchSefesficpatients();  

      this.fetchSefesficpatientsname();  

      this.refresh()
      
    }

    async fetchSefesficpatients(): Promise<void> {
      try {
        const response = await this.apiController.fetchSefesficpatients(this.patientsId);
        this.patient = response.data || []; // Ensure `data` exists in the API response
        this.patientStatus = response.data[0].active

        console.log("patient details <----",this.patient,"status",this.patientStatus)
      } catch (error) {
        // console.error('Error fetching clients:', error);
      }
    }

    async fetchSefesficpatientsname(): Promise<void> {
      try {
        const response = await this.apiController.fetchSefesficpatients(this.patientsId);
        this.patientname = response.data[0].patient_name || []; // Ensure `data` exists in the API response
        // console.log("doctor----",this.patient)
      } catch (error) {
        // console.error('Error fetching clients:', error);
      }
    }

    editProfile(patient: any) {
      // Logic to open the edit profile form/modal
      console.log('Edit Profile for', patient);

        // const dialogRef = this._matDialog.open(EditPatientsInfoComponent, {data: {patient: this.patientsId}});

        const dialogRef = this._matDialog.open(EditPatientsInfoComponent, {data: {patient: patient}});

    }
  
    suspendPatient(patient: any) {
      // Logic to suspend the patient
      this.fetchSefesficpatients();  

      console.log('Suspend Patient', patient);

      const dialogRef = this._matDialog.open(SuspendPatientComponent, {data: {patient: patient}});

    }
  
    rescheduleAppointment(patient: any) {
      // Logic to reschedule the patient's appointment
      console.log('Reschedule Appointment for', patient);
      const dialogRef = this._matDialog.open(SchedulePatientsappointComponent, {data: {patient: patient}});

    }

    refresh(){
      console.log("refresh----")
    this.fetchSefesficpatients();  
    }

    goback(){
      // console.log("click this button")
      this.router.navigate(['/Viewpatients'])
    }

}
