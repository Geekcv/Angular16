import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SampleBookComponent } from './sample-book.component';

describe('SampleBookComponent', () => {
  let component: SampleBookComponent;
  let fixture: ComponentFixture<SampleBookComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SampleBookComponent]
    });
    fixture = TestBed.createComponent(SampleBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
