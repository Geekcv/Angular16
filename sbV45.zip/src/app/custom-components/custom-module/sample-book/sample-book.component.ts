import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { Table } from 'primeng/table';
import { FormBuilderComponent } from '../../form-builder/form-builder.component';
import { FormsService } from 'src/app/constants/forms.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { UtiltiesService } from 'src/app/services/utilties.service';
import { JsonListService } from 'src/app/constants/json-list.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sample-book',
  templateUrl: './sample-book.component.html',
  styleUrls: ['./sample-book.component.css']
})

export class SampleBookComponent {
 @ViewChild('dt') dt: Table | undefined;
  @Output() editEvent = new EventEmitter();
  @Output() deleteEvent = new EventEmitter();
  @Output() fetchNextData = new EventEmitter();
  @Input() selectedtableData: any = [];
  @Input() searchFields: any = [];
  @Input() tableTitle: any = "Record List";
  @Input() totalRecords: any = 4;
  @Input() rows: any = 4;
  @Input() noofpages: any = 4;
  @Input() allowDelete: any = false;
  @Input() allowEdit: any = true;
@Input() width: any = '75rem';
@Input() height: any = '85rem';
  @Input() tableData: any = [

  ];
  @Input() filteredData: any = this.tableData;
  loading: any = false;
  viewDialog: boolean = false;
  selectedViewData: any = null;
  Examlogdata:any = [];
  temCenter:any = []
  temfaculty:any = []
  temExam:any = []
  temclass :any =[]

    // --- Add properties for the dialog ---
    displayDialog: boolean = false;
    displayEditDialog:boolean = false;
    selectedStudent: any = null; // Declare selectedStudent
    exams: any[] = []; // Example: [{label: 'Exam 1', value: 'E1'}, {label: 'Exam 2', value: 'E2'}]
    classes: any[] = []; // Example: [{label: 'Class A', value: 'C1'}, {label: 'Class B', value: 'C2'}]
    centers: any[] = []; // Example: [{id: 1, name: 'Center A'}, {id: 2, name: 'Center B'}] - This holds all centers
    filteredCenters: any[] = []; // For autocomplete suggestions
    selectedFaculty: any = null;
    selectedExam: any = null;
    selectedClass: any = null;
    selectedCenter: any = null;
    faculty:any[]=[];
    city_name:any;
    state_name:any;

  selectedGender: any ; // Default to 'All'
query: any;

  @ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;


  constructor(public formsService: FormsService, private apiController: ApicontrollerService,public jsonlist:JsonListService,
    private utiltiesService: UtiltiesService ,
        private router: Router, private jsonList: JsonListService,
  ) {
  }

  ngOnChanges() {
    this.filteredData = this.tableData;
  }

  ngOnInit() {
    this.filteredData = this.tableData;
    this.loadInitialData();
  }

  

  loadInitialData() {
    // Placeholder: Load your exam, class, and center data here
    // Example:
    this.exams = [];
    this.classes = [];
    this.centers = [];
    // this.fetchClasses();

  }

  @Input() tableDataHeader: any = [
  ];
  

  //  tableDataRows: any = this.formsService.studentTableData.tableDataRows;

  @Input() tableDataRows:any =[

  ]


  async edit(pr: any) {
    console.log("pr-->",pr.row_id)
    this.editEvent.emit(pr);  
   this.router.navigate(['/addSamplebook', pr.row_id]);  

  }

  delete(pr: any) {
    this.deleteEvent.emit(pr);
  }

  filterByQuery(query: string): void {
          const trimmedQuery = query.trim().toLowerCase();
        
          console.log("trimmedQuery",trimmedQuery)
          // this.tableData = trimmedQuery

    this.tableData = this.filterItems(this.filteredData, trimmedQuery);

         
        }

  

  
  openViewDialog(rowItem: any): void {
    this.selectedViewData = rowItem;
    this.viewDialog = true;
  }

  filterGlobal(event: Event) {

    const input = event.target as HTMLInputElement;
    const value = input?.value || '';

    // console.log("data-",value,"filterdata",this.tableData)
    this.tableData = this.filterItems(this.filteredData, value);
  }
  onPageChagne(event: any) {
    this.loading = true;
   // console.log(event);
    var page = (event.first / event.rows) + 1;

    var nextPage = { page: page, limit: event.rows };
    this.fetchNextData.emit(nextPage);
    this.loading = false;
  }

  sortItems(items: any[], sortField: string, sortOrder: number): any[] {
    if (!sortField || sortOrder === 0) {
      return items;
    }

    return items.sort((a, b) => {
      const value1 = a[sortField];
      const value2 = b[sortField];
      const result = value1 < value2 ? -1 : value1 > value2 ? 1 : 0;
      return sortOrder * result;
    });
  }
  filterItems(items: any[], filter: string): any[] {
    if (!filter) {
      console.log("inside filter ")
      return items;
    }
    return items.filter(item => {
      console.log("items",item)
      return this.searchFields.some((field: any) => {
        console.log("feild",field)
        return item[field]?.toString().toLowerCase().includes(filter.toLowerCase());
      });
    });
  }
  onSort(event: any) {
   // console.log(event);
    this.loading = true;
    this.tableData = this.sortItems(this.tableData, event.field, event.order);

    this.loading = false;
  }





 








 








}