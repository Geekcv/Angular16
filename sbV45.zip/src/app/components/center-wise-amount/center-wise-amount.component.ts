import { Component } from '@angular/core';
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-center-wise-amount',
  templateUrl: './center-wise-amount.component.html',
  styleUrls: ['./center-wise-amount.component.css']
})
export class CenterWiseAmountComponent {
 // Dropdown options
  examSessions: any[] = [];
  classes: any[] = [];
  centers: any[] = [];
  transposedData: any[] = [];
  reportData: any[] = []; 
  selectedAccount: any = 'All'; // Default to 'All'
  temCenter:any = []


  faculty: any[] = [];
  temfaculty: any = [];
  temExam: any = [];
  temclass: any = [];

  // Selected filter values
  selectedFaculty: string = '0'; // Default value
  selectedExamSession: any = null;
  selectedClass: any = null; // Optional filter
  selectedCenter: any = null; // Optional filter
 

  // Data for the report table
  filteredMarksData: any[] = [];
  submitted: boolean = false;

  constructor(
    private apiController: ApicontrollerService,
    private utiltiesService: UtiltiesService,
    public jsonlist: JsonListService // For dropdown data
  ) { }

  ngOnInit(): void {
    this.loadInitialData();
    this.fetchClasses(); // Fetch initial classes based on default faculty
  }

  async loadInitialData() {
    // Fetch exam sessions
    this.examSessions = [];
    // Fetch centers (assuming you want all centers initially)
    this.centers =  [];
    this.fetchExams();
    this.fetchExamCenter();
  }

  async fetchExams(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fechExam(page, limit);

    console.log('temExam---', tempClientDAta);

    if (tempClientDAta != false) {
      // console.log("exams========",tempClientDAta);
      this.temExam = [];
      this.temExam = tempClientDAta.map((item: any) => ({
        title: `${item.session_name}`,
        value: item.row_id,
        data: item,
      }));
    }
  }



async fetchExamCenter(page = 1, limit = 500) {
    const tempClientData = await this.apiController.fetchExamCenter(
      page,
      limit
    );
    console.log('data', tempClientData);
    if (tempClientData !== false) {
      this.temCenter = [];
      this.temCenter = tempClientData.map((item: any) => ({
        title: `${item.center} - ${item.center_code}`,
        code: item.center_code?.toString(),
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchClasses() {
    this.selectedClass = null; // Reset class when faculty changes
    this.classes = [];
    this.submitted = false;
    if (this.selectedFaculty) {
      console.log(`Fetching classes for faculty: ${this.selectedFaculty}`);
      // Fetch classes based on selectedFaculty ('Board' or 'Thokra')
      // You might need separate API calls or pass the faculty type
      this.classes = await this.apiController.fetchClassesByFaculty(this.selectedFaculty,1,100) || []; // Adapt/Create this API call
      // Map data if needed
      console.log('Fetched classes:', this.classes);
    }
  }


  async fetchFilteredMarks() {
    this.submitted = true;
    this.filteredMarksData = []; // Clear previous results
    if (!this.selectedExamSession) {
      console.error("Please select Exam Session.");
      return;
    }

    console.log('Fetching filtered marks for:',  this.selectedExamSession,  this.selectedCenter);

    // Call API to fetch filtered marks list
    const fetchedData = await this.apiController.CenterWiseAmountReport(     
        this.selectedExamSession, 
        this.selectedCenter, // Pass null if not selected     
        this.selectedAccount,     
    ) || []; // Create this API call

    console.log("fetchded ----->",fetchedData)
    // Map fetchedData to the structure needed by the table
    this.filteredMarksData = fetchedData.data.map((item: any) => ({
        rollNo: item.roll_no,
        studentname: item.student_name,
        fathername: item.father_name, // Adjust field name based on API     
        address: item.address,
        classname: item.class_name, 
        centerCode: item.center_code, 
        mobile_no:item.mobile_no,     
        marks:item.marks, 
        prize:item.prize, 
        centerheadAcNo:item.center_head_ac_no, 
        centerheadName:item.center_head_name, 
        centerheadifsccode:item.center_head_ifsc_code,  
        marksPercentage:item.marksPercentage,     
        id: item.row_id // Or another unique identifier
    }));
    console.log('fetchedData:', fetchedData);

    this.reportData = [];
    
    for(var i=0;i<fetchedData.marks_wise_count.length;i++){
      this.reportData.push(
        {
          "Marks":fetchedData.marks_wise_count[i]['marks'],
          "Total marks":fetchedData.marks_wise_count[i]['total_marks']
        }
      );
    }
    const keys = Object.keys(this.reportData[0]);
    this.transposedData = keys.map(key => {
      return {
        key,
        values: this.reportData.map(item => item[key])
      };
    });
  }

  // --- Helper methods for display ---
  getSessionName(id: any): string | null {
    const item = this.examSessions.find(e => e.id === id);
    return item ? item.name : null;
  }

  getClassName(id: any): string | null {
    const item = this.classes.find(c => c.id === id);
    return item ? item.name : null;
  }

  getCenterName(id: any): string | null {
    const item = this.centers.find(c => c.id === id);
    return item ? item.name : null;
  }
  // --- End Helper methods ---

  exportData() {
    if (this.filteredMarksData && this.filteredMarksData.length > 0) {
      console.log("Exporting data...", this.filteredMarksData);
      this.filteredMarksData.forEach((item: any) => {
        delete item.id;

      });
      this.utiltiesService.exportAsExcelFile(this.filteredMarksData, 'FilteredMarksReport');
    } else {
      console.warn("No data to export.");
    }
  }

  printReport() {
    this.utiltiesService.printReport('report', 'StudentMarksFilterReport'); // Adjust the ID of the report section
  }

  searchValues: { [key: string]: string } = {};
  showDropdown: { [key: string]: boolean } = {};
  filteredOptions: { [key: string]: any[] } = {};
  focusedIndex: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions(id: string) {
    const query = this.searchValues[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions[id] = [...this.temCenter];
    } else {
      this.filteredOptions[id] = this.temCenter.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex[id] = 0;
  }

  selectOption(id: string, option: any) {
    this.searchValues[id] = option.title;
    this.selectedCenter = option.value;
    this.showDropdown[id] = false;
  }

  hideDropdownWithDelay(id: string) {
    setTimeout(() => {
      this.showDropdown[id] = false;
    }, 200);
  }

  handleKeydown(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions[id] || [];
    let index = this.focusedIndex[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex[id] = index;

      // Select option immediately
      this.selectOption(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex[id] = index;

      // Select option immediately
      this.selectOption(id, options[index]);

      event.preventDefault();
    }
  }

  searchValues_Exam: { [key: string]: string } = {};
  showDropdown_Exam: { [key: string]: boolean } = {};
  filteredOptions_Exam: { [key: string]: any[] } = {};
  focusedIndex_Exam: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_Exam(id: string) {
    const query = this.searchValues_Exam[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_Exam[id] = [...this.temExam];
    } else {
      this.filteredOptions_Exam[id] = this.temExam.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_Exam[id] = 0;
  }

  selectOption_Exam(id: string, option: any) {
    this.searchValues_Exam[id] = option.title;
    this.selectedExamSession = option.value;
    this.showDropdown_Exam[id] = false;
    this.fetchClasses();
  }

  hideDropdownWithDelay_Exam(id: string) {
    setTimeout(() => {
      this.showDropdown_Exam[id] = false;
    }, 200);
  }

  handleKeydown_Exam(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_Exam[id] || [];
    let index = this.focusedIndex_Exam[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    }
  }
}
