import { Component } from '@angular/core';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {

  totalStudent:any;
totalCenter:any;

    constructor(
      private apiController: ApicontrollerService,
      private utiltiesService: UtiltiesService // For export
    ) { }
  
     ngOnInit(): void {
      this.fetchStudentcount()
      this.fetchCenterCount()
  }


 async fetchStudentcount(){
    this.totalStudent = await this.apiController.fetchCount('students');

  }

  async fetchCenterCount(){
    this.totalCenter = await this.apiController.fetchCount('centers');

  }

}
