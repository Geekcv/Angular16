import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SamplebookListComponent } from './samplebook-list.component';

describe('SamplebookListComponent', () => {
  let component: SamplebookListComponent;
  let fixture: ComponentFixture<SamplebookListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SamplebookListComponent]
    });
    fixture = TestBed.createComponent(SamplebookListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
