import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { FormsService } from 'src/app/constants/forms.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from 'src/app/custom-components/form-builder/form-builder.component';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-samplebook-list',
  templateUrl: './samplebook-list.component.html',
  styleUrls: ['./samplebook-list.component.css']
})

export class SamplebookListComponent implements OnInit {
 @ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;
   constructor(public formsService: FormsService, private apiController: ApicontrollerService, public utiltiesService: UtiltiesService,
    private router: Router

   ) { }
   selectedRowId: any;
   searchFields: any =  this.formsService.sampleBookTableData.searchFields;
   tableData: any = [];
   tableDataHeader: any = this.formsService.sampleBookTableData.tableDataHeader;
   tableDataRows: any = this.formsService.sampleBookTableData.tableDataRows;
 
   tableTitle: any =  this.formsService.sampleBookTableData.title;
   savedForm: any = {};
   isFormValid: boolean = false;
   totalRecords: any=100;
   limit: any = 100;
   noofpage: any = 1;
 
    @ViewChild('student_name') studentNameRef!: ElementRef;
 
   ngOnInit() {
     this.fetchCount();
     this.fetchSampleBook();

     
   }
 
  
 
 
   async addSampleBook() {
 
   setTimeout(() => {
            this.router.navigate(['/addSamplebook']);
          }, 500);
 
   }
 
   onFormValidityChange(isValid: boolean) {
     this.isFormValid = isValid;
   }
   resetForm() {
     this.savedForm = {};
     this.selectedRowId = null;
   }
 
   async fetchSampleBook(page = 1, limit = 50) {
     var tempClientDAta = await this.apiController.fetchSampleBook(page, limit);
    //  console.log("tempClientDAta",tempClientDAta)
     if (tempClientDAta != false) {
       this.tableData = [];
       for (var i = 0; i < tempClientDAta.length; i++) {
         this.tableData.push(
           {
             "row_id": tempClientDAta[i].row_id,
             "title": tempClientDAta[i].title,
             "cr_on": new Date(tempClientDAta[i].cr_on).toDateString(), 
           }
         );
       }
      // console.log("this.tableData========");
      // console.log(this.tableData);
     }
   }
 
  
   editClient(cl: any) {
    console.log(cl);
     this.savedForm=cl.data;
     
     this.selectedRowId = cl.rowId;
    

   }
   deleteClient(cl: any) {
    // console.log(cl);
   }
 
   fetchNextData(row: any) {
    // console.log("fetchNextData");
     const page = row.page;
     const limit = row.limit;
    // console.log(page, limit);
     this.fetchSampleBook(page, limit);
   }
   async fetchCount() {
     var totRec = await this.apiController.fetchCount('samplebook');
  // console.log(totRec);
     if (totRec != false) {
       this.totalRecords = totRec;
       this.noofpage = Math.ceil(this.totalRecords / this.limit);
      // console.log(this.totalRecords);
     }
     // this.fetchStudents();
   }

  
}