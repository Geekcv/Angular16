import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SamplePaperlistComponent } from './sample-paperlist.component';

describe('SamplePaperlistComponent', () => {
  let component: SamplePaperlistComponent;
  let fixture: ComponentFixture<SamplePaperlistComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SamplePaperlistComponent]
    });
    fixture = TestBed.createComponent(SamplePaperlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
