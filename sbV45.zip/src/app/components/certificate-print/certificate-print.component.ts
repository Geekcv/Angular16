import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http'; // Import HttpClient
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { UtiltiesService } from 'src/app/services/utilties.service';
import * as pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';

(pdfMake as any).vfs = pdfFonts.vfs;

(pdfMake as any).fonts = {
  Roboto: {
    normal: 'Roboto-Regular.ttf',
    bold: 'Roboto-Medium.ttf',
    italics: 'Roboto-Italic.ttf',
    bolditalics: 'Roboto-MediumItalic.ttf',
  },
};

@Component({
  selector: 'app-certificate-print',
  templateUrl: './certificate-print.component.html',
  styleUrls: ['./certificate-print.component.css'],
})
export class CertificatePrintComponent implements OnInit {
  // Your existing variables
  examSessions: any[] = [];
  centers: any[] = [];
  classes: any[] = [];
  temCenter: any = [];
  faculty: any[] = [];
  temfaculty: any = [];
  temExam: any = [];
  temclass: any = [];

  selectedExamSession: any = null;
  selectedCenter: any = null;
  selectedFaculty: any = null;
  selectedClass: any = null;

  centerWiseResults: any[] = [];
  submitted: boolean = false;
  rollNo: any;

  base64Image: string | null = null; // To store base64 image string

  constructor(
    private apiController: ApicontrollerService,
    private utiltiesService: UtiltiesService,
    public jsonlist: JsonListService,
    private http: HttpClient // Inject HttpClient
  ) {}

  ngOnInit(): void {
    this.loadInitialData();
    this.fetchClasses();
    this.loadImageAsBase64(); // Load image on component init
  }

  loadImageAsBase64() {
    this.http
      .get('assets/pdfformate.png', { responseType: 'blob' })
      .subscribe((blob) => {
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = () => {
          this.base64Image = reader.result as string;
        };
      });
  }

  async loadInitialData() {
    this.examSessions = [];
    this.centers = [];
    this.faculty = [];

    this.fetchExams();
    this.fetchExamCenter();
    this.fetchfaculty();
  }

  async fetchClasses(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchClassesByFaculty(
      this.selectedFaculty,
      page,
      limit
    );
    console.log('tem---', tempClientDAta);
    if (tempClientDAta != false) {
      this.temclass = [];
      // console.log("classes========",tempClientDAta);
      this.temclass = tempClientDAta.map((item: any) => ({
        title: `${item.class_name}`,
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchExams(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchExameByFaculty(
      this.selectedFaculty,
      page,
      limit
    );
    console.log('temExam---', tempClientDAta);

    if (tempClientDAta != false) {
      // console.log("exams========",tempClientDAta);
      this.temExam = [];
      this.temExam = tempClientDAta.map((item: any) => ({
        title: `${item.session_name}`,
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchExamCenter(page = 1, limit = 500) {
    const tempClientData = await this.apiController.fetchExamCenter(
      page,
      limit
    );
    console.log('data', tempClientData);
    if (tempClientData !== false) {
      this.temCenter = [];
      this.temCenter = tempClientData.map((item: any) => ({
        title: `${item.center} - ${item.center_code}`,
        code: item.center_code?.toString(),
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchfaculty(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchfaculty(page, limit);
    console.log('datafaculty', tempClientDAta);
    if (tempClientDAta != false) {
      this.temfaculty = [];
      // console.log("exams========",tempClientDAta);
      this.temfaculty = tempClientDAta.map((item: any) => ({
        title: `${item.faculty_name}`,
        value: item.row_id,
        data: item,
      }));
    }
    this.fetchExams();
  }
  async fetchCenterWiseResults() {
    const studentData = await this.apiController.fetchCertificateData(
      this.selectedExamSession,
      this.selectedClass,
      this.selectedFaculty,this.selectedCenter,this.rollNo
    );

    if (Array.isArray(studentData)) {
      for (let student of studentData) {
        this.generateCertificatePDF(student);
      }
    } else {
      this.generateCertificatePDF(studentData);
    }
  }

  generateCertificatePDF(data: any) {
    if (!this.base64Image) {
      alert('Background image is still loading. Please try again in a moment.');
      return;
    }

    const docDefinition: any = {
      pageSize: 'A4',
      pageMargins: [0, 0, 0, 0] as [number, number, number, number],
      background: [
        {
          image: this.base64Image,
          width: 595,
          height: 842,
        },
      ],
      content: [
        {
          absolutePosition: { x: 140, y: 370 },
          text: data.center_code?.toString(),
          fontSize: 12,
          bold: true,
        },
        {
          absolutePosition: { x: 500, y: 370 },
          text: data.roll_no?.toString(),
          fontSize: 12,
          bold: true,
        },
        {
          absolutePosition: { x: 130, y: 430 },
          text: data.students,
          fontSize: 14,
          bold: true,
          color: 'red',
        },
        {
          absolutePosition: { x: 370, y: 430 },
          text: data.fatherName,
          fontSize: 14,
          bold: true,
          color: 'red',
        },
        {
          absolutePosition: { x: 80, y: 495 },
          text: `(${data.centerCity}) ${data.center_name}`,
          fontSize: 13,
        },
        {
          absolutePosition: { x: 270, y: 495 },
          text: data.examDate,
          fontSize: 13,
        },
        {
          absolutePosition: { x: 400, y: 495 },
          text: data.subject,
          fontSize: 10,
        },
        {
          absolutePosition: { x: 150, y: 550 },
          text: data.marks?.toString(),
          fontSize: 13,
          color: 'red',
        },
      ],
    };

    pdfMake.createPdf(docDefinition).open();
  }

  // --- Helper methods for display ---
  getSessionName(id: any): string | null {
    const item = this.examSessions.find((e) => e.id === id);
    return item ? item.name : null;
  }

  getFaculty(id: any): string | null {
    const item = this.jsonlist.faculty.find((c) => c.value === id);
    return item ? item.title : null;
  }
  getCenterName(id: any): string | null {
    const item = this.centers.find((c) => c.id === id);
    return item ? item.name : null;
  }

  getCenterCode(id: any): string | null {
    const item = this.centers.find((c) => c.id === id);
    return item ? item.data?.center_code : null;
  }

  getClassName(id: any): string | null {
    const item = this.classes.find((c) => c.row_id === id);
    return item ? item.class_name : null;
  }
  // --- End Helper methods ---

  printReport() {
    this.utiltiesService.printReport('report', 'MeritListCenterWiseReport');
  }

  searchValues_Exam: { [key: string]: string } = {};
  showDropdown_Exam: { [key: string]: boolean } = {};
  filteredOptions_Exam: { [key: string]: any[] } = {};
  focusedIndex_Exam: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_Exam(id: string) {
    const query = this.searchValues_Exam[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_Exam[id] = [...this.temExam];
    } else {
      this.filteredOptions_Exam[id] = this.temExam.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_Exam[id] = 0;
  }

  selectOption_Exam(id: string, option: any) {
    this.searchValues_Exam[id] = option.title;
    this.selectedExamSession = option.value;
    this.showDropdown_Exam[id] = false;
    this.fetchClasses();
  }

  hideDropdownWithDelay_Exam(id: string) {
    setTimeout(() => {
      this.showDropdown_Exam[id] = false;
    }, 200);
  }

  handleKeydown_Exam(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_Exam[id] || [];
    let index = this.focusedIndex_Exam[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    }
  }

  searchValues_class: { [key: string]: string } = {};
  showDropdown_class: { [key: string]: boolean } = {};
  filteredOptions_class: { [key: string]: any[] } = {};
  focusedIndex_class: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_class(id: string) {
    const query = this.searchValues_Exam[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_class[id] = [...this.temclass];
    } else {
      this.filteredOptions_class[id] = this.temclass.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_class[id] = 0;
  }

  selectOption_class(id: string, option: any) {
    this.searchValues_class[id] = option.title;
    this.selectedClass = option.value;
    this.showDropdown_class[id] = false;
    this.fetchClasses();
  }

  hideDropdownWithDelay_class(id: string) {
    setTimeout(() => {
      this.showDropdown_class[id] = false;
    }, 200);
  }

  handleKeydown_class(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_class[id] || [];
    let index = this.focusedIndex_class[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_class[id] = index;

      // Select option immediately
      this.selectOption_class(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_class[id] = index;

      // Select option immediately
      this.selectOption_class(id, options[index]);

      event.preventDefault();
    }
  }

  searchValues_faculty: { [key: string]: string } = {};
  showDropdown_faculty: { [key: string]: boolean } = {};
  filteredOptions_faculty: { [key: string]: any[] } = {};
  focusedIndex_faculty: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_faculty(id: string) {
    const query = this.searchValues_faculty[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_faculty[id] = [...this.temfaculty];
    } else {
      this.filteredOptions_faculty[id] = this.temfaculty.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_faculty[id] = 0;
  }

  selectOption_faculty(id: string, option: any) {
    this.searchValues_faculty[id] = option.title;
    this.selectedFaculty = option.value;
    this.showDropdown_faculty[id] = false;
    this.fetchExams();
  }

  hideDropdownWithDelay_faculty(id: string) {
    setTimeout(() => {
      this.showDropdown_faculty[id] = false;
    }, 200);
  }

  handleKeydown_faculty(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_faculty[id] || [];
    let index = this.focusedIndex_faculty[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_faculty[id] = index;

      // Select option immediately
      this.selectOption_faculty(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_faculty[id] = index;

      // Select option immediately
      this.selectOption_faculty(id, options[index]);

      event.preventDefault();
    }
  }

  searchValues: { [key: string]: string } = {};
  showDropdown: { [key: string]: boolean } = {};
  filteredOptions: { [key: string]: any[] } = {};
  focusedIndex: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions(id: string) {
    const query = this.searchValues[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions[id] = [...this.temCenter];
    } else {
      this.filteredOptions[id] = this.temCenter.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex[id] = 0;
  }

  selectOption(id: string, option: any) {
    this.searchValues[id] = option.title;
    this.selectedCenter = option.value;
    this.showDropdown[id] = false;
  }

  hideDropdownWithDelay(id: string) {
    setTimeout(() => {
      this.showDropdown[id] = false;
    }, 200);
  }

  handleKeydown(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions[id] || [];
    let index = this.focusedIndex[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex[id] = index;

      // Select option immediately
      this.selectOption(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex[id] = index;

      // Select option immediately
      this.selectOption(id, options[index]);

      event.preventDefault();
    }
  }
}
