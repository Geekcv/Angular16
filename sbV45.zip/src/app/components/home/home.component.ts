import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { MenuItem } from 'primeng/api';
import { AuthService } from 'src/app/services/auth.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent {
  items: MenuItem[] | undefined;
  routes: MenuItem[] | undefined;
  activeItem: any;
  userRole: any;
  desktopSidebarVisible = true; // controls desktop sidebar visibility
  mobileSidebarVisible = false; // controls mobile sidebar visibility

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit() {
    this.routes = [
      {
        label: 'Dashboard',
        icon: 'pi pi-chart-pie',
        id: 'dashboard',
        routerLink: '/dashboard',
      },

      {
        label: 'Student',
        icon: 'pi pi-fw pi-users',
        id: 'users',
        items: [
          {
            label: 'Create Student',
            routerLink: '/students',
            icon: 'pi pi-fw pi-user-edit',
            id: 'create-student',
          },

          {
            label: 'list of Student',
            routerLink: '/list-students',
            icon: 'pi pi-fw pi-file-edit',
            id: 'list-students',
          },
          {
            label: 'Student Attendance',
            routerLink: '/attendance',
            icon: 'pi pi-fw pi-check-circle',
            id: 'attendance',
          },
          {
            label: 'Bandal  Issue',
            routerLink: '/bundle',
            icon: 'pi pi-fw pi-box',
            id: 'bundle',
          },

          {
            label: 'Bandal  Sheet',
            routerLink: '/bandalSheet',
            icon: 'pi pi-fw pi-box',
            id: 'bundlesheet',
          },
          {
            label: 'Copy Makrs',
            routerLink: '/marks',

            icon: 'pi pi-fw pi-percentage',
            id: 'marks',
          },
        ],
      },

      {
        label: 'Reports',
        icon: 'pi pi-fw pi-file',
        id: 'marks',
        items: [
          {
            label: 'Student Report',
            routerLink: '/center-wise-students',

            icon: 'pi pi-fw pi-file',
            id: 'studentreports',
          },
          {
            label: 'State City Wise Student Report',
            routerLink: '/city-wise-students',

            icon: 'pi pi-fw pi-file',
            id: 'city-wise-students',
          },
          {
            label: 'Center Wise Total Student',
            routerLink: '/center-wise-total-students',

            icon: 'pi pi-fw pi-file',
            id: 'center-wise-total-students',
          },
          {
            label: 'Admission Card',
            routerLink: '/admission-card',

            icon: 'pi pi-fw pi-id-card',
            id: "admission-card'",
          },
          {
            label: 'Marks Report',
            routerLink: '/student-marks',

            icon: 'pi pi-fw pi-percentage',
            id: 'student-marks',
          },
          {
            label: 'Marks Filter Report',
            routerLink: '/student-marks-filter',

            icon: 'pi pi-fw pi-percentage',
            id: 'student-marks-filter',
          },
          {
            label: 'Press Note Result',
            routerLink: '/pressnoteresultreport',
            icon: 'pi pi-compass',
            id: 'press-note-result-report',
          },
          {
            label: 'Merit List ',
            routerLink: '/merit-list',

            icon: 'pi pi-fw pi-graduation-cap',
            id: 'merit-list',
          },
          {
            label: 'Center Wise Report',
            routerLink: '/merit-list-center-wise',

            icon: 'pi pi-fw pi-graduation-cap',
            id: 'merit-list-center-wise',
          },
          {
            label: 'Center Wise Amount Report',
            routerLink: '/center-wise-amount',

            icon: 'pi pi-fw pi-percentage',
            id: 'center-wise-amount',
          },
          {
            label: 'Reject Exam Report',
            routerLink: '/reject-exam',

            icon: 'pi pi-fw pi-ban',
            id: 'reject-exam',
          },

          // {
          //   label: 'Medium Wise Report',
          //   routerLink: '/medium-wise-report',

          //   "icon": "pi pi-fw pi-percentage",
          //   "id": "medium-wise-report"
          // }

          {
            label: 'Student Last Exam Status',
            routerLink: '/studentlastexamstatus',
            icon: 'pi pi-compass',
            id: 'studentlastexamstatus',
          },
          {
            label: 'Certificate Print',
            routerLink: '/certificate',
            icon: 'pi pi-compass',
            id: 'certificate',
          },
        ],
      },
      {
        label: 'Branch',
        icon: 'pi pi-fw pi-warehouse',
        id: 'branch',
        items: [
          {
            label: 'Branch',
            routerLink: '/branch',

            icon: 'pi pi-fw pi-warehouse',
            id: 'branch',
          },
        ],
      },
      {
        label: 'Center',
        icon: 'pi pi-fw pi-calendar-times',
        id: 'exams',
        items: [
          {
            label: 'Exam Center',
            routerLink: '/exam-center',
            icon: 'pi pi-fw pi-shop',
            id: 'exam-center',
          },
        ],
      },
      {
        label: 'Classes',
        icon: 'pi pi-align-center',
        id: 'classes',
        items: [
          {
            label: 'Class',
            routerLink: '/class',

            icon: 'pi pi-fw pi-calendar-plus',
            id: 'classes',
          },
        ],
      },

      {
        label: 'Exam Session',
        icon: 'pi pi-fw pi-calendar-plus',
        id: 'marks',
        items: [
          {
            label: 'Exam',
            routerLink: '/exam',

            icon: 'pi pi-fw pi-calendar-plus',
            id: 'programs',
          },
        ],
      },
      {
        label: 'Sheet Checker',
        icon: 'pi pi-compass',
        id: 'marks',
        items: [
          {
            label: 'Sheet Checker',
            routerLink: '/checker',

            icon: 'pi pi-fw pi-check-square',
            id: 'checker',
          },
        ],
      },
      {
        label: 'Faculty',
        icon: 'pi pi-users',
        id: 'faculty',
        items: [
          {
            label: 'Add Faculty',
            routerLink: '/faculty',

            icon: 'pi pi-plus-circle',
            id: 'faculty',
          },
        ],
      },
      {
        label: 'Sample Book',
        icon: 'pi pi-book',
        id: 'samplebook',
        items: [
          {
            label: 'list',
            routerLink: '/listSamplebook',
            icon: 'pi pi-fw pi-check-square',
            id: 'listsamplebook',
          },
          {
            label: 'Add',
            routerLink: '/addSamplebook',
            icon: 'pi pi-cloud-upload',
            id: 'addsamplebook',
          },
        ],
      },
      {
        label: 'Sample Paper',
        icon: 'pi pi-paperclip',
        id: 'samplepaper',
        items: [
          {
            label: 'list',
            routerLink: '/listSamplePaper',
            icon: 'pi pi-fw pi-check-square',
            id: 'listsamplePaper',
          },
          {
            label: 'Add',
            routerLink: '/addSamplePaper',
            icon: 'pi pi-cloud-upload',
            id: 'addsamplePaper',
          },
        ],
      },
    ];
    this.items = this.routes;
    // this.items = this.getRoutes();

    // console.log(this.items);
  }

  // getRoutes() {

  //   const allowedPanels = this.authService.getUserAllowedPanels();

  //   return this.routes?.filter(route => allowedPanels.includes(route.id));
  // }
  logout() {
    this.authService.logoutUser();
  }
}
