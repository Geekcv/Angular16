import { Component, OnInit } from '@angular/core';
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service'; // Adjust path
import { UtiltiesService } from 'src/app/services/utilties.service'; // Adjust path

@Component({
  selector: 'app-merit-list',
  templateUrl: './merit-list.component.html',
  styleUrls: ['./merit-list.component.css']
})
export class MeritListComponent implements OnInit {

  // Dropdown options
  examSessions: any[] = [];
  classes: any[] = [];

  // Selected filter values
  selectedFaculty: any = null;
  selectedExamSession: any = null;
  selectedClass: any = null;

  // Data for the report table
  meritListData: any[] = []; // e.g., [{ studentName: '...', fatherHusbandName: '...', ..., position: 1 }, ...]
  submitted: boolean = false; // To track if submit was clicked
    faculty:any[]=[];

    
  temCenter: any = [];
  temfaculty: any = [];
  temExam: any = [];
  temclass: any = []


  constructor(
    private apiController: ApicontrollerService,
    private utiltiesService: UtiltiesService, // For export
    public jsonlist: JsonListService // For dropdown data
  ) { }

  ngOnInit(): void {
    this.loadInitialData();
    this.fetchClasses(); // Fetch initial classes based on default faculty
  }

  async loadInitialData() {
    // Fetch exam sessions
    this.examSessions = []; // Adapt API call
    // Map data if needed to {name: '...', id: '...'} format for dropdowns
    this.faculty = []

    this.fetchExams();
    this.fetchfaculty();

  }

  async fetchClasses(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchClassesByFaculty(
      this.selectedFaculty,
      page,
      limit
    );
    console.log('tem---', tempClientDAta);
    if (tempClientDAta != false) {
      this.temclass = [];
      // console.log("classes========",tempClientDAta);
      this.temclass = tempClientDAta.map((item: any) => ({
        title: `${item.class_name}`,
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchExams(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchExameByFaculty(
      this.selectedFaculty,
      page,
      limit
    );
    console.log('temExam---', tempClientDAta);

    if (tempClientDAta != false) {
      // console.log("exams========",tempClientDAta);
      this.temExam = [];
      this.temExam = tempClientDAta.map((item: any) => ({
        title: `${item.session_name}`,
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchExamCenter(page = 1, limit = 500) {
    const tempClientData = await this.apiController.fetchExamCenter(
      page,
      limit
    );
    console.log('data', tempClientData);
    if (tempClientData !== false) {
      this.temCenter = [];
      this.temCenter = tempClientData.map((item: any) => ({
        title: `${item.center} - ${item.center_code}`,
        code: item.center_code?.toString(),
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchfaculty(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchfaculty(page, limit);
    console.log('datafaculty', tempClientDAta);
    if (tempClientDAta != false) {
      this.temfaculty = [];
      // console.log("exams========",tempClientDAta);
      this.temfaculty = tempClientDAta.map((item: any) => ({
        title: `${item.faculty_name}`,
        value: item.row_id,
        data: item,
      }));
    }
    this.fetchExams();
  }


  async fetchMeritList() {
    this.submitted = true;
    this.meritListData = []; // Clear previous results
    if (!this.selectedFaculty || !this.selectedExamSession || !this.selectedClass) {
      console.error("Please select Faculty, Exam Session, and Class.");
      return;
    }
    console.log('Fetching merit list for:', this.selectedFaculty, this.selectedExamSession, this.selectedClass);

    // Call API to fetch merit list based on filters
    const fetchedData = await this.apiController.fetchMeritListReport(
        this.selectedFaculty,
        this.selectedExamSession,
        this.selectedClass
    ) || []; // Create this API call

    // Assuming API returns data sorted by position/marks
    // Map fetchedData to the structure needed by the table
    this.meritListData = fetchedData.map((item: any) => ({
        studentName: item.student_name,
        fatherHusbandName: item.father_name,
        address: item.address,
        centerCode: item.center_code,
        centerName: item.center,
        className: item.class_name,
        rollNo: item.roll_no,
        marks: item.marks,
        position: item.position, // Assuming API provides position
        id: item.row_id // Or another unique identifier
    }));
    console.log('Fetched merit list:', this.meritListData);
  }


  // --- Helper methods for display ---
  getFacultyName(id: any): string | null {
    const item = this.jsonlist.faculty.find(e => e.value === id);
    return item ? item.title : null;
  }
  getSessionName(id: any): string | null {
    const item = this.examSessions.find(e => e.id === id);
    return item ? item.name : null;
  }

  getClassName(id: any): string | null {
    const item = this.classes.find(c => c.row_id === id);
    return item ? item.class_name : null;
  }
  // --- End Helper methods ---

  exportData() {
    if (this.meritListData && this.meritListData.length > 0) {
      console.log("Exporting data...", this.meritListData);
      this.meritListData.forEach((item: any) => {
        delete item.id;
      });
      this.utiltiesService.exportAsExcelFile(this.meritListData, 'MeritListReport');
    } else {
      console.warn("No data to export.");
    }
  }

  printReport() {
    this.utiltiesService.printReport('report', 'MeritListReport'); // Adjust the ID of the report section
  }


  searchValues_faculty: { [key: string]: string } = {};
  showDropdown_faculty: { [key: string]: boolean } = {};
  filteredOptions_faculty: { [key: string]: any[] } = {};
  focusedIndex_faculty: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_faculty(id: string) {
    const query = this.searchValues_faculty[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_faculty[id] = [...this.temfaculty];
    } else {
      this.filteredOptions_faculty[id] = this.temfaculty.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_faculty[id] = 0;
  }

  selectOption_faculty(id: string, option: any) {
    this.searchValues_faculty[id] = option.title;
    this.selectedFaculty = option.value;
    this.showDropdown_faculty[id] = false;
    this.fetchExams();
  }

  hideDropdownWithDelay_faculty(id: string) {
    setTimeout(() => {
      this.showDropdown_faculty[id] = false;
    }, 200);
  }

  handleKeydown_faculty(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_faculty[id] || [];
    let index = this.focusedIndex_faculty[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_faculty[id] = index;

      // Select option immediately
      this.selectOption_faculty(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_faculty[id] = index;

      // Select option immediately
      this.selectOption_faculty(id, options[index]);

      event.preventDefault();
    }
  }

  searchValues_Exam: { [key: string]: string } = {};
  showDropdown_Exam: { [key: string]: boolean } = {};
  filteredOptions_Exam: { [key: string]: any[] } = {};
  focusedIndex_Exam: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_Exam(id: string) {
    const query = this.searchValues_Exam[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_Exam[id] = [...this.temExam];
    } else {
      this.filteredOptions_Exam[id] = this.temExam.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_Exam[id] = 0;
  }

  selectOption_Exam(id: string, option: any) {
    this.searchValues_Exam[id] = option.title;
    this.selectedExamSession = option.value;
    this.showDropdown_Exam[id] = false;
    this.fetchClasses();
  }

  hideDropdownWithDelay_Exam(id: string) {
    setTimeout(() => {
      this.showDropdown_Exam[id] = false;
    }, 200);
  }

  handleKeydown_Exam(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_Exam[id] || [];
    let index = this.focusedIndex_Exam[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    }
  }

  searchValues_class: { [key: string]: string } = {};
  showDropdown_class: { [key: string]: boolean } = {};
  filteredOptions_class: { [key: string]: any[] } = {};
  focusedIndex_class: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_class(id: string) {
    const query = this.searchValues_Exam[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_class[id] = [...this.temclass];
    } else {
      this.filteredOptions_class[id] = this.temclass.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_class[id] = 0;
  }

  selectOption_class(id: string, option: any) {
    this.searchValues_class[id] = option.title;
    this.selectedClass = option.value;
    this.showDropdown_class[id] = false;
    this.fetchClasses();
  }

  hideDropdownWithDelay_class(id: string) {
    setTimeout(() => {
      this.showDropdown_class[id] = false;
    }, 200);
  }

  handleKeydown_class(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_class[id] || [];
    let index = this.focusedIndex_class[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_class[id] = index;

      // Select option immediately
      this.selectOption_class(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_class[id] = index;

      // Select option immediately
      this.selectOption_class(id, options[index]);

      event.preventDefault();
    }
  }
  
}
