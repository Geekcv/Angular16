import { Component } from '@angular/core';
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-student-marks-filter-report',
  templateUrl: './student-marks-filter-report.component.html',
  styleUrls: ['./student-marks-filter-report.component.css']
})
export class StudentMarksFilterReportComponent {

  // Dropdown options
  examSessions: any[] = [];
  classes: any[] = [];
  centers: any[] = [];
    faculty:any[]=[];

  

  // Selected filter values
    selectedFaculty: any = null;
  selectedExamSession: any = null;
  selectedClass: any = null; // Optional filter
  selectedCenter: any = null; // Optional filter
  marksFrom: number | null = null;
  marksTo: number | null = null;
  temCenter:any = []


  // Data for the report table
  filteredMarksData: any[] = [];
  submitted: boolean = false;
  temfaculty: any = [];
  temExam: any = [];
  temclass: any = [];

  constructor(
    private apiController: ApicontrollerService,
    private utiltiesService: UtiltiesService,
    public jsonlist: JsonListService // For dropdown data
  ) { }

  ngOnInit(): void {
    this.loadInitialData();
    this.fetchClasses(); // Fetch initial classes based on default faculty
  }

  async loadInitialData() {
    // Fetch exam sessions
    this.examSessions = [];
    // Fetch centers (assuming you want all centers initially)
    this.centers =  [];
    this.faculty = []
    this.classes = []
    this.fetchExams();
    this.fetchExamCenter();
    this.fetchfaculty();

  }

  async fetchClasses(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchClassesByFaculty(
      this.selectedFaculty,
      page,
      limit
    );
    console.log('tem---', tempClientDAta);
    if (tempClientDAta != false) {
      this.temclass = [];
      // console.log("classes========",tempClientDAta);
      this.temclass = tempClientDAta.map((item: any) => ({
        title: `${item.class_name}`,
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchExams(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchExameByFaculty(
      this.selectedFaculty,
      page,
      limit
    );
    console.log('temExam---', tempClientDAta);

    if (tempClientDAta != false) {
      // console.log("exams========",tempClientDAta);
      this.temExam = [];
      this.temExam = tempClientDAta.map((item: any) => ({
        title: `${item.session_name}`,
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchExamCenter(page = 1, limit = 500) {
    const tempClientData = await this.apiController.fetchExamCenter(
      page,
      limit
    );
    console.log('data', tempClientData);
    if (tempClientData !== false) {
      this.temCenter = [];
      this.temCenter = tempClientData.map((item: any) => ({
        title: `${item.center} - ${item.center_code}`,
        code: item.center_code?.toString(),
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchfaculty(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchfaculty(page, limit);
    console.log('datafaculty', tempClientDAta);
    if (tempClientDAta != false) {
      this.temfaculty = [];
      // console.log("exams========",tempClientDAta);
      this.temfaculty = tempClientDAta.map((item: any) => ({
        title: `${item.faculty_name}`,
        value: item.row_id,
        data: item,
      }));
    }
    this.fetchExams();
  }

  async fetchFilteredMarks() {
    this.submitted = true;
    this.filteredMarksData = []; // Clear previous results
    if (!this.selectedFaculty || !this.selectedExamSession) {
      console.error("Please select Faculty and Exam Session.");
      return;
    }

    // Validate marks range if both are entered
    if (this.marksFrom !== null && this.marksTo !== null && this.marksFrom > this.marksTo) {
        this.utiltiesService.openSnackBar("Marks 'From' value cannot be greater than 'To' value.");
        return;
    }


    console.log('Fetching filtered marks for:', this.selectedFaculty, this.selectedExamSession, this.selectedClass, this.selectedCenter, this.marksFrom, this.marksTo);

    // Call API to fetch filtered marks list
    const fetchedData = await this.apiController.fetchStudentMarks(
        this.selectedFaculty,
        this.selectedExamSession,
        this.selectedClass, // Pass null if not selected
        this.selectedCenter, // Pass null if not selected
        this.marksFrom, // Pass null if not entered
        this.marksTo // Pass null if not entered
    ) || []; // Create this API call

    // Map fetchedData to the structure needed by the table
    this.filteredMarksData = fetchedData.map((item: any) => ({
        rollNo: item.roll_no,
        bandalNo: item.bandal_no,
        centerCode: item.center_code,
        centerName: item.center_name,
        sheetChecker: item.sheet_checker_name, // Adjust field name based on API
        className: item.class_name,
        marks: item.marks,
        id: item.row_id // Or another unique identifier
    }));
    console.log('Fetched filtered marks:', this.filteredMarksData);
  }

  // --- Helper methods for display ---
  getSessionName(id: any): string | null {
    const item = this.examSessions.find(e => e.id === id);
    return item ? item.name : null;
  }

  getClassName(id: any): string | null {
    const item = this.classes.find(c => c.id === id);
    return item ? item.name : null;
  }

  getCenterName(id: any): string | null {
    const item = this.centers.find(c => c.id === id);
    return item ? item.name : null;
  }
  // --- End Helper methods ---

  exportData() {
    if (this.filteredMarksData && this.filteredMarksData.length > 0) {
      console.log("Exporting data...", this.filteredMarksData);
      this.filteredMarksData.forEach((item: any) => {
        delete item.id;

      });
      this.utiltiesService.exportAsExcelFile(this.filteredMarksData, 'FilteredMarksReport');
    } else {
      console.warn("No data to export.");
    }
  }

  printReport() {
    this.utiltiesService.printReport('report', 'StudentMarksFilterReport'); // Adjust the ID of the report section
  }

  getFacultyName(id: any): string | null {
    // const item = this.jsonlist.faculty.find(e => e.value === id);
    const item = this.faculty.find(e => e.value === id);
    return item ? item.title : null;
  }

  searchValues: { [key: string]: string } = {};
  showDropdown: { [key: string]: boolean } = {};
  filteredOptions: { [key: string]: any[] } = {};
  focusedIndex: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions(id: string) {
    const query = this.searchValues[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions[id] = [...this.temCenter];
    } else {
      this.filteredOptions[id] = this.temCenter.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex[id] = 0;
  }

  selectOption(id: string, option: any) {
    this.searchValues[id] = option.title;
    this.selectedCenter = option.value;
    this.showDropdown[id] = false;
  }

  hideDropdownWithDelay(id: string) {
    setTimeout(() => {
      this.showDropdown[id] = false;
    }, 200);
  }

  handleKeydown(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions[id] || [];
    let index = this.focusedIndex[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex[id] = index;

      // Select option immediately
      this.selectOption(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex[id] = index;

      // Select option immediately
      this.selectOption(id, options[index]);

      event.preventDefault();
    }
  }

  searchValues_faculty: { [key: string]: string } = {};
  showDropdown_faculty: { [key: string]: boolean } = {};
  filteredOptions_faculty: { [key: string]: any[] } = {};
  focusedIndex_faculty: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_faculty(id: string) {
    const query = this.searchValues_faculty[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_faculty[id] = [...this.temfaculty];
    } else {
      this.filteredOptions_faculty[id] = this.temfaculty.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_faculty[id] = 0;
  }

  selectOption_faculty(id: string, option: any) {
    this.searchValues_faculty[id] = option.title;
    this.selectedFaculty = option.value;
    this.showDropdown_faculty[id] = false;
    this.fetchExams();
  }

  hideDropdownWithDelay_faculty(id: string) {
    setTimeout(() => {
      this.showDropdown_faculty[id] = false;
    }, 200);
  }

  handleKeydown_faculty(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_faculty[id] || [];
    let index = this.focusedIndex_faculty[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_faculty[id] = index;

      // Select option immediately
      this.selectOption_faculty(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_faculty[id] = index;

      // Select option immediately
      this.selectOption_faculty(id, options[index]);

      event.preventDefault();
    }
  }

  searchValues_Exam: { [key: string]: string } = {};
  showDropdown_Exam: { [key: string]: boolean } = {};
  filteredOptions_Exam: { [key: string]: any[] } = {};
  focusedIndex_Exam: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_Exam(id: string) {
    const query = this.searchValues_Exam[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_Exam[id] = [...this.temExam];
    } else {
      this.filteredOptions_Exam[id] = this.temExam.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_Exam[id] = 0;
  }

  selectOption_Exam(id: string, option: any) {
    this.searchValues_Exam[id] = option.title;
    this.selectedExamSession = option.value;
    this.showDropdown_Exam[id] = false;
    this.fetchClasses();
  }

  hideDropdownWithDelay_Exam(id: string) {
    setTimeout(() => {
      this.showDropdown_Exam[id] = false;
    }, 200);
  }

  handleKeydown_Exam(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_Exam[id] || [];
    let index = this.focusedIndex_Exam[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    }
  }

  searchValues_class: { [key: string]: string } = {};
  showDropdown_class: { [key: string]: boolean } = {};
  filteredOptions_class: { [key: string]: any[] } = {};
  focusedIndex_class: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_class(id: string) {
    const query = this.searchValues_Exam[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_class[id] = [...this.temclass];
    } else {
      this.filteredOptions_class[id] = this.temclass.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_class[id] = 0;
  }

  selectOption_class(id: string, option: any) {
    this.searchValues_class[id] = option.title;
    this.selectedClass = option.value;
    this.showDropdown_class[id] = false;
    this.fetchClasses();
  }

  hideDropdownWithDelay_class(id: string) {
    setTimeout(() => {
      this.showDropdown_class[id] = false;
    }, 200);
  }

  handleKeydown_class(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_class[id] || [];
    let index = this.focusedIndex_class[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_class[id] = index;

      // Select option immediately
      this.selectOption_class(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_class[id] = index;

      // Select option immediately
      this.selectOption_class(id, options[index]);

      event.preventDefault();
    }
  }

}
