import { Component, ViewChild } from '@angular/core';
import { FormsService } from 'src/app/constants/forms.service';
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from 'src/app/custom-components/form-builder/form-builder.component';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-city-wise-student',
  templateUrl: './city-wise-student.component.html',
  styleUrls: ['./city-wise-student.component.css'],
})
export class CityWiseStudentComponent {
  getSessionName(examId: any): string | null {
    const exam = this.exams.find((e) => e.id === examId);
    // console.log("exam============",exam)
    return exam ? exam.name : null;
  }
  getStateName(examId: any): string | null {
    const exam = this.jsonlist.state.find((e) => e.value === examId);
    // console.log("exam============",exam)
    return exam ? exam.title : null;
  }
  getCityName(examId: any): string | null {
    const exam = this.jsonlist.cities.find((e) => e.value === examId);
    // console.log("exam============",exam)
    return exam ? exam.title : null;
  }
  // --- End of Helper methods ---

  exportData() {
    // Implement your export logic here (e.g., using exceljs or similar)
    console.log('Exporting data...', this.students);
    this.students.forEach((item: any) => {
      delete item.id;
    });
    this.utiltiesService.exportAsExcelFile(
      this.students,
      'CityWiseStudentReport'
    );
  }
  temExam: any = [];

  selectedGender: any = 'All'; // Default to 'All'
  fromDate: Date | null = null; // Initialize date properties
  toDate: Date | null = null; // Initialize date properties
  printReport() {
    this.utiltiesService.printReport('report', 'CityWiseStudentReport');
  }

  @ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;
  constructor(
    public formsService: FormsService,
    private apiController: ApicontrollerService,
    public utiltiesService: UtiltiesService,
    public jsonlist: JsonListService
  ) {}
  selectedRowId: any;
  searchFields: any = this.formsService.studentTableData.searchFields;
  students: any = [];
  tableDataHeader: any = this.formsService.studentTableData.tableDataHeader;
  tableTitle: any = this.formsService.studentTableData.title;
  savedForm: any = {};
  isFormValid: boolean = false;
  totalRecords: any = 100;
  limit: any = 5;
  noofpage: any = 1;
  bundleNo: any;
  displayDialog: boolean = false;
  selectedStudent: any = null;
  exams: any[] = [];
  filteredCenters: any[] = [];
  selectedFaculty: any = null;
  selectedExam: any = null;
  selectedState: any = null;
  selectedCity: any = null;
  selectedStudents: any = [];

  state: any[] = this.jsonlist.states_rs;
  cities:any[] =this.jsonlist.cities_rs;

  ngOnInit() {
    this.loadInitialData();
  }

  loadInitialData() {
    this.exams = []; // Keep if needed elsewhere
    this.fetchExams();
  }

  onFormValidityChange(isValid: boolean) {
    this.isFormValid = isValid;
  }
  resetForm() {
    this.savedForm = {};
    this.selectedRowId = null;
  }

  // Method called when filters change or Submit button is clicked
  async onFilterChange() {
    this.students = []; // Clear previous student list
    // Fetch students based on the selected filters
    await this.fetchFilteredStudents();
  }

  async fetchExams(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fechExam(page, limit);

    console.log('temExam---', tempClientDAta);

    if (tempClientDAta != false) {
      // console.log("exams========",tempClientDAta);
      this.temExam = [];
      this.temExam = tempClientDAta.map((item: any) => ({
        title: `${item.session_name}`,
        value: item.row_id,
        data: item,
      }));
    }
  }

  // Fetch students based on selected filters
  async fetchFilteredStudents(page = 1, limit = 100) {
    var tempClientDAta = await this.apiController.fetchStudentByCityWise(
      this.selectedCity,
      this.selectedExam,
      this.selectedState,
      page,
      limit
    );
    if (tempClientDAta != false) {
      this.students = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        // Map API response fields to the fields expected by the table

        var age = this.utiltiesService.calculateAge(tempClientDAta[i].dob);
        this.students.push({
          rollNo: tempClientDAta[i].roll_no,
          studentName: tempClientDAta[i].student_name,
          fatherName: tempClientDAta[i].father_name,
          address: tempClientDAta[i].address,
          aadharNo: tempClientDAta[i].aadhar_no, // Adjust field names as per your API response
          phone: tempClientDAta[i].phone,
          age: age,
          class: tempClientDAta[i].class_name, // Assuming class name is needed
          accountNo: tempClientDAta[i].account_no,
          accountName: tempClientDAta[i].account_name,
          ifscCode: tempClientDAta[i].ifsc_code,
          // Keep original data if needed for other operations
          originalData: tempClientDAta[i],
          id: tempClientDAta[i].row_id, // Use a unique ID for potential row operations
        });
      }
      console.log('Fetched students:', this.students);
    } else {
      this.students = []; // Ensure students array is empty if fetch fails
      console.log('No students found or API error.');
    }
  }

  editClient(cl: any) {
    this.savedForm = cl.originalData;
    this.selectedRowId = cl.rowId;
  }
  deleteClient(cl: any) {
    // console.log(cl);
  }

  fetchNextData(row: any) {
    // Implement pagination for filtered results if needed
    // const page = row.page;
    // const limit = row.limit;
    // this.fetchFilteredStudents(page, limit);
  }
  async fetchCount() {
    // Adjust count logic if needed for filtered data
    // var totRec = await this.apiController.fetchCount('bandals'); // Or a specific count endpoint
    // if (totRec != false) {
    //   this.totalRecords = totRec;
    //   this.noofpage = Math.ceil(this.totalRecords / this.limit);
    // }
  }

  searchValues_Exam: { [key: string]: string } = {};
  showDropdown_Exam: { [key: string]: boolean } = {};
  filteredOptions_Exam: { [key: string]: any[] } = {};
  focusedIndex_Exam: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_Exam(id: string) {
    const query = this.searchValues_Exam[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_Exam[id] = [...this.temExam];
    } else {
      this.filteredOptions_Exam[id] = this.temExam.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_Exam[id] = 0;
  }

  selectOption_Exam(id: string, option: any) {
    this.searchValues_Exam[id] = option.title;
    this.selectedExam = option.value;
    this.showDropdown_Exam[id] = false;
  }

  hideDropdownWithDelay_Exam(id: string) {
    setTimeout(() => {
      this.showDropdown_Exam[id] = false;
    }, 200);
  }

  handleKeydown_Exam(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_Exam[id] || [];
    let index = this.focusedIndex_Exam[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    }
  }

  searchValues_State: { [key: string]: string } = {};
  showDropdown_State: { [key: string]: boolean } = {};
  filteredOptions_State: { [key: string]: any[] } = {};
  focusedIndex_State: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_State(id: string) {
    const query = this.searchValues_State[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_State[id] = [...this.state];
    } else {
      this.filteredOptions_State[id] = this.state.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_State[id] = 0;
  }

  selectOption_State(id: string, option: any) {
    this.searchValues_State[id] = option.title;
    this.selectedState = option;
    this.showDropdown_State[id] = false;
  
    // Reset city input
    this.searchValues_City[id] = '';
    this.filteredOptions_City[id] = [];
  
    // Load cities for selected state
    this.filterOptions_City(id);
  }
  

  hideDropdownWithDelay_State(id: string) {
    setTimeout(() => {
      this.showDropdown_State[id] = false;
    }, 200);
  }

  handleKeydown_State(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_State[id] || [];
    let index = this.focusedIndex_State[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_State[id] = index;

      // Select option immediately
      this.selectOption_State(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_State[id] = index;

      // Select option immediately
      this.selectOption_State(id, options[index]);

      event.preventDefault();
    }
  }

  searchValues_City: { [key: string]: string } = {};
  showDropdown_City: { [key: string]: boolean } = {};
  filteredOptions_City: { [key: string]: any[] } = {};
  focusedIndex_City: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_City(id: string) {
    const query = this.searchValues_City[id]?.toLowerCase() || '';
  
    if (!this.selectedState) {
      this.filteredOptions_City[id] = [];
      return;
    }
  
    const selectedStateId = this.selectedState.value;
  
    this.filteredOptions_City[id] = this.cities.filter(
      (city: { title: string; value: string; st: string }) =>
        city.st === selectedStateId &&
        city.title.toLowerCase().includes(query)
    );
  
    this.focusedIndex_City[id] = 0;
  }
  

  selectOption_City(id: string, option: any) {
    this.searchValues_City[id] = option.title;
    this.selectedCity = option.value;
    this.showDropdown_City[id] = false;
  }

  hideDropdownWithDelay_City(id: string) {
    setTimeout(() => {
      this.showDropdown_City[id] = false;
    }, 200);
  }

  handleKeydown_City(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_City[id] || [];
    let index = this.focusedIndex_City[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_City[id] = index;

      // Select option immediately
      this.selectOption_City(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_City[id] = index;

      // Select option immediately
      this.selectOption_City(id, options[index]);

      event.preventDefault();
    }
  }
}
