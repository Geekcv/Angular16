import { Component, OnInit } from '@angular/core';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service'; // Adjust path
import { UtiltiesService } from 'src/app/services/utilties.service'; // Adjust path

@Component({
  selector: 'app-bandal-sheet',
  templateUrl: './bandal-sheet.component.html',
  styleUrls: ['./bandal-sheet.component.css'],
})
export class BandalSheetComponent implements OnInit {
  // Dropdown options
  examSessions: any[] = [];

  // Selected filter values
  selectedExamSession: any = null;
  bandalNo: string = '';
  temExam: any = [];

  // Data
  marksData: any[] = []; // Raw data from API
  pairedMarksData: any[] = []; // Processed data for two-column display
  sheetCheckerName: string | null = null; // Name associated with Bandal No.
  submitted: boolean = false; // To track if submit was clicked

  constructor(
    private apiController: ApicontrollerService,
    private utiltiesService: UtiltiesService // For export
  ) {}

  ngOnInit(): void {
    this.loadInitialData();
  }

  async loadInitialData() {
    // Fetch exam sessions
    this.examSessions = []; // Adapt API call
    // Map data if needed to {name: '...', id: '...'} format for dropdowns
    this.fetchExams();
  }
  async fetchExams(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fechExam(page, limit);
    if (tempClientDAta != false) {
      // console.log("exams========",tempClientDAta);
      this.temExam = [];
      this.temExam = tempClientDAta.map((item: any) => ({
        title: `${item.session_name}`,
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchMarksReport() {
    this.submitted = true;
    this.marksData = [];
    this.pairedMarksData = [];
    this.sheetCheckerName = null;
    if (!this.selectedExamSession) {
      console.error('Please select Exam Session');
      return;
    }
    console.log('Fetching marks report for:', this.selectedExamSession);

    // Call API to fetch marks based on session and bandal number
    // This API might return the list of marks AND the sheet checker name
    const response = await this.apiController.fetchMarksByBandal(
      this.selectedExamSession,
      this.bandalNo
    ); // Create this API call

    console.log('res--->1', response);
    console.log('res--->2', response.marks);

    if (response && Array.isArray(response)) {
      this.marksData = response.map((item: any, index: number) => ({
        sno: index + 1, // Generate S.No based on index
        bandalNo: item.bandal_no, // Adjust field names based on API response
        class: item.class_name,
        rollNo: item.roll_no,
        marks: item.marks,
        id: item.row_id, // Or another unique identifier
      }));
      this.sheetCheckerName = response[0].sheet_checker_name || null; // Get checker name from response

      this.preparePairedData(); // Process data for two-column layout
      console.log('Fetched marks data:', this.marksData);
      console.log('Sheet Checker:', this.sheetCheckerName);
    } else {
      console.log('No marks data found or invalid response format.');
    }
  }

  preparePairedData() {
    this.pairedMarksData = [];
    const half = Math.ceil(this.marksData.length / 2);
    for (let i = 0; i < half; i++) {
      const leftItem = this.marksData[i];
      const rightItem = this.marksData[i + half]; // Get corresponding item from the second half
      this.pairedMarksData.push({ left: leftItem, right: rightItem || null }); // Add pair, handle case where right item doesn't exist
    }
    console.log('Paired data:', this.pairedMarksData);
  }

  // --- Helper method for display ---
  getSessionName(id: any): string | null {
    const item = this.examSessions.find((e) => e.id === id);
    return item ? item.name : null;
  }
  // --- End Helper method ---

  bandalSheetprint: any = false;

  printReport() {
    this.fetchMarksReport();
    this.bandalSheetprint = true;
    console.log('bandalSheet');
    this.utiltiesService.printReport('report', 'BandalSheetReport');
  }

  searchValues_Exam: { [key: string]: string } = {};
  showDropdown_Exam: { [key: string]: boolean } = {};
  filteredOptions_Exam: { [key: string]: any[] } = {};
  focusedIndex_Exam: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_Exam(id: string) {
    const query = this.searchValues_Exam[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_Exam[id] = [...this.temExam];
    } else {
      this.filteredOptions_Exam[id] = this.temExam.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_Exam[id] = 0;
  }

  selectOption_Exam(id: string, option: any) {

    console.log("select op",option.value)
    this.searchValues_Exam[id] = option.title;
    this.selectedExamSession = option.value;
    this.showDropdown_Exam[id] = false;
  }

  hideDropdownWithDelay_Exam(id: string) {
    setTimeout(() => {
      this.showDropdown_Exam[id] = false;
    }, 200);
  }

  handleKeydown_Exam(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_Exam[id] || [];
    let index = this.focusedIndex_Exam[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    }
  }
}
