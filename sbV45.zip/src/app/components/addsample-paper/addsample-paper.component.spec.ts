import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddsamplePaperComponent } from './addsample-paper.component';

describe('AddsamplePaperComponent', () => {
  let component: AddsamplePaperComponent;
  let fixture: ComponentFixture<AddsamplePaperComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddsamplePaperComponent]
    });
    fixture = TestBed.createComponent(AddsamplePaperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
