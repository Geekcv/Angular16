import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from 'src/app/custom-components/form-builder/form-builder.component';
import { ApiService } from 'src/app/services/api.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-addsample-paper',
  templateUrl: './addsample-paper.component.html',
  styleUrls: ['./addsample-paper.component.css']
})
export class AddsamplePaperComponent implements OnInit {
    @ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;
  
  savedForm: any = {};
  selectedRowId: any;

samplePaper: FormGroup ;
  loading: boolean = false;
  errorMessage: string = '';
  successMessage: string = '';
  config:any ;


  selectedClass: any = null;
  classes: any[] = [];
    faculty:any[]=[];
  selectedFaculty: any = null;
title:any;
samplepaperID:any;
  uploadedFilePath: string = ''; // To store the uploaded file's path

  constructor(
    private fb: FormBuilder,
    private apiController: ApicontrollerService,
    private http: HttpClient,  private route: ActivatedRoute,private router: Router,
    private configdata:ApiService
  ) {
    this.samplePaper = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required]
    });
    console.log("configdata---->",configdata.apiUrl)
    console.log("uploadedFilePath------",this.uploadedFilePath)
   this.config = configdata.apiUrl

  }

  async ngOnInit(){
      this.samplepaperID = this.route.snapshot.paramMap.get('id');

    if (this.samplepaperID) {
      await this.loadSamplePaperById(this.samplepaperID);
    }
    this.loadInitialData();

  }



   async loadSamplePaperById(id: string) {
    const studentData = await this.apiController.fetchSamplePaperById(id);
    console.log("stud---", studentData);  

    this.title = studentData.title
    this.selectedClass = studentData.class_id_name  
this.selectedRowId = studentData.row_id
this.uploadedFilePath = studentData.photo_path

    console.log("uploadedFilePath------",this.uploadedFilePath)

       
  }

   loadInitialData() {
    this.classes = [];
    this.faculty = []
    this.fetchfaculty();
    this.fetchClasses();

  }
  async onFilterChange() {
  
    console.log("selected class",this.selectedClass)
    
  }

    async fetchClasses(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fetchClasses(page, limit);
    // console.log("fetch class",tempClientDAta)
    if (tempClientDAta != false) {
      this.classes = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.classes.push({
          title: tempClientDAta[i].class_name,
          data: tempClientDAta[i],
          value: tempClientDAta[i].row_id
        });
      }
    }


    if (tempClientDAta===false) {
      this.classes = []; // Clear existing students      
    }
  }

      async fetchfaculty(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchfaculty(page, limit);
    if (tempClientDAta != false) {
    // console.log("exams========",tempClientDAta);
      this.faculty = []; // Clear existing students
      for (var i = 0; i < tempClientDAta.length; i++) {
        // Map fetched data to the structure expected by the table/dialog
        // Ensure 'name' and 'rollNo' properties exist for the template
        this.faculty.push(
          {
            title: tempClientDAta[i].faculty_name, 
            data: tempClientDAta[i], // Keep original data if needed
            value: tempClientDAta[i].row_id
          }
        );
      }
    }
  }



  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const file = input.files[0];
      const formData = new FormData();
      formData.append('file', file);
  
      this.http.post(this.config + '/uploads', formData).subscribe({
        next: (response: any) => {
          // console.log('Upload successful:', response);
          // Extract the file path from the response
          if (response?.rsp?.data?.filesInfo?.[0]?.foPa) {
            this.uploadedFilePath = response.rsp.data.filesInfo[0].foPa;
            console.log('Uploaded File Path:', this.uploadedFilePath);
          } else {
            console.error('Unexpected response format:', response);
            this.errorMessage = 'File upload failed. Invalid server response.';
          }
        },
        error: (error) => {
          console.error('Upload failed:', error);
          this.errorMessage = 'File upload failed. Please try again.';
        },
      });
    }
  }

  async onSubmit() {     
       
       

        const resp = await this.apiController.createSamplePaper(this.selectedClass,this.title,this.uploadedFilePath,this.selectedRowId);
        console.log("res summbit",resp)      
   
    
  }

  async  discard(){
    setTimeout(() => {
            this.router.navigate(['/listSamplePaper']);
          }, 500)
  }
}
