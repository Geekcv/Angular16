import { Component, OnInit } from '@angular/core';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service'; // Adjust path
import { UtiltiesService } from 'src/app/services/utilties.service'; // Adjust path

@Component({
  selector: 'app-center-wise-student-total',
  templateUrl: './center-wise-student-total.component.html',
  styleUrls: ['./center-wise-student-total.component.css']
})
export class CenterWiseStudentTotalComponent implements OnInit {

  // Dropdown options
  examSessions: any[] = [];
  transposedData: any[] = [];
  centers: any[] = [];
  orderByOptions: any[] = [
      { label: 'Class+Roll No', value: 'roll_no' },
      { label: 'Class+Name', value: 'name' }
  ];

  // Selected filter values
  selectedExamSession: any = null;
  selectedCenter: any = null;
  selectedGender: string = 'All'; // Default value
  selectedOrderBy: string = 'roll_no'; // Default value

  // Data for the report table
  reportData: any[] = []; 
  students:any=[];// e.g., [{ className: 'Class 10', maleCount: 15, femaleCount: 10, totalCount: 25 }, ...]
  grandTotalMale: number = 0;
  grandTotalFemale: number = 0;
  grandTotal: number = 0;
  temCenter:any = []
  temExam:any=[]

  constructor(
    private apiController: ApicontrollerService,
    private utiltiesService: UtiltiesService // For export
  ) { }

  ngOnInit(): void {
    this.loadInitialData();
  }

  async loadInitialData() {
    // Fetch exam sessions
    this.examSessions =  []; // Adapt API call
    // Fetch centers
    this.centers = []; // Adapt API call
    // Map data if needed to {name: '...', id: '...'} format for dropdowns
    this.fetchExams();
    this.fetchExamCenter();
  }

  async fetchExams(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fechExam(page, limit);

    console.log('temExam---', tempClientDAta);

    if (tempClientDAta != false) {
      // console.log("exams========",tempClientDAta);
      this.temExam = [];
      this.temExam = tempClientDAta.map((item: any) => ({
        title: `${item.session_name}`,
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchExamCenter(page = 1, limit = 500) {
    const tempClientData = await this.apiController.fetchExamCenter(
      page,
      limit
    );
    console.log('data', tempClientData);
    if (tempClientData !== false) {
      this.temCenter = [];
      this.temCenter = tempClientData.map((item: any) => ({
        title: `${item.center} - ${item.center_code}`,
        code: item.center_code?.toString(),
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchReportData() {
    if (!this.selectedExamSession ) {
      console.error("Please select Exam Session and Gender and OrderBy.");
      this.reportData = [];
      // this.calculateTotals(); // Reset totals
      return;
    }
    console.log('Fetching report data for:', this.selectedExamSession, this.selectedCenter, this.selectedGender, this.selectedOrderBy);

    // Call API to fetch aggregated student counts based on filters
    const fetchedData = await this.apiController.fetchCenterWiseStudentTotals(
        this.selectedExamSession,
        this.selectedCenter,
        this.selectedGender,
        this.selectedOrderBy
    ) || []; // Create this API call

    // Assuming API returns data like [{ class_name: 'Class 10', male_count: 15, female_count: 10, total_count: 25 }, ...]
    // this.reportData = fetchedData.map((item: any) => ({
    //     className: item.class_name,
    //     maleCount: item.male_count || 0,
    //     femaleCount: item.female_count || 0,
    //     totalCount: item.total_count || 0
//     // Add other fields if needed
// }));

this.reportData = []; this.students = []; // Clear existing students before adding new ones
  
this.transposedData = [];
// Check if fetchedData is the expected object type and has the 'students' property
if (!Array.isArray(fetchedData) && 'students' in fetchedData) {
    const tempClientDAta = fetchedData.students; // Access students safely
     for(var i=0; i < tempClientDAta.length; i++){
    var  age = this.utiltiesService.calculateAge(new Date(tempClientDAta[i].dob));
      this.students.push(
        {
          rollNo: tempClientDAta[i].roll_no,
          studentName: tempClientDAta[i].student_name,
          fatherName: tempClientDAta[i].father_name,
          address: tempClientDAta[i].address,
          aadharNo: tempClientDAta[i].aadhar_no, // Adjust field names as per your API response
          phone: tempClientDAta[i].phone,
          age:age,
          class: tempClientDAta[i].class_name, // Assuming class name is needed
          accountNo: tempClientDAta[i].account_no,
          accountName: tempClientDAta[i].account_name,
          ifscCode: tempClientDAta[i].ifsc_code,

            }
          )
        }
        for(var i=0;i<fetchedData.classes.length;i++){
          this.reportData.push(
            {
              "Class":fetchedData.classes[i]['class_name'],
              "Total":fetchedData.classes[i]['total_students']
            }
          );
        }
        const keys = Object.keys(this.reportData[0]);
        this.transposedData = keys.map(key => {
          return {
            key,
            values: this.reportData.map(item => item[key])
          };
        });
    } else {
        // Handle the case where fetchedData is an array (e.g., the fallback []) or lacks 'students'
        this.students = []; // Ensure students array is empty
        console.warn("No student data found or data format incorrect.");
    }
    // this.calculateTotals(); // This seems to operate on reportData, not students
    console.log('Processed students:', this.students); // Log the processed students array
  }
  
  calculateTotals() {
      this.grandTotalMale = this.reportData.reduce((sum, row) => sum + (row.maleCount || 0), 0);
      this.grandTotalFemale = this.reportData.reduce((sum, row) => sum + (row.femaleCount || 0), 0);
      this.grandTotal = this.reportData.reduce((sum, row) => sum + (row.totalCount || 0), 0);
  }

  // --- Helper methods for display ---
  getSessionName(id: any): string | null {
    const item = this.examSessions.find(e => e.id === id);
    return item ? item.name : null;
  }

  getCenterName(id: any): string | null {
    const item = this.centers.find(c => c.id === id);
    return item ? item.name : null;
  }

  getCenterCode(id: any): string | null {
    const item = this.centers.find(c => c.id === id);
    // Adjust based on your center data structure
    return item ? item.data?.center_code : null;
  }

  getOrderByName(value: string): string | null {
      const item = this.orderByOptions.find(o => o.value === value);
      return item ? item.label : null;
  }
  // --- End Helper methods ---

  exportData() {
    if (this.reportData && this.reportData.length > 0) {
      console.log("Exporting data...", this.reportData);
     
      this.utiltiesService.exportTablesToExcel(this.students, this.transposedData, 'CenterWiseStudentTotalReport');
      // this.utiltiesService.exportAsExcelFile(dataToExport, 'CenterWiseStudentTotalReport');
    } else {
      console.warn("No data to export.");
    }
  }

  printReport() {
    this.utiltiesService.printReport('report', 'CenterWiseStudentTotalReport');
  }

  searchValues_Exam: { [key: string]: string } = {};
  showDropdown_Exam: { [key: string]: boolean } = {};
  filteredOptions_Exam: { [key: string]: any[] } = {};
  focusedIndex_Exam: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_Exam(id: string) {
    const query = this.searchValues_Exam[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_Exam[id] = [...this.temExam];
    } else {
      this.filteredOptions_Exam[id] = this.temExam.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_Exam[id] = 0;
  }

  selectOption_Exam(id: string, option: any) {
    this.searchValues_Exam[id] = option.title;
    this.selectedExamSession = option.value;
    this.showDropdown_Exam[id] = false;
  }

  hideDropdownWithDelay_Exam(id: string) {
    setTimeout(() => {
      this.showDropdown_Exam[id] = false;
    }, 200);
  }

  handleKeydown_Exam(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_Exam[id] || [];
    let index = this.focusedIndex_Exam[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    }
  }

  searchValues: { [key: string]: string } = {};
  showDropdown: { [key: string]: boolean } = {};
  filteredOptions: { [key: string]: any[] } = {};
  focusedIndex: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions(id: string) {
    const query = this.searchValues[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions[id] = [...this.temCenter];
    } else {
      this.filteredOptions[id] = this.temCenter.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex[id] = 0;
  }

  selectOption(id: string, option: any) {
    this.searchValues[id] = option.title;
    this.selectedCenter = option.value;
    this.showDropdown[id] = false;
  }

  hideDropdownWithDelay(id: string) {
    setTimeout(() => {
      this.showDropdown[id] = false;
    }, 200);
  }

  handleKeydown(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions[id] || [];
    let index = this.focusedIndex[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex[id] = index;

      // Select option immediately
      this.selectOption(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex[id] = index;

      // Select option immediately
      this.selectOption(id, options[index]);

      event.preventDefault();
    }
  }
  
}
