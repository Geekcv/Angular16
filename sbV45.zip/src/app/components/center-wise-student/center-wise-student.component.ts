import { Component, OnInit, ViewChild } from '@angular/core'; // Import OnInit
import { FormsService } from 'src/app/constants/forms.service';
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from 'src/app/custom-components/form-builder/form-builder.component';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-center-wise-student',
  templateUrl: './center-wise-student.component.html',
  styleUrls: ['./center-wise-student.component.css'],
})
// Implement OnInit
export class CenterWiseStudentComponent implements OnInit {
  // Implement OnInit

  temExam: any = [];

  // --- Helper methods to get names/codes ---
  getCenterCode(centerId: any): string | null {
    const center = this.centers.find((c) => c.id === centerId);
    // console.log(center)
    // Assuming the center object fetched has a 'code' property within its 'data'
    return center ? center.data?.center_code : null; // Adjust 'center.data.code' based on your actual center object structure
  }

  getCenterName(centerId: any): string | null {
    const center = this.centers.find((c) => c.id === centerId);
    return center ? center.name : null;
  }

  getSessionName(examId: any): string | null {
    const exam = this.exams.find((e) => e.id === examId);
    // console.log("exam============",exam)
    return exam ? exam.name : null;
  }
  // --- End of Helper methods ---

  exportData() {
    // Implement your export logic here (e.g., using exceljs or similar)
    console.log('Exporting data...', this.students);
    this.students.forEach((item: any) => {
      delete item.id;
      delete item.originalData;
    });
    this.utiltiesService.exportAsExcelFile(
      this.students,
      'CenterWiseStudentReport'
    );
  }

  selectedGender: any = 'All'; // Default to 'All'
  fromDate: Date | null = null; // Initialize date properties
  toDate: Date | null = null; // Initialize date properties

  printReport() {
    this.utiltiesService.printReport('report', 'CenterWiseStudentReport');
  }

  @ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;
  constructor(
    public formsService: FormsService,
    private apiController: ApicontrollerService,
    public utiltiesService: UtiltiesService,
    public jsonlist: JsonListService
  ) {}
  selectedRowId: any;
  searchFields: any = this.formsService.studentTableData.searchFields;
  students: any = [];
  tableDataHeader: any = this.formsService.studentTableData.tableDataHeader;
  tableTitle: any = this.formsService.studentTableData.title;
  savedForm: any = {};
  isFormValid: boolean = false;
  totalRecords: any = 100;
  limit: any = 5;
  noofpage: any = 1;
  bundleNo: any;
  displayDialog: boolean = false;
  selectedStudent: any = null;
  exams: any[] = [];
  classes: any[] = [];
  centers: any[] = [];
  checkers: any[] = [];
  filteredCenters: any[] = [];
  selectedFaculty: any = null;
  selectedExam: any = null;
  selectedClass: any = null;
  selectedCenter: any = null;
  selectedChecker: any = null;
  selectedStudents: any = [];

  temCenter: any = [];

  ngOnInit() {
    this.loadInitialData();
  }

  loadInitialData() {
    this.exams = [];
    this.classes = []; // Keep if needed elsewhere
    this.centers = [];
    this.checkers = []; // Keep if needed elsewhere
    this.fetchExams();
    this.fetchExamCenter();
  }

  onFormValidityChange(isValid: boolean) {
    this.isFormValid = isValid;
  }
  resetForm() {
    this.savedForm = {};
    this.selectedRowId = null;
  }

  // Method called when filters change or Submit button is clicked
  async onFilterChange() {
    this.students = []; // Clear previous student list
    // Fetch students based on the selected filters
    await this.fetchFilteredStudents();
  }

  async fetchExams(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fechExam(page, limit);

    console.log('temExam---', tempClientDAta);

    if (tempClientDAta != false) {
      // console.log("exams========",tempClientDAta);
      this.temExam = [];
      this.temExam = tempClientDAta.map((item: any) => ({
        title: `${item.session_name}`,
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchClasses(page = 1, limit = 500) {
    // Keep if needed for other parts
    var tempClientDAta = await this.apiController.fetchClassesByFaculty(
      this.selectedFaculty,
      page,
      limit
    );
    if (tempClientDAta != false) {
      this.classes = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.classes.push({
          name: tempClientDAta[i].class_name,
          data: tempClientDAta[i],
          id: tempClientDAta[i].row_id,
        });
      }
    }
  }

  async fetchExamCenter(page = 1, limit = 500) {
    const tempClientData = await this.apiController.fetchExamCenter(
      page,
      limit
    );
    console.log('data', tempClientData);
    if (tempClientData !== false) {
      this.temCenter = [];
      this.temCenter = tempClientData.map((item: any) => ({
        title: `${item.center} - ${item.center_code}`,
        code: item.center_code?.toString(),
        value: item.row_id,
        data: item,
      }));
    }
  }

  // Fetch students based on selected filters
  async fetchFilteredStudents(page = 1, limit = 100) {
    // Check if required filters are selected before fetching
    if (!this.selectedGender || !this.selectedExam) {
      console.log('Required filters (gender, Exam) not selected.');
      this.students = []; // Ensure students are cleared if filters are missing
      return;
    }

    // Format dates if they exist, otherwise pass null or undefined
    const formattedFromDate = this.fromDate
      ? this.utiltiesService.formatDateForApi(this.fromDate)
      : null;
    const formattedToDate = this.toDate
      ? this.utiltiesService.formatDateForApi(this.toDate)
      : null;

    console.log('Fetching students with filters:', {
      center: this.selectedCenter,
      exam: this.selectedExam,
      gender: this.selectedGender,
      from: formattedFromDate,
      to: formattedToDate,
    });

    var tempClientDAta = await this.apiController.fetchStudentByCenterwise(
      this.selectedCenter,
      this.selectedExam,
      this.selectedGender, // Send 'All', 'm', or 'f'
      formattedFromDate,
      formattedToDate,
      page,
      limit
    );
    if (tempClientDAta != false) {
      this.students = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        // Map API response fields to the fields expected by the table
        var age =
          tempClientDAta[i].dob != null
            ? this.utiltiesService.calculateAge(tempClientDAta[i].dob)
            : '-';
        this.students.push({
          rollNo: tempClientDAta[i].roll_no,
          studentName: tempClientDAta[i].student_name,
          fatherName: tempClientDAta[i].father_name,
          address: tempClientDAta[i].address,
          aadharNo: tempClientDAta[i].aadhar_no, // Adjust field names as per your API response
          phone: tempClientDAta[i].phone,
          age: age,
          class: tempClientDAta[i].class_name, // Assuming class name is needed
          accountNo: tempClientDAta[i].account_no,
          accountName: tempClientDAta[i].account_name,
          ifscCode: tempClientDAta[i].ifsc_code,
          // Keep original data if needed for other operations
          originalData: tempClientDAta[i],
          id: tempClientDAta[i].row_id, // Use a unique ID for potential row operations
        });
      }
      console.log('Fetched students:', this.students);
    } else {
      this.students = []; // Ensure students array is empty if fetch fails
      console.log('No students found or API error.');
    }
  }

  editClient(cl: any) {
    this.savedForm = cl.originalData;
    this.selectedRowId = cl.rowId;
  }
  deleteClient(cl: any) {
    // console.log(cl);
  }

  fetchNextData(row: any) {
    // Implement pagination for filtered results if needed
    // const page = row.page;
    // const limit = row.limit;
    // this.fetchFilteredStudents(page, limit);
  }
  async fetchCount() {
    // Adjust count logic if needed for filtered data
    // var totRec = await this.apiController.fetchCount('bandals'); // Or a specific count endpoint
    // if (totRec != false) {
    //   this.totalRecords = totRec;
    //   this.noofpage = Math.ceil(this.totalRecords / this.limit);
    // }
  }

  searchValues_Exam: { [key: string]: string } = {};
  showDropdown_Exam: { [key: string]: boolean } = {};
  filteredOptions_Exam: { [key: string]: any[] } = {};
  focusedIndex_Exam: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_Exam(id: string) {
    const query = this.searchValues_Exam[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_Exam[id] = [...this.temExam];
    } else {
      this.filteredOptions_Exam[id] = this.temExam.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_Exam[id] = 0;
  }

  selectOption_Exam(id: string, option: any) {
    this.searchValues_Exam[id] = option.title;
    this.selectedExam = option.value;
    this.showDropdown_Exam[id] = false;
    this.fetchClasses();
  }

  hideDropdownWithDelay_Exam(id: string) {
    setTimeout(() => {
      this.showDropdown_Exam[id] = false;
    }, 200);
  }

  handleKeydown_Exam(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_Exam[id] || [];
    let index = this.focusedIndex_Exam[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    }
  }

  searchValues: { [key: string]: string } = {};
  showDropdown: { [key: string]: boolean } = {};
  filteredOptions: { [key: string]: any[] } = {};
  focusedIndex: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions(id: string) {
    const query = this.searchValues[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions[id] = [...this.temCenter];
    } else {
      this.filteredOptions[id] = this.temCenter.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex[id] = 0;
  }

  selectOption(id: string, option: any) {
    this.searchValues[id] = option.title;
    this.selectedCenter = option.value;
    this.showDropdown[id] = false;
  }

  hideDropdownWithDelay(id: string) {
    setTimeout(() => {
      this.showDropdown[id] = false;
    }, 200);
  }

  handleKeydown(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions[id] || [];
    let index = this.focusedIndex[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex[id] = index;

      // Select option immediately
      this.selectOption(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex[id] = index;

      // Select option immediately
      this.selectOption(id, options[index]);

      event.preventDefault();
    }
  }
}
