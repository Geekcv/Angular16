import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddsampleBookComponent } from './addsample-book.component';

describe('AddsampleBookComponent', () => {
  let component: AddsampleBookComponent;
  let fixture: ComponentFixture<AddsampleBookComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddsampleBookComponent]
    });
    fixture = TestBed.createComponent(AddsampleBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
