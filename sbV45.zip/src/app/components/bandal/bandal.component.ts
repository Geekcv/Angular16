import { Component, OnInit, ViewChild } from '@angular/core'; // Import OnInit
import { FormsService } from 'src/app/constants/forms.service';
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from 'src/app/custom-components/form-builder/form-builder.component';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-bandal',
  templateUrl: './bandal.component.html',
  styleUrls: ['./bandal.component.css']
})
// Implement OnInit
export class BandalComponent implements OnInit {
 @ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;
  constructor(public formsService: FormsService, private apiController: ApicontrollerService, public utiltiesService: UtiltiesService,public jsonlist:JsonListService) { }
  selectedRowId: any;
  searchFields: any =  this.formsService.studentTableData.searchFields;
  students: any = [];
  tableDataHeader: any = this.formsService.studentTableData.tableDataHeader;
  tableTitle: any =  this.formsService.studentTableData.title;
  savedForm: any = {};
  isFormValid: boolean = false;
  totalRecords: any=100;
  limit: any = 5;
  noofpage: any = 1;
  bundleNo:any;
  displayDialog: boolean = false;
  selectedStudent: any = null;
  exams: any[] = [];
  classes: any[] = [];
  centers: any[] = [];
  checkers: any[] = [];
  filteredCenters: any[] = [];
  selectedFaculty: any = null;
  selectedExam: any = null;
  selectedClass: any = null;
  selectedCenter: any = null;
  selectedChecker: any = null;
  selectedStudents:any=[];
    faculty:any[]=[];

    temfaculty: any = [];
    temExam: any = [];
    temclass: any = [];
    temCenter: any = [];
    temcheckers:any = [];
  ngOnInit() {
    // Don't fetch all students initially, wait for filters
    // this.fetchStudents();
    this.loadInitialData();
  }

  loadInitialData() {
    this.exams = [];
    this.classes = [];
    this.centers = [];
    this.checkers = []; 
    this.faculty = []
    this.fetchExams();
    // this.fetchExamCenter(); // Keep if needed elsewhere, but not directly for this component's main table
    this.fetchSheetChecker();
    this.fetchLatestBundlNo();
    this.fetchfaculty();

  }

  onFormValidityChange(isValid: boolean) {
    this.isFormValid = isValid;
  }
  resetForm() {
    this.savedForm = {};
    this.selectedRowId = null;
  }

  // Method called when Faculty, Exam, or Class dropdown changes
  async onFilterChange() {
    this.students = []; // Clear previous student list
    this.selectedStudents = []; // Clear selection
    if (this.selectedFaculty && this.selectedExam && this.selectedClass) {
      // Fetch students based on the selected filters
      await this.fetchFilteredStudents();
    }
  }

  async fetchLatestBundlNo(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fetchLatestBundlNo(page, limit);
    if (tempClientDAta != false ) {
    // console.log("bundle_no========",tempClientDAta);
      // Increment the last bundle number or handle logic as needed
      this.bundleNo =tempClientDAta
    } else {
        // this.bundleNo = 1; // Start from 1 if none exist
    }
  }

  async fetchSheetChecker(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fetchSheetCheckers(page, limit);
    if (tempClientDAta != false) {
    // console.log("checkers========",tempClientDAta); // Corrected log message
      this.temcheckers = []; // Clear existing checkers
        this.temcheckers = tempClientDAta.map((item: any) => ({

          
          title: `${item.name}`,
          data: item,
            value: item.row_id,
          
        }));

    }

    if (tempClientDAta != false) {
      this.temclass = [];
      // console.log("classes========",tempClientDAta);
      this.temclass = tempClientDAta.map((item: any) => ({
        title: `${item.class_name}`,
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchClasses(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchClassesByFaculty(
      this.selectedFaculty,
      page,
      limit
    );
    console.log('tem---', tempClientDAta);
    if (tempClientDAta != false) {
      this.temclass = [];
      // console.log("classes========",tempClientDAta);
      this.temclass = tempClientDAta.map((item: any) => ({
        title: `${item.class_name}`,
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchExams(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchExameByFaculty(
      this.selectedFaculty,
      page,
      limit
    );
    console.log('temExam---', tempClientDAta);

    if (tempClientDAta != false) {
      // console.log("exams========",tempClientDAta);
      this.temExam = [];
      this.temExam = tempClientDAta.map((item: any) => ({
        title: `${item.session_name}`,
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchExamCenter(page = 1, limit = 500) {
    const tempClientData = await this.apiController.fetchExamCenter(
      page,
      limit
    );
    console.log('data', tempClientData);
    if (tempClientData !== false) {
      this.temCenter = [];
      this.temCenter = tempClientData.map((item: any) => ({
        title: `${item.center} - ${item.center_code}`,
        code: item.center_code?.toString(),
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchfaculty(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchfaculty(page, limit);
    console.log('datafaculty', tempClientDAta);
    if (tempClientDAta != false) {
      this.temfaculty = [];
      // console.log("exams========",tempClientDAta);
      this.temfaculty = tempClientDAta.map((item: any) => ({
        title: `${item.faculty_name}`,
        value: item.row_id,
        data: item,
      }));
    }
    this.fetchExams();
  }


  // async fetchExamCenter(page = 1, limit = 500) {
  //   var tempClientDAta = await this.apiController.fetchExamCenter(page, limit);
  //   if (tempClientDAta != false) {
  //     this.centers = [];
  //     for (var i = 0; i < tempClientDAta.length; i++) {
  //     // console.log("centers========",tempClientDAta);
  //       this.centers.push(
  //         {
  //           title: tempClientDAta[i].center,
  //           data: tempClientDAta[i],
  //           value: tempClientDAta[i].row_id
  //         }
  //       );
  //     }
  //   }
  // }

  // Fetch students based on selected filters
  async fetchFilteredStudents(page = 1, limit = 100) {
    if (!this.selectedFaculty || !this.selectedExam || !this.selectedClass) {
        return; // Don't fetch if filters aren't set
    }
    // Pass filter values to the API call
    var tempClientDAta = await this.apiController.fetchStudentsByFilter(
        this.selectedFaculty,
        this.selectedExam,
        this.selectedClass,
        page,
        limit
    );
    if (tempClientDAta != false) {
      this.students = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.students.push(
          {
            name: tempClientDAta[i].student_name,
            rollNo: tempClientDAta[i].roll_no || `TEMP-${i}`,
            father_name: tempClientDAta[i].father_name,
            dob: tempClientDAta[i].dob,
            address: tempClientDAta[i].address,
            city: tempClientDAta[i].city,
            originalData: tempClientDAta[i],
            id: tempClientDAta[i].row_id // Use 'id' for dataKey
          }
        );
      }
      // Optionally update totalRecords if pagination is needed for filtered results
      // this.totalRecords = await this.apiController.fetchFilteredStudentCount(...)
    } else {
        this.students = []; // Ensure students array is empty if fetch fails
    }
  }


  editClient(cl: any) {
    this.savedForm=cl.originalData;
    this.selectedRowId = cl.rowId;
  }
  deleteClient(cl: any) {
   // console.log(cl);
  }

  fetchNextData(row: any) {
    // If pagination is needed for filtered results, call fetchFilteredStudents
    // const page = row.page;
    // const limit = row.limit;
    // this.fetchFilteredStudents(page, limit);
  }
  async fetchCount() {
    // This might need adjustment if counting filtered students
    var totRec = await this.apiController.fetchCount('bandals');
    if (totRec != false) {
      this.totalRecords = totRec;
      this.noofpage = Math.ceil(this.totalRecords / this.limit);
    }
  }

  // --- Dialog methods (Keep if needed for other actions, remove if not) ---
  showActionDialog(student: any) {
    this.selectedStudent = student;
    this.selectedExam = null;
    this.selectedClass = null;
    this.selectedCenter = null;
    this.filteredCenters = [];
    this.displayDialog = true;
  }

  hideDialog() {
    this.displayDialog = false;
    this.selectedStudent = null;
  }

  searchCenter(event: any) {
    let query = event.query;
    this.filteredCenters = this.centers.filter(center => {
      return center.title.toLowerCase().includes(query.toLowerCase());
    });
  }
  // --- End of Dialog methods ---

  async assignCopies() {
    // Check if students are selected and a checker is chosen
    if (this.selectedStudents && this.selectedStudents.length > 0 && this.selectedChecker) {
    // console.log('Assigning Copies:', {
      //   students: this.selectedStudents.map((s:any) => s.id), // Send only IDs or necessary data
      //   examId: this.selectedExam,
      //   classId: this.selectedClass,
      //   facultyId: this.selectedFaculty,
      //   checkerId: this.selectedChecker,
      //   bundleNo: this.bundleNo
      // });
      var studentids: any[]=[];

      this.selectedStudents.forEach((student:any) => {
        studentids.push(student.id);
      }
      );
      // Call the API to create the bundle/assignment
       await this.apiController.createBundle(
        studentids, // Send the selected student objects or just IDs
          this.selectedExam,
          this.selectedClass,
          this.selectedFaculty, // Pass faculty
          this.selectedChecker,
          this.bundleNo
      );

   

    } else {
      console.error('Form is not complete. Select students and a checker.');
      // Optionally show a message to the user
    }
  }

  searchValues_faculty: { [key: string]: string } = {};
  showDropdown_faculty: { [key: string]: boolean } = {};
  filteredOptions_faculty: { [key: string]: any[] } = {};
  focusedIndex_faculty: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_faculty(id: string) {
    const query = this.searchValues_faculty[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_faculty[id] = [...this.temfaculty];
    } else {
      this.filteredOptions_faculty[id] = this.temfaculty.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_faculty[id] = 0;
  }

  selectOption_faculty(id: string, option: any) {
    this.searchValues_faculty[id] = option.title;
    this.selectedFaculty = option.value;
    this.showDropdown_faculty[id] = false;
    this.fetchExams();
  }

  hideDropdownWithDelay_faculty(id: string) {
    setTimeout(() => {
      this.showDropdown_faculty[id] = false;
    }, 200);
  }

  handleKeydown_faculty(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_faculty[id] || [];
    let index = this.focusedIndex_faculty[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_faculty[id] = index;

      // Select option immediately
      this.selectOption_faculty(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_faculty[id] = index;

      // Select option immediately
      this.selectOption_faculty(id, options[index]);

      event.preventDefault();
    }
  }

  searchValues_Exam: { [key: string]: string } = {};
  showDropdown_Exam: { [key: string]: boolean } = {};
  filteredOptions_Exam: { [key: string]: any[] } = {};
  focusedIndex_Exam: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_Exam(id: string) {
    const query = this.searchValues_Exam[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_Exam[id] = [...this.temExam];
    } else {
      this.filteredOptions_Exam[id] = this.temExam.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_Exam[id] = 0;
  }

  selectOption_Exam(id: string, option: any) {
    this.searchValues_Exam[id] = option.title;
    this.selectedExam = option.value;
    this.showDropdown_Exam[id] = false;
    this.fetchClasses();
  }

  hideDropdownWithDelay_Exam(id: string) {
    setTimeout(() => {
      this.showDropdown_Exam[id] = false;
    }, 200);
  }

  handleKeydown_Exam(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_Exam[id] || [];
    let index = this.focusedIndex_Exam[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    }
  }

  searchValues_class: { [key: string]: string } = {};
  showDropdown_class: { [key: string]: boolean } = {};
  filteredOptions_class: { [key: string]: any[] } = {};
  focusedIndex_class: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_class(id: string) {
    const query = this.searchValues_Exam[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_class[id] = [...this.temclass];
    } else {
      this.filteredOptions_class[id] = this.temclass.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_class[id] = 0;
  }

  selectOption_class(id: string, option: any) {
    this.searchValues_class[id] = option.title;
    this.selectedClass = option.value;
    this.showDropdown_class[id] = false;
    this.fetchClasses();
  }

  hideDropdownWithDelay_class(id: string) {
    setTimeout(() => {
      this.showDropdown_class[id] = false;
    }, 200);
  }

  handleKeydown_class(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_class[id] || [];
    let index = this.focusedIndex_class[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_class[id] = index;

      // Select option immediately
      this.selectOption_class(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_class[id] = index;

      // Select option immediately
      this.selectOption_class(id, options[index]);

      event.preventDefault();
    }
  }






  searchValues_Checker: { [key: string]: string } = {};
  showDropdown_Checker: { [key: string]: boolean } = {};
  filteredOptions_Checker: { [key: string]: any[] } = {};
  focusedIndex_Checker: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_Checker(id: string) {
    const query = this.searchValues_Checker[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_Checker[id] = [...this.temcheckers];
    } else {
      this.filteredOptions_Checker[id] = this.temcheckers.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_Checker[id] = 0;
  }

  selectOption_Checker(id: string, option: any) {
    this.searchValues_Checker[id] = option.title;
    this.selectedChecker = option.value;
    this.showDropdown_Checker[id] = false;
    this.fetchClasses();
  }

  hideDropdownWithDelay_Checker(id: string) {
    setTimeout(() => {
      this.showDropdown_Checker[id] = false;
    }, 200);
  }

  handleKeydown_Checker(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_Checker[id] || [];
    let index = this.focusedIndex_Checker[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_Checker[id] = index;

      // Select option immediately
      this.selectOption_Checker(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_Checker[id] = index;

      // Select option immediately
      this.selectOption_Checker(id, options[index]);

      event.preventDefault();
    }
  }
}