import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PressNoteResultReportComponent } from './press-note-result-report.component';

describe('PressNoteResultReportComponent', () => {
  let component: PressNoteResultReportComponent;
  let fixture: ComponentFixture<PressNoteResultReportComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PressNoteResultReportComponent]
    });
    fixture = TestBed.createComponent(PressNoteResultReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
