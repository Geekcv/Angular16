import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentlastExamstatusComponent } from './studentlast-examstatus.component';

describe('StudentlastExamstatusComponent', () => {
  let component: StudentlastExamstatusComponent;
  let fixture: ComponentFixture<StudentlastExamstatusComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StudentlastExamstatusComponent]
    });
    fixture = TestBed.createComponent(StudentlastExamstatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
