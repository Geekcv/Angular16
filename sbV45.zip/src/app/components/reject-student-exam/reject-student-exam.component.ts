import { Component, OnInit } from '@angular/core';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service'; // Adjust path
import { UtiltiesService } from 'src/app/services/utilties.service'; // Adjust path

@Component({
  selector: 'app-reject-student-exam',
  templateUrl: './reject-student-exam.component.html',
  styleUrls: ['./reject-student-exam.component.css']
})
export class RejectStudentExamComponent implements OnInit {

  // Dropdown options
  examSessions: any[] = [];
  temExam:any =[]
  // Selected filter values
  selectedExamSession: any = null;

  // Data for the report table
  rejectedStudents: any[] = []; // e.g., [{ name: '...', fatherHusbandName: '...', ..., remarks: '...' }, ...]
  submitted: boolean = false; // To track if submit was clicked

  constructor(
    private apiController: ApicontrollerService,
    private utiltiesService: UtiltiesService // For export
  ) { }

  ngOnInit(): void {
    this.loadInitialData();
  }

  async loadInitialData() {
    // Fetch exam sessions
    this.examSessions = []; // Adapt API call
    this.fetchExams();
    // Map data if needed to {name: '...', id: '...'} format for dropdowns
  }

  async fetchExams(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fechExam(page, limit);

    console.log('temExam---', tempClientDAta);

    if (tempClientDAta != false) {
      // console.log("exams========",tempClientDAta);
      this.temExam = [];
      this.temExam = tempClientDAta.map((item: any) => ({
        title: `${item.session_name}`,
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchRejectedStudents() {
    this.submitted = true;
    this.rejectedStudents = []; // Clear previous results
    if (!this.selectedExamSession) {
      console.error("Please select an Exam Session.");
      return;
    }
    console.log('Fetching rejected students for session:', this.selectedExamSession);

    // Call API to fetch rejected students based on the selected session
    const fetchedData = await this.apiController.fetchRejectStudentExam(
        this.selectedExamSession
    ) || []; // Create this API call

    // Map fetchedData to the structure needed by the table
    this.rejectedStudents = fetchedData.map((item: any) => ({
        name: item.student_name, // Adjust field names based on API response
        fatherHusbandName: item.father_name,
        address: item.address,
        centerCode: item.center_code,
        centerName: item.center,
        rollNo: item.roll_no,
        phoneNo: item.phone_no,
        mobileNo: item.mobile_no,
        remarks: item.remarks, // Reason for rejection
        id: item.row_id // Or another unique identifier
    }));
    console.log('Fetched rejected students:', this.rejectedStudents);
  }

  // --- Helper method for display ---
  getSessionName(id: any): string | null {
    const item = this.examSessions.find(e => e.id === id);
    return item ? item.name : null;
  }
  // --- End Helper method ---

  exportData() {
    if (this.rejectedStudents && this.rejectedStudents.length > 0) {
      console.log("Exporting data...", this.rejectedStudents);
      this.rejectedStudents.forEach((item: any) => {
        delete item.id;

      });
      this.utiltiesService.exportAsExcelFile(this.rejectedStudents, 'RejectedExamStudentsReport');
    } else {
      console.warn("No data to export.");
    }
  }

  printReport() {
    this.utiltiesService.printReport('report', 'RejectedExamStudentsReport'); // Adjust the ID of the report section
  }

  searchValues_Exam: { [key: string]: string } = {};
  showDropdown_Exam: { [key: string]: boolean } = {};
  filteredOptions_Exam: { [key: string]: any[] } = {};
  focusedIndex_Exam: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_Exam(id: string) {
    const query = this.searchValues_Exam[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_Exam[id] = [...this.temExam];
    } else {
      this.filteredOptions_Exam[id] = this.temExam.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_Exam[id] = 0;
  }

  selectOption_Exam(id: string, option: any) {
    this.searchValues_Exam[id] = option.title;
    this.selectedExamSession = option.value;
    this.showDropdown_Exam[id] = false;
  }

  hideDropdownWithDelay_Exam(id: string) {
    setTimeout(() => {
      this.showDropdown_Exam[id] = false;
    }, 200);
  }

  handleKeydown_Exam(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_Exam[id] || [];
    let index = this.focusedIndex_Exam[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    }
  }
}
