import { Component, OnInit } from '@angular/core';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service'; // Adjust path
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-admission-card',
  templateUrl: './admission-card.component.html',
  styleUrls: ['./admission-card.component.css']
})
export class AdmissionCardComponent implements OnInit {

  // Dropdown options
  examSessions: any[] = [];
  centers: any[] = [];

  // Selected filter values
  selectedExamSession: any = null;
  selectedCenter: any = null;
  rollNo: string = '';
  temCenter:any = []
  temExam:any =[]

  // Data for the admission card
  admissionData: any = []; // e.g., { permanentRollNo: '...', studentName: '...', ... }
  submitted: boolean = false; // To track if submit was clicked

  constructor(
    private apiController: ApicontrollerService,
    private utiltiesService: UtiltiesService // For export
  ) { }

  ngOnInit(): void {
    this.loadInitialData();
  }

  async loadInitialData() {
    this.examSessions = []; // Adapt API call
    // Fetch centers
    this.centers = []; // Adapt API call
    // Map data if needed to {name: '...', id: '...'} format for dropdowns
    this.fetchExams();
    this.fetchExamCenter();
  }

  getSessionName(examId: any): string | null {
    const exam = this.examSessions.find(e => e.id === examId);
    // console.log("exam============",exam)
    return exam ? exam.name : null;
  }
  async fetchExams(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fechExam(page, limit);

    console.log('temExam---', tempClientDAta);

    if (tempClientDAta != false) {
      // console.log("exams========",tempClientDAta);
      this.temExam = [];
      this.temExam = tempClientDAta.map((item: any) => ({
        title: `${item.session_name}`,
        value: item.row_id,
        data: item,
      }));
    }
  }


  async fetchExamCenter(page = 1, limit = 500) {
    const tempClientData = await this.apiController.fetchExamCenter(
      page,
      limit
    );
    console.log('data', tempClientData);
    if (tempClientData !== false) {
      this.temCenter = [];
      this.temCenter = tempClientData.map((item: any) => ({
        title: `${item.center} - ${item.center_code}`,
        code: item.center_code?.toString(),
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchAdmissionCard() {
    this.submitted = true; // Mark that submit was attempted
    this.admissionData = []; // Reset previous data
    if (!this.selectedExamSession || !this.selectedCenter) {
      console.error("Please select Exam Session, Center");
      return;
    }
    console.log('Fetching admission card for:', this.selectedExamSession, this.selectedCenter, this.rollNo);

    // Call API to fetch admission card details based on filters
    const fetchedData = await this.apiController.fetchAdmissionCardDetails(
      this.selectedExamSession,
      this.selectedCenter,
      this.rollNo
    ); // Create this API call

    if (fetchedData) {
      // Assuming API returns data matching the fields needed
      for (var i = 0; i < fetchedData.length; i++) {
        var tempdata = {
          permanentRollNo: fetchedData[i].roll_no, // Adjust field names based on API response
          studentName: fetchedData[i].student_name,
          fatherHusbandName: fetchedData[i].father_name,
          addressAndPhone: fetchedData[i].address +"("+fetchedData[i]['mobile_no']+")",
          class: fetchedData[i].class_name,
          examDate: fetchedData[i].exam_date ? new Date(fetchedData[i].exam_date) : null, // Convert to Date if needed
          examinationCenter: fetchedData[i].center_name,
          examName: this.getSessionName(this.selectedExamSession), // Get exam name from ID
          // Add other fields if needed
        };
        this.admissionData.push(tempdata);
      }

      console.log('Fetched admission data:', this.admissionData);
    } else {
      console.log("No admission card data found.");
    }
  }

  printCard() {
this.utiltiesService.printReport('admissionCard','Admission Card'); // Adjust the ID of the element to print
  }

  searchValues_Exam: { [key: string]: string } = {};
  showDropdown_Exam: { [key: string]: boolean } = {};
  filteredOptions_Exam: { [key: string]: any[] } = {};
  focusedIndex_Exam: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions_Exam(id: string) {
    const query = this.searchValues_Exam[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions_Exam[id] = [...this.temExam];
    } else {
      this.filteredOptions_Exam[id] = this.temExam.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex_Exam[id] = 0;
  }

  selectOption_Exam(id: string, option: any) {
    this.searchValues_Exam[id] = option.title;
    this.selectedExamSession = option.value;
    this.showDropdown_Exam[id] = false;
  }

  hideDropdownWithDelay_Exam(id: string) {
    setTimeout(() => {
      this.showDropdown_Exam[id] = false;
    }, 200);
  }

  handleKeydown_Exam(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions_Exam[id] || [];
    let index = this.focusedIndex_Exam[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex_Exam[id] = index;

      // Select option immediately
      this.selectOption_Exam(id, options[index]);

      event.preventDefault();
    }
  }

  searchValues: { [key: string]: string } = {};
  showDropdown: { [key: string]: boolean } = {};
  filteredOptions: { [key: string]: any[] } = {};
  focusedIndex: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions(id: string) {
    const query = this.searchValues[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions[id] = [...this.temCenter];
    } else {
      this.filteredOptions[id] = this.temCenter.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex[id] = 0;
  }

  selectOption(id: string, option: any) {
    this.searchValues[id] = option.title;
    this.selectedCenter = option.value;
    this.showDropdown[id] = false;
  }

  hideDropdownWithDelay(id: string) {
    setTimeout(() => {
      this.showDropdown[id] = false;
    }, 200);
  }

  handleKeydown(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions[id] || [];
    let index = this.focusedIndex[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex[id] = index;

      // Select option immediately
      this.selectOption(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex[id] = index;

      // Select option immediately
      this.selectOption(id, options[index]);

      event.preventDefault();
    }
  }
}
