import { Component, ElementRef, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { DiagnosisComponent } from 'app/modules/admin/dialog/doctor/audio/diagnosis/diagnosis.component';
import { FormulationComponent } from 'app/modules/admin/dialog/doctor/audio/formulation/formulation.component';
import { HistoryComponent } from 'app/modules/admin/dialog/doctor/audio/history/history.component';
import { RateComponent } from 'app/modules/admin/dialog/doctor/audio/rate/rate.component';
import { ViewChatComponent } from 'app/modules/admin/dialog/doctor/chats/view-chat/view-chat.component';
import { FormPreviewComponent } from 'app/modules/admin/formBuilder/components/form-preview/form-preview.component';
import { config } from '../../../../../../config';

interface Patient {

  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name: string;
  user_contact_number: string;
  user_password: string;
  user_row_id: string;
}

interface mediaMetadata {
  date: string;
  description: string;
  filename: string;
  filesize: string;
  time: string;
  media_link: string;
}

@Component({
  selector: 'app-audio-notes',
  imports: [MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatInputModule,
    MatPaginatorModule,
  ],
  templateUrl: './audio-notes.component.html',
  styleUrl: './audio-notes.component.css'
})
export class AudioNotesComponent {



  audiodata: any;
  patientname: any;
  row_id: any;
  userrowId: any;
  audiomediadata: mediaMetadata[] = [];


  @ViewChild('audioPlayer') audioPlayer!: ElementRef<HTMLAudioElement>

  constructor(
    private _matDialog: MatDialog,
    private Apicontroller: ApicontrollerService,
    private route: ActivatedRoute,
    private router: Router,

  ) {
    this.patientsId = this.route.snapshot.paramMap.get('id');

  }


  displayedColumns: string[] = [
    'date',
    'time',
    // 'filename',
    // 'filesize',
    // 'description',


    'actions'
  ];


  patientsId!: string | null; // Holds the patientsId ID from the route

  isviewbtn: any = false;


  isviewaudioboxbtn: any = false;
  ishistorybtn: any = false;
  isformulationbtn: any = false
  isdiagnosisbtn: any = false;
  isratebtn: any = false;

  selectedRow: any = null;
  selectedAction: string | null = null; // Store selected action separately
  media_link:any;

    config: string = config.apiBaseURL;
  

  viewaudioboxbtn(media: any) {

    console.log("view data",media)
    this.selectedRow = media;
    this.selectedAction = 'view';

    this.isviewaudioboxbtn = true;
    this.ishistorybtn = false;
    this.isformulationbtn = false;
    this.isdiagnosisbtn = false;
    this.isratebtn = false;

    this.row_id = media.filename;
    this.media_link = media.media_link;
    setTimeout(() => {
      this.audioPlayer.nativeElement.load()
    })


  }

  historybtn(media: any) {
    this.selectedRow = media;
    this.selectedAction = 'history';

    this.ishistorybtn = true;
    this.isviewaudioboxbtn = false;
    this.isformulationbtn = false;
    this.isdiagnosisbtn = false;
    this.isratebtn = false;

    // this.row_id = Patient.patient_age

    this.media_link = media.media_link;
    setTimeout(() => {
      this.audioPlayer.nativeElement.load()
    })


  }

  formulationbtn(media: any) {
    this.selectedRow = media;
    this.selectedAction = 'formulation';

    this.isformulationbtn = true;
    this.ishistorybtn = false;
    this.isviewaudioboxbtn = false;
    this.isdiagnosisbtn = false;
    this.isratebtn = false;

    // this.row_id = Patient.patient_gender

    this.media_link = media.media_link;
    setTimeout(() => {
      this.audioPlayer.nativeElement.load()
    })

  }

  diagnosisbtn(media: any) {
    this.selectedRow = media;
    this.selectedAction = 'diagnosis';

    this.isdiagnosisbtn = true;
    this.isformulationbtn = false;
    this.ishistorybtn = false;
    this.isviewaudioboxbtn = false;
    this.isratebtn = false;

    // this.row_id = Patient.user_contact_number

    this.media_link = media.media_link;
    setTimeout(() => {
      this.audioPlayer.nativeElement.load()
    })
  }

  ratebtn(media: any) {
    this.selectedRow = media;
    this.selectedAction = 'rate';

    this.isratebtn = true;
    this.isdiagnosisbtn = false;
    this.isformulationbtn = false;
    this.ishistorybtn = false;
    this.isviewaudioboxbtn = false;

    // this.row_id = Patient.user_row_id

    this.media_link = media.media_link;
    setTimeout(() => {
      this.audioPlayer.nativeElement.load()
    })
  }




  ngOnInit(): void {
    this.FetchAudioMedia();

    this.patientsId = this.route.snapshot.paramMap.get('id');
    // console.log("patientsId",this.patientsId)

    this.fetchSefesficpatients();
  }


  async fetchSefesficpatients(): Promise<void> {
    try {
      const response = await this.Apicontroller.fetchSefesficpatients(this.patientsId);
      this.patientname = response.data[0].patient_name || []; // Ensure `data` exists in the API response
      console.log("patient----", response.data[0].patient_name)

    } catch (error) {
      // console.error('Error fetching clients:', error);
    }
  }

  page: number = 1; // Default to first page

  async FetchAudioMedia() {
    try {
      const data = {
        row_id: this.patientsId,
        media_type: 'audio/mpeg',
      };

      console.log("data",data)

      const resp = await this.Apicontroller.fetchuserMedia(data);
      console.log("audio media --->", resp);
      this.audiodata = resp as mediaMetadata[]; // Type assert to Doctor[]
    } catch (error) {
      console.error("Error fetching audio media:", error);
    }

  }




  viewchatsdialogboxbtn() {
    // const dialogRef = this._matDialog.open(ViewChatComponent,{data: {patient:  this.row_id}});
  }

  historychatsdialogboxbtn() {

    const dialogRef = this._matDialog.open(HistoryComponent, { data: { medialink: this.media_link } });

  }

  formulationdialogboxbtn() {
    const dialogRef = this._matDialog.open(FormulationComponent, { data: { medialink: this.media_link } });

  }

  diagnosisdialogboxbtn() {
    const dialogRef = this._matDialog.open(DiagnosisComponent, { data: { medialink: this.media_link } });

  }

  ratedialogboxbtn() {
    const dialogRef = this._matDialog.open(RateComponent, { data: { medialink: this.media_link } });

  }

  goback(){
    // console.log("click this button")
    this.router.navigate(['/Viewpatients'])
  }

}
