import { Component, ElementRef, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { DiagnosisComponent } from 'app/modules/admin/dialog/doctor/video/diagnosis/diagnosis.component';
import { FormulationComponent } from 'app/modules/admin/dialog/doctor/video/formulation/formulation.component';
import { HistoryComponent } from 'app/modules/admin/dialog/doctor/video/history/history.component';
import { RateComponent } from 'app/modules/admin/dialog/doctor/video/rate/rate.component';
import { ViewVideonotesComponent } from 'app/modules/admin/dialog/doctor/view-videonotes/view-videonotes.component';
import { config } from '../../../../../../config';

interface Doctor {
    doctor_email: string;
    doctor_gender: string;
    doctor_name: string;
    user_contact_number: string;
    user_password: string;
    user_row_id: string;
  }
  
  interface Patient{
    patient_age: string;
    patient_email: string;
    patient_gender: string;
    patient_name: string;
    user_password: string;
    user_contact_number: string;
  }

interface mediaMetadata {
  date: string;
  description: string;
  filename: string;
  filesize: string;
  time: string;
  media_link: string;
}

@Component({
  selector: 'app-video-notes',
  imports: [MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatInputModule,
    MatPaginatorModule],
  templateUrl: './video-notes.component.html',
  styleUrl: './video-notes.component.css'
})
export class VideoNotesComponent {


 userDeatials: Doctor = {
        doctor_email: '',
        doctor_gender: '',
        doctor_name: '',
        user_contact_number: '',
        user_password: '',
        user_row_id: ''
      };
      role :any ='';
    
      patientDeatials: Patient = {
        patient_age: '',
      patient_email: '',
      patient_gender: '',
      patient_name: '',
      user_password: '',
      user_contact_number: ''
      };

      names :any = '';

  videodata: any;
  patientname: any;
  row_id: any;
  media_link: any;

  config: string = config.apiBaseURL;

  displayedColumns: string[] = [
    'date',
    'time',
    // 'filename',
    // 'filesize',
    // 'description',


    'actions'
  ];

  @ViewChild('videoPlayer') videoPlayer!: ElementRef<HTMLVideoElement>
  userrowId: any;

  constructor(
    private _matDialog: MatDialog,
    private Apicontroller: ApicontrollerService,
    private route: ActivatedRoute,
    private router: Router,

  ) {
    this.patientsId = this.route.snapshot.paramMap.get('id');

     this.role=  localStorage.getItem('role')

    if(this.role==2){
      this.patientDeatials = JSON.parse(localStorage.getItem("userDeatials"));

      this.names = this.patientDeatials.patient_name

      //console.log("name--",name)

    }else{
      
      this.userDeatials = JSON.parse(localStorage.getItem("userDeatials"));

      this.names = this.userDeatials.doctor_name
    }
  }





  patientsId!: string | null; // Holds the patientsId ID from the route

  isviewbtn: any = false;


  isviewvideoboxbtn: any = false;
  ishistorybtn: any = false;
  isformulationbtn: any = false
  isdiagnosisbtn: any = false;
  isratebtn: any = false;

  selectedRow: any = null;
  selectedAction: string | null = null; // Store selected action separately

   visitedActions: { [rowId: string]: string[] } = {};
   mediaData:any;

markActionAsVisited(rowId: string, action: string): void {
  if (!this.visitedActions[rowId]) {
    this.visitedActions[rowId] = [];
  }
  if (!this.visitedActions[rowId].includes(action)) {
    this.visitedActions[rowId].push(action);
  }
}

  viewvideoboxbtn(media: any) {
    this.selectedRow = media;
    this.selectedAction = 'view';

    this.isviewvideoboxbtn = true;
    this.ishistorybtn = false;
    this.isformulationbtn = false;
    this.isdiagnosisbtn = false;
    this.isratebtn = false;


    this.row_id = media.filename;
    this.media_link = media.media_link;
    this.mediaData = media

    setTimeout(() => {
      this.videoPlayer.nativeElement.load()
    })

    this.markActionAsVisited(media.row_id, 'view');

  }

  historybtn(media: any) {
    this.selectedRow = media;
    this.selectedAction = 'history';

    this.ishistorybtn = true;
    this.isviewvideoboxbtn = false;
    this.isformulationbtn = false;
    this.isdiagnosisbtn = false;
    this.isratebtn = false;

    // this.row_id = Patient.patient_age
    this.mediaData = media

    this.media_link = media.media_link;
    setTimeout(() => {
      this.videoPlayer.nativeElement.load()
    })
    this.markActionAsVisited(media.row_id, 'history');

  }

  formulationbtn(media: any) {
    this.selectedRow = media;
    this.selectedAction = 'formulation';

    this.isformulationbtn = true;
    this.ishistorybtn = false;
    this.isviewvideoboxbtn = false;
    this.isdiagnosisbtn = false;
    this.isratebtn = false;

    // this.row_id = Patient.patient_gender
    this.mediaData = media

    this.media_link = media.media_link;
    setTimeout(() => {
      this.videoPlayer.nativeElement.load()
    })
    this.markActionAsVisited(media.row_id, 'formulation');

  }

  diagnosisbtn(media: any) {
    this.selectedRow = media;
    this.selectedAction = 'diagnosis';

    this.isdiagnosisbtn = true;
    this.isformulationbtn = false;
    this.ishistorybtn = false;
    this.isviewvideoboxbtn = false;
    this.isratebtn = false;

    // this.row_id = Patient.user_contact_number
    this.mediaData = media

    this.media_link = media.media_link;
    setTimeout(() => {
      this.videoPlayer.nativeElement.load()
    })

    this.markActionAsVisited(media.row_id, 'diagnosis');

  }

  ratebtn(media: any) {
    this.selectedRow = media;
    this.selectedAction = 'rate';

    this.isratebtn = true;
    this.isdiagnosisbtn = false;
    this.isformulationbtn = false;
    this.ishistorybtn = false;
    this.isviewvideoboxbtn = false;
    
    this.mediaData = media


    // this.row_id = Patient.user_row_id

    this.media_link = media.media_link;
    setTimeout(() => {
      this.videoPlayer.nativeElement.load()
    })
    this.markActionAsVisited(media.row_id, 'rate');

  }




  ngOnInit(): void {
    this.FetchAudioMedia();

    this.patientsId = this.route.snapshot.paramMap.get('id');
    // console.log("patientsId",this.patientsId)

    this.fetchSefesficpatients();
  }


  async fetchSefesficpatients(): Promise<void> {
    try {
      const response = await this.Apicontroller.fetchSefesficpatients(this.patientsId);
      this.patientname = response.data[0].patient_name || []; // Ensure `data` exists in the API response
      console.log("patient----", response.data[0].patient_name)

    } catch (error) {
      // console.error('Error fetching clients:', error);
    }
  }

  page: number = 1; // Default to first page
  async FetchAudioMedia() {
    try {
      const data = {
        row_id: this.patientsId,
        media_type: 'video/mp4',
      };

      console.log("data",data)

      const resp = await this.Apicontroller.fetchuserMedia(data);
      console.log("audio media", resp);
      this.videodata = resp as mediaMetadata[]; // Type assert to Doctor[]
    } catch (error) {
      console.error("Error fetching audio media:", error);
    }

  }



  viewchatsdialogboxbtn() {
    // const dialogRef = this._matDialog.open(ViewChatComponent,{data: {patient:  this.row_id}});
  }

  historychatsdialogboxbtn() {
    const dialogRef = this._matDialog.open(HistoryComponent, { data: { medialink: this.media_link,mediadata:this.mediaData } });

  }

  formulationdialogboxbtn() {
    const dialogRef = this._matDialog.open(FormulationComponent, { data: { medialink: this.media_link,mediadata:this.mediaData } });

  }

  diagnosisdialogboxbtn() {
    const dialogRef = this._matDialog.open(DiagnosisComponent, { data: { medialink: this.media_link,mediadata:this.mediaData } });

  }

  ratedialogboxbtn() {
    const dialogRef = this._matDialog.open(RateComponent, { data: { medialink: this.media_link,mediadata:this.mediaData } });

  }

  goback(){
    // console.log("click this button")
    this.router.navigate(['/Viewpatients'])
  }
}
