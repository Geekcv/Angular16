import {
    Component,
    inject,
    OnInit,
    ViewChild,
    ViewEncapsulation,
} from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatRadioModule } from '@angular/material/radio';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { fuseAnimations } from '@fuse/animations';
import { FuseAlertType } from '@fuse/components/alert';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/core/auth/auth.service';

@Component({
    selector: 'auth-sign-in',
    templateUrl: './sign-in.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: fuseAnimations,
    imports: [
        // RouterLink,
        //FuseAlertComponent,
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatProgressSpinnerModule,
        MatRadioModule,
    ],
})
export class AuthSignInComponent implements OnInit {
    @ViewChild('signInNgForm') signInNgForm: NgForm;

    alert: { type: FuseAlertType; message: string } = {
        type: 'success',
        message: '',
    };
    signInForm: UntypedFormGroup;
    showAlert: boolean = false;

    private _snackBar = inject(MatSnackBar);

    /**
     * Constructor
     */
    constructor(
        private _activatedRoute: ActivatedRoute,
        private _authService: AuthService,
        private _formBuilder: UntypedFormBuilder,
        private _router: Router,
        private Apicontroller: ApicontrollerService,
        private router: Router,
        private route: ActivatedRoute
    ) {}

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void {
        // Create the form
        this.signInForm = this._formBuilder.group({
            phone: ['', [Validators.required]],
            password: ['', Validators.required],
            rememberMe: [''],
        });

        const token = this.route.snapshot.queryParamMap.get('token');

        if (token) {
            localStorage.setItem('token', token);
            this.router.navigate(['/dashboard']);
        } else {
            this.router.navigate(['/sign-in']);
        }
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    async signIn() {
        //     this.showAlert = false;

        const resp = await this.Apicontroller.loginuser(this.signInForm.value);

        console.log('resp------------>', resp.status);

        // console.log("resp",resp)
        // Checking resp
        if (resp.status === 0) {
            localStorage.setItem('token', resp.token);
            localStorage.setItem('role', resp.user_type);
            localStorage.setItem(
                'userDeatials',
                JSON.stringify(resp.user_details)
            );

            this._snackBar.open(resp.msg, '', {
                duration: 3000, // Duration in milliseconds (3 seconds)
                verticalPosition: 'top', // Position: 'top' | 'bottom'
                horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
            });
            // console.log("register successfully ")
            this._router.navigate(['/dashboard']);
        } else {
            // this.messageService.add({ severity: 'error', summary: 'Error', detail: resp.msg });
            //    console.log("error ")

            this._snackBar.open(resp.msg, '', {
                duration: 3000, // Duration in milliseconds (3 seconds)
                verticalPosition: 'top', // Position: 'top' | 'bottom'
                horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
            });
        }
    }

    signUp() {
        this._router.navigate(['/sign-up']);
    }

    forgotpassword() {
        this._router.navigate(['/forgot-password']);
    }

    // Default selected user type
    selectedUserType: 'doctor' | 'patient' = 'doctor';

    signwithGoogle() {
        if (!this.selectedUserType) {
            alert('Please select whether you are a Doctor or Patient');
            return;
        }

        console.log('type---------', this.selectedUserType);
        // Redirect to your backend with user type as query param
        window.location.href = `http://localhost:3000/common/auth/google?type=${this.selectedUserType}`;
    }
}
