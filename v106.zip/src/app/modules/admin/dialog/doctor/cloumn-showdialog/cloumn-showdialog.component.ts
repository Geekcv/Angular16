import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import {MatRadioModule} from '@angular/material/radio';
@Component({
  selector: 'app-cloumn-showdialog',
  imports: [MatDialogModule,MatRadioModule,MatButtonModule],
  templateUrl: './cloumn-showdialog.component.html',
  styleUrl: './cloumn-showdialog.component.scss'
})
export class CloumnShowdialogComponent {

  headerdata : any;

  constructor(
     @Inject(MAT_DIALOG_DATA) public data: {data: any},
           private dialogRef: MatDialogRef<CloumnShowdialogComponent> // Inject MatDialogRef    
  ){

    this.headerdata = data
    console.log("header data",this.headerdata)
  }

   exitbtn(){
    this.dialogRef.close();

   }

}
