import { Component, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { AddpatientdialogComponent } from '../../dialog/doctor/addpatientdialog/addpatientdialog.component';
import { MatDialog } from '@angular/material/dialog';
import { DeldialogComponent } from '../../dialog/deldialog/deldialog.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { SuspendPatientComponent } from '../../dialog/suspend-patient/suspend-patient.component';
import { CloumnShowdialogComponent } from '../../dialog/doctor/cloumn-showdialog/cloumn-showdialog.component';

interface Patient {
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name: string;
  user_contact_number: string;
  user_password: string;
  user_row_id: string;
  qualifications_details: string;
  qualifications: string;
}

interface Column {
  name: string;    // The column name/key (must match MatTable's columnDef)
  label: string;   // The displayed label for checkbox and header
  visible: boolean; // Whether this column is currently shown
}


@Component({
  selector: 'app-viewpatients',
  imports: [
    MatTableModule, MatButtonModule, MatIconModule, MatInputModule,
    MatPaginatorModule, CommonModule, FormsModule, MatSortModule
  ],
  templateUrl: './viewpatients.component.html',
  styleUrl: './viewpatients.component.css'
})
export class ViewpatientsComponent {
  // displayedColumns: string[] = [
  //   'user_row_id',
  //   'patient_name',
  //   'patient_email',
  //   'user_contact_number',
  //   'qualifications',
  //   'qualifications_details',
  //   'actions'
  // ];


  columns: Column[] = [
    { name: 'user_row_id', label: 'ID', visible: true },
    { name: 'patient_name', label: 'Name', visible: true },
    { name: 'patient_email', label: 'Email', visible: true },
    { name: 'user_contact_number', label: 'Contact Number', visible: true },
    { name: 'qualifications', label: 'Qualifications', visible: true },
    { name: 'qualifications_details', label: 'Qualification Details', visible: true },
    { name: 'actions', label: 'Actions', visible: true }
  ];

  get displayedColumns(): string[] {
    return this.columns.filter(c => c.visible).map(c => c.name);
  }


  role: any = '';
  patient = new MatTableDataSource<Patient>([]);

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(
    private Apicontroller: ApicontrollerService,
    private router: Router,
    private _matDialog: MatDialog
  ) {
    this.role = localStorage.getItem('role');
  }

  ngOnInit(): void {
    this.Patients();
  }

  ngAfterViewInit() {
    this.patient.paginator = this.paginator;
    this.patient.sort = this.sort;
  }

  page: number = 1;

  async Patients() {
    try {
      const resp = await this.Apicontroller.fetchPatients('common', this.page);
      this.patient.data = resp.data as Patient[];
    } catch (error) {
      console.error("Error fetching patients:", error);
    }
  }

  viewDoctorDetails(patient: Patient) {
    this.router.navigate(['patientDetails', patient.user_row_id]);
  }


  refresh() {
    this.Patients();
  }

  addpatientdialog() {
    this._matDialog.open(AddpatientdialogComponent, {
      position: { right: '1%' }
    });
  }

  deletebtn(patient: Patient) {
    this._matDialog.open(DeldialogComponent, { data: { patient: patient } });
  }

  viewpatientDetails(patient_rowId: string) {
    this.router.navigate(['patientpanel', patient_rowId]);
  }


 
  isSearchActive = false;

  suspendPatient(patient: any) {
    this._matDialog.open(SuspendPatientComponent, { data: { patient: patient } });
  }

  editRowId: number | null = null;

  editRow(rowId: number) {
    this.editRowId = rowId;
  }

  async saveRow(row: any) {
    this.editRowId = null;
    try {
      const resp = await this.Apicontroller.updatePatients('common', row);
      console.log("Patients update data:", resp);
    } catch (error) {
      console.error("Error updating patients:", error);
    }
  }

  cancelEdit() {
    this.editRowId = null;
  }

  displayheaderdata: any;

  isRowEditing(rowId: any) {
    return this.editRowId === rowId;
  }
  

  
}
