import { Component, ViewChild } from '@angular/core';
import { FormsService } from 'src/app/constants/forms.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from 'src/app/custom-components/form-builder/form-builder.component';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-exam',
  templateUrl: './exam.component.html',
  styleUrls: ['./exam.component.css']
})
export class ExamComponent {
@ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;
  constructor(public formsService: FormsService, private apiController: ApicontrollerService, public utiltiesService: UtiltiesService) { }
  selectedRowId: any;
  searchFields: any =  this.formsService.examTableData.searchFields;
  tableData: any = [];
  tableDataHeader: any = this.formsService.examTableData.tableDataHeader;
  tableDataRows:any = this.formsService.examTableData.tableDataRows;
  tableTitle: any =  this.formsService.examTableData.title;
  savedForm: any = {};
  isFormValid: boolean = false;
  totalRecords: any=100;
  limit: any = 100;
  noofpage: any = 1;
  ngOnInit() {
    this.fetchCount();
    this.fetchStudents();
  }

  async saveQuestion() {
 // console.log("Client Saved");
 // console.log(this.savedForm);
    var tempData=this.savedForm;
    await this.apiController.saveExam(tempData, this.selectedRowId);
    this.resetForm();
    this.fetchStudents();

  }

  onFormValidityChange(isValid: boolean) {
    this.isFormValid = isValid;
  }
  resetForm() {
    this.savedForm = {};
    this.selectedRowId = null;
  }

  async fetchStudents(page = 1, limit = 100) {
    var tempClientDAta = await this.apiController.fechExam(page, limit);
  // console.log("tempClientDAta");
  // console.log(tempClientDAta);
    if (tempClientDAta != false) {
      this.tableData = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.tableData.push(
          {
            "name": tempClientDAta[i].session_name,
            "exam_date": (new Date(tempClientDAta[i].exam_date)).toLocaleDateString(),
            
            "data": tempClientDAta[i],
            "rowId": tempClientDAta[i].row_id
          }
        );
      }
     // console.log("this.tableData========");
     // console.log(this.tableData);
    }
  }

 
  editClient(cl: any) {
 // console.log(cl);
    this.savedForm.name=cl.name;
    this.savedForm.exam_date=new Date(cl.data.exam_date);
    
    this.selectedRowId = cl.rowId;
 // console.log(this.savedForm);
  }
  deleteClient(cl: any) {
   // console.log(cl);
  }

  fetchNextData(row: any) {
   // console.log("fetchNextData");
    const page = row.page;
    const limit = row.limit;
   // console.log(page, limit);
    this.fetchStudents(page, limit);
  }
  async fetchCount() {
    var totRec = await this.apiController.fetchCount('exam_sessions');
   // console.log(totRec);
    if (totRec != false) {
      this.totalRecords = totRec;
      this.noofpage = Math.ceil(this.totalRecords / this.limit);
     // console.log(this.totalRecords);
    }
    this.fetchStudents();
  }

}
