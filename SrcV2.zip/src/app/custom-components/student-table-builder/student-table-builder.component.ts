import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { Table } from 'primeng/table';
import { FormsService } from 'src/app/constants/forms.service'
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';

@Component({
  selector: 'app-student-table-builder',
  templateUrl: './student-table-builder.component.html',
  styleUrls: ['./student-table-builder.component.css']
})
export class StudentTableBuilderComponent {
 @ViewChild('dt') dt: Table | undefined;
  @Output() editEvent = new EventEmitter();
  @Output() deleteEvent = new EventEmitter();
  @Output() fetchNextData = new EventEmitter();
  @Input() selectedtableData: any = [];
  @Input() searchFields: any = [];
  @Input() tableTitle: any = "Record List";
  @Input() totalRecords: any = 4;
  @Input() rows: any = 4;
  @Input() noofpages: any = 4;
  @Input() allowDelete: any = false;
  @Input() allowEdit: any = true;
@Input() width: any = '75rem';
@Input() height: any = '85rem';
  @Input() tableData: any = [

  ];
  @Input() filteredData: any = this.tableData;
  loading: any = false;
  viewDialog: boolean = false;
  selectedViewData: any = null;
  Examlogdata:any = [];
  temCenter:any = []

    // --- Add properties for the dialog ---
    displayDialog: boolean = false;
    selectedStudent: any = null; // Declare selectedStudent
    exams: any[] = []; // Example: [{label: 'Exam 1', value: 'E1'}, {label: 'Exam 2', value: 'E2'}]
    classes: any[] = []; // Example: [{label: 'Class A', value: 'C1'}, {label: 'Class B', value: 'C2'}]
    centers: any[] = []; // Example: [{id: 1, name: 'Center A'}, {id: 2, name: 'Center B'}] - This holds all centers
    filteredCenters: any[] = []; // For autocomplete suggestions
    selectedFaculty: any = null;
    selectedExam: any = null;
    selectedClass: any = null;
    selectedCenter: any = null;

  constructor(public formsService: FormsService, private apiController: ApicontrollerService,public jsonlist:JsonListService) {
  }

  ngOnChanges() {
    this.filteredData = this.tableData;
  }

  ngOnInit() {
    this.filteredData = this.tableData;
    this.loadInitialData();
  }

  loadInitialData() {
    // Placeholder: Load your exam, class, and center data here
    // Example:
    this.exams = [];
    this.classes = [];
    this.centers = [];
    // this.fetchClasses();
    this.fetchExams();
    this.fetchExamCenter();
  }

  @Input() tableDataHeader: any = [
  ];
  

  //  tableDataRows: any = this.formsService.studentTableData.tableDataRows;

  @Input() tableDataRows:any =[

  ]


  edit(pr: any) {
    this.editEvent.emit(pr);   
  }

  delete(pr: any) {
    this.deleteEvent.emit(pr);
  }


  
  openViewDialog(rowItem: any): void {
    this.selectedViewData = rowItem;
    this.viewDialog = true;
  }

  filterGlobal(event: Event) {

    const inputElement = event.target as HTMLInputElement;
    const value = inputElement.value;
    this.tableData = this.filterItems(this.filteredData, value);
  }
  onPageChagne(event: any) {
    this.loading = true;
   // console.log(event);
    var page = (event.first / event.rows) + 1;

    var nextPage = { page: page, limit: event.rows };
    this.fetchNextData.emit(nextPage);
    this.loading = false;
  }

  sortItems(items: any[], sortField: string, sortOrder: number): any[] {
    if (!sortField || sortOrder === 0) {
      return items;
    }

    return items.sort((a, b) => {
      const value1 = a[sortField];
      const value2 = b[sortField];
      const result = value1 < value2 ? -1 : value1 > value2 ? 1 : 0;
      return sortOrder * result;
    });
  }
  filterItems(items: any[], filter: string): any[] {
    if (!filter) {
      return items;
    }
    return items.filter(item => {
      return this.searchFields.some((field: string | number) => {
        return item[field]?.toString().toLowerCase().includes(filter.toLowerCase());
      });
    });
  }
  onSort(event: any) {
   // console.log(event);
    this.loading = true;
    this.tableData = this.sortItems(this.tableData, event.field, event.order);

    this.loading = false;
  }

  // applyFilters(items: any[], filters: any): any[] {
  //   if (!filters || Object.keys(filters).length === 0) {
  //     return items;
  //   }

  //   return items.filter(item => {
  //     // console.log("item=====qq=======", item);

  //     return Object.keys(filters).every(field => {
  //       return Object.keys(filters[field]).every(chfield => {
  //         // console.log("chfield============", chfield);
  //         // console.log("item[field]============");
  //         // console.log(filters[field][chfield]);
  //         const filterValue = filters[field][chfield].value??'';
  //         const filterMatchMode = filters[field][chfield].matchMode || 'contains';
  //         const fieldValue = item[chfield]? item[chfield].toString().toLowerCase() : '';

  //         if (filterMatchMode === 'contains') {
  //           return fieldValue.includes(filterValue.toLowerCase());
  //         }
  //         else if (filterMatchMode === 'startsWith') {
  //           return fieldValue.startsWith(filterValue.toLowerCase());
  //         }
  //         else if (filterMatchMode === 'endsWith') {
  //           return fieldValue.endsWith(filterValue.toLowerCase());
  //         }
  //         else if (filterMatchMode === 'equals') {
  //           return fieldValue === filterValue.toLowerCase();
  //         }
  //         else if (filterMatchMode === 'notEquals') {
  //           return fieldValue !== filterValue.toLowerCase();
  //         }
  //         else if (filterMatchMode === 'notContains') {
  //           return !fieldValue.includes(filterValue.toLowerCase());
  //         }
  //         else if(filterMatchMode==='nofilter'){
  //           return true;
  //         }
  //         return true; // Handle other match modes as needed
  //       });
  //     });
  //   });
  // }


  // onFilterChange(filter: any) {
  //  // console.log(filter);
  //   this.tableData = this.applyFilters(this.filteredData, filter);
  // }


  showActionDialog(student: any) {
    
    this.selectedStudent = student; // Set the selected student
    
    console.log("selected students---->",student)
    

    // Reset form fields when opening dialog
    this.selectedExam = null;
    this.selectedClass = null;
    this.selectedCenter = null;
    this.filteredCenters = [];
    this.displayDialog = true; // Show the dialog

    this.fetchExamlogStudent()
  }

  async fetchExamlogStudent(){
    console.log("selected students",this.selectedStudent.rowId)
    var exallogdata = await this.apiController.StudentExamLog(this.selectedStudent.rowId);
   
    console.log("res-->",exallogdata)
    if (exallogdata != false) {
      console.log("response dta============",exallogdata);
      this.Examlogdata = []; // Clear existing students
      for (var i = 0; i < exallogdata.length; i++) {
        // Map fetched data to the structure expected by the table/dialog
        // Ensure 'name' and 'rollNo' properties exist for the template
        this.Examlogdata.push(
          {
            name: exallogdata[i].student_name, 
            className: exallogdata[i].class_name,
            center: exallogdata[i].center,
            sessionName:exallogdata[i].session_name,
            examDate: exallogdata[i].exam_date,
            marks: exallogdata[i].marks,
          
          }
        );
      }
    }else{
      this.Examlogdata = []; // Clear existing students
    }
  }


  hideDialog() {
    this.displayDialog = false; // Hide the dialog
    this.selectedStudent = null; // Clear selected student
  }

  async assignDetails() {
    if (this.selectedStudent && this.selectedExam && this.selectedClass && this.selectedCenter) {
    // console.log('Assigning Details:', {
      //   studentId: this.selectedStudent.rowId, // or another unique ID
      //   studentName: this.selectedStudent.name,
      //   exam: this.selectedExam,
      //   class: this.selectedClass,
      //   center: this.selectedCenter // This will be the selected center object
      // });
   

await this.apiController.assignExamtoStudent(this.selectedStudent.rowId, this.selectedExam, this.selectedClass, this.selectedCenter,this.selectedFaculty);
      this.hideDialog(); // Close dialog on successful assignment
    } else {
      console.error('Form is not complete');
      // Optionally show a message to the user
    }
  }

  async fetchClasses(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchClassesByFaculty(this.selectedFaculty,page, limit);
    if (tempClientDAta != false) {
    // console.log("classes========",tempClientDAta);
      this.classes = []; // Clear existing students
      for (var i = 0; i < tempClientDAta.length; i++) {
        // Map fetched data to the structure expected by the table/dialog
        // Ensure 'name' and 'rollNo' properties exist for the template
        this.classes.push(
          {
            title: tempClientDAta[i].class_name, 
            data: tempClientDAta[i], // Keep original data if needed
            value: tempClientDAta[i].row_id
          }
        );
      }
    }
  }

  async fetchExams(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fechExam(page, limit);
    if (tempClientDAta != false) {
    // console.log("exams========",tempClientDAta);
      this.exams = []; // Clear existing students
      for (var i = 0; i < tempClientDAta.length; i++) {
        // Map fetched data to the structure expected by the table/dialog
        // Ensure 'name' and 'rollNo' properties exist for the template
        this.exams.push(
          {
            title: tempClientDAta[i].session_name, 
            data: tempClientDAta[i], // Keep original data if needed
            value: tempClientDAta[i].row_id
          }
        );
      }
    }
  }
 
  async fetchExamCenter(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchExamCenter(page, limit);
    console.log("tem data center",tempClientDAta.center_code)
    if (tempClientDAta != false) {
      this.centers = []; // Clear existing students
      for (var i = 0; i < tempClientDAta.length; i++) {
      // console.log("centers========",tempClientDAta);
        // Map fetched data to the structure expected by the table/dialog
        // Ensure 'name' and 'rollNo' properties exist for the template
        this.centers.push(
          {
            title: tempClientDAta[i].center + "-" +tempClientDAta[i].center_code, 
            data: tempClientDAta[i], // Keep original data if needed
            value: tempClientDAta[i].row_id,
            code: tempClientDAta[i].center_code
          }
        );

        this.temCenter = this.centers;
      }
    }
  }


  searchCenter(event: any) {
    // Basic filtering example, adjust as needed
    console.log("serach log",event)
    let query = event.query;

    this.filteredCenters = this.centers.filter(center => {
      return center.code;
    });
  }

  filters: { [key: string]: { value: string, matchMode: string } } = {};

  onFilterChange(event: Event, fieldName: string): void {
    const input = event.target as HTMLInputElement;
    const value = input?.value || '';
  
    // Apply your filter logic here
    this.tableData = this.applyFilters(this.filteredData, fieldName, value);
  }
  
  
  applyFilters(data: any[], fieldName: string, value: string): any[] {
    return data.filter(item => {
      const fieldValue = item[fieldName]?.toString().toLowerCase() || '';
      return fieldValue.includes(value.toLowerCase());
    });
  }
  
  
}
