import { Component, EventEmitter, Input, Output, ChangeDetectorRef, AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-form-builder',
  templateUrl: './form-builder.component.html',
  styleUrls: ['./form-builder.component.css'],
})
export class FormBuilderComponent  {
  @Input() forms: any;
  @Input() formdata: any;
  @Output() formdataChange: EventEmitter<any> = new EventEmitter<any>();
  // @Input() form: FormGroup;
  @Output() formChange: EventEmitter<any> = new EventEmitter<any>();
  @Output() formValidityChange: EventEmitter<boolean> = new EventEmitter<boolean>();
  Output: any = {};


  constructor(private cdr: ChangeDetectorRef, private utilities: UtiltiesService, private fb: FormBuilder) {
    // this.form = this.fb.group({});

  }
  // ngAfterViewInit() {
  //  // console.log(this.forms);
  //   var tempFbGroup: any = {};
  //   this.forms.elements.array.forEach((element:any) => {
  //   tempFbGroup[element.name] = new FormControl(element.value, element.required ? Validators.required : null);
  //   });
  //   this.form = this.fb.group(tempFbGroup);

  // }


  isValidPhoneNumber(value: string): boolean {
    const pattern = /^[6-9]\d{9}$/;
    return pattern.test(value);
  }
  

  allowOnlyDigits(event: KeyboardEvent): void {
    const allowedKeys = ['Backspace', 'ArrowLeft', 'ArrowRight', 'Tab'];
    if (!/^\d$/.test(event.key) && !allowedKeys.includes(event.key)) {
      event.preventDefault();
    }
  }
  
  onPhoneInput(event: any, id: string): void {
    let value = event.target.value.replace(/\D/g, ''); // remove non-digits
    if (value.length > 10) {
      value = value.slice(0, 10); // limit to 10 digits
    }
    this.formdata[id] = value;
  }
  

  @ViewChild('inputField') inputField: ElementRef | undefined;

  ngAfterViewInit() {
    // Focus on the element if it's available
    if (this.inputField) {
      this.inputField.nativeElement.focus();
    }
  }



}
