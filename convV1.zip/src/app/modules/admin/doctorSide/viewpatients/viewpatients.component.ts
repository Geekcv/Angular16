import { Component, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { AddpatientdialogComponent } from '../../dialog/doctor/addpatientdialog/addpatientdialog.component';
import { MatDialog } from '@angular/material/dialog';
import { DeldialogComponent } from '../../dialog/deldialog/deldialog.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Patient {
 
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name:string;
  user_contact_number:string;
  user_password:string;
  user_row_id:string;
  qualifications_details:string;
  qualifications:string;
  }
   

@Component({
  selector: 'app-viewpatients',
imports: [MatTableModule, MatButtonModule,
  MatIconModule,MatInputModule,MatPaginatorModule,CommonModule,FormsModule],
  templateUrl: './viewpatients.component.html',
  styleUrl:'./viewpatients.component.css'
})
export class ViewpatientsComponent {

  // patient: Patient[] = [];
   
    displayedColumns: string[] = [
      'user_row_id',
      'patient_name',
      'patient_email',
      'user_contact_number',
      // 'patient_gender',

      'qualifications',
      'qualifications_details',      

      'actions'
    ];
  

   role :any ='';

   isSearchActive = false;

    patient = new MatTableDataSource<Patient>([]); // Use MatTableDataSource for pagination

    
      @ViewChild(MatPaginator) paginator!: MatPaginator;

   constructor(
     private Apicontroller: ApicontrollerService,
     private router: Router,
       private _matDialog: MatDialog
   ) { 

    this.role=  localStorage.getItem('role')

  // console.log("my role",this.role)
   }
 
   ngOnInit(): void {
     this.Patients();
   }

   ngAfterViewInit() {
    this.patient.paginator = this.paginator; // Set paginator after view init
  }

   page: number = 1; // Default to first page
   async Patients() {
     try {
       const resp = await this.Apicontroller.fetchPatients('common',this.page);
       console.log("Patients", resp);
       this.patient.data = resp.data as Patient[]; // Type assert to Doctor[]
     } catch (error) {
       console.error("Error fetching doctors:", error);
     }
 
   }
 
 
   viewDoctorDetails(patient: Patient) {
     this.router.navigate(['patientDetails', patient.user_row_id]);
   }




//   filterByQuery(query: string): void {
//     const trimmedQuery = query.trim().toLowerCase();

//     if (trimmedQuery) {
//         this.isSearchActive = true;
//         this.patient.filter = trimmedQuery;

//         if (this.patient.paginator) {
//             this.patient.paginator.firstPage(); // Reset to first page after search
//         }
//     } else {
//         this.isSearchActive = false;
//         this.patient.filter = ''; // Clear filter

//         // Reset the paginator and restore original data
//         setTimeout(() => {
//             this.patient.paginator = this.paginator;
//         });
//     }
// }

  exportToExcel(): void {
      const dataToExport = this.patient.data.map((patient) => ({
        ID: patient.user_row_id,
        Name: patient.patient_name,
        Email: patient.patient_email,
        Gender: patient.patient_gender,
        Contact: patient.user_contact_number,
      }));
  
      const worksheet = XLSX.utils.json_to_sheet(dataToExport);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Doctors');
  
      const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      
      saveAs(data, 'Patients_List.xlsx');
    }


    refresh(){
      console.log("refresh----")
      this.Patients();
      // window.location.reload();
    }
  
    addpatientdialog(){
        const dialogRef = this._matDialog.open(AddpatientdialogComponent);
      }



      deletebtn(patient: Patient){
      console.log("delete click ")
          const dialogRef = this._matDialog.open(DeldialogComponent,{data:{patient:patient}} ) // ,{ data: { doctordata: user_row_id  }}
          // dialogRef.afterClosed().subscribe((result) => {
          //     console.log('dialog was closed!');
          // });
      
          console.log("delete.....")
        }


        viewpatientDetails(patient_rowId: string) {
          console.log("viewdata",patient_rowId)
          // this.router.navigate(['patientDetails', patient_rowId]);
          this.router.navigate(['patientpanel', patient_rowId]);

          
        }


        filterPanelVisible = false; // Track visibility of filter panel
        filterName = '';
        filterEmail = '';
        filterContact = '';
      

        toggleFilterPanel() {
          this.filterPanelVisible = !this.filterPanelVisible;
        }
      
        applyFilter() {
          const filteredData = this.patient.data.filter(patient => 
            (this.filterName ? patient.patient_name.toLowerCase().includes(this.filterName.toLowerCase()) : true) &&
            (this.filterEmail ? patient.patient_email.toLowerCase().includes(this.filterEmail.toLowerCase()) : true) &&
            (this.filterContact ? patient.user_contact_number.includes(this.filterContact) : true)
          );
          this.patient.data = filteredData;
        }
      
        clearFilters() {
          this.filterName = '';
          this.filterEmail = '';
          this.filterContact = '';
          this.Patients(); // Reload original data
        }


        filterByQuery(query: string): void {
          const trimmedQuery = query.trim().toLowerCase();
        
          if (trimmedQuery) {
            this.isSearchActive = true;
            this.patient.filter = trimmedQuery;
        
            if (this.patient.paginator) {
              this.patient.paginator.firstPage(); // Reset to first page after search
            }
          } else {
            this.isSearchActive = false;
            this.patient.filter = ''; // Clear filter
        
            // Reset the paginator and restore original data
            setTimeout(() => {
              this.patient.paginator = this.paginator;
            });
          }
        }
        
      
      
}
