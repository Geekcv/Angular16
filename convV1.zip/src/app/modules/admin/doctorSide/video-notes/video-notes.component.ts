import { Component, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { DeldialogComponent } from '../../dialog/deldialog/deldialog.component';

interface Patient {
 
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name:string;
  user_contact_number:string;
  user_password:string;
  user_row_id:string;
  }
   
  interface mediaMetadata {
    date: string;
    description: string;
    doctor_name:string;
    filename: string;
    filesize: string;
    time: string;
    media_link: string;
    media_type:string;
    patient_name:string;
  }

@Component({
  selector: 'app-video-notes',
  imports: [MatTableModule, MatButtonModule,
    MatIconModule,MatInputModule,MatPaginatorModule],
  templateUrl: './video-notes.component.html',
  styleUrl:'./video-notes.component.css'
})
export class VideoNotesComponent {
  userrowId: any;
  audiomediadata: mediaMetadata[] = [];
   
    displayedColumns: string[] = [
      'filename',
      'description',
      'filesize',
      'date',
      // 'doctor_name',
      'media_type',
       'patient_name',
      'actions'
    ];
  

   role :any ='';

   isSearchActive = false;

    videodata = new MatTableDataSource<mediaMetadata>([]); // Use MatTableDataSource for pagination

    
      @ViewChild(MatPaginator) paginator!: MatPaginator;

   constructor(
     private Apicontroller: ApicontrollerService,
     private router: Router,
       private _matDialog: MatDialog
   ) { 

    this.role=  localStorage.getItem('role')

  // console.log("my role",this.role)
   }
 
   ngOnInit(): void {
     this.FetchVideoMedia();
   }

   ngAfterViewInit() {
    this.videodata.paginator = this.paginator; // Set paginator after view init
  }

   page: number = 1; // Default to first page
   async FetchVideoMedia() {
    try {
     const data = {
       row_id: this.userrowId,
       media_type: 'video/mp4',
     };

     console.log("data",data)
 
      const resp = await this.Apicontroller.fetchmedia(data);
      console.log("audio media", resp);
      this.videodata.data = resp.data as mediaMetadata[]; // Type assert to Doctor[]
    } catch (error) {
      console.error("Error fetching audio media:", error);
    }

  }
 
 
 




  filterByQuery(query: string): void {
    const trimmedQuery = query.trim().toLowerCase();

    if (trimmedQuery) {
        this.isSearchActive = true;
        this.videodata.filter = trimmedQuery;

        if (this.videodata.paginator) {
            this.videodata.paginator.firstPage(); // Reset to first page after search
        }
    } else {
        this.isSearchActive = false;
        this.videodata.filter = ''; // Clear filter

        // Reset the paginator and restore original data
        setTimeout(() => {
            this.videodata.paginator = this.paginator;
        });
    }
}

  exportToExcel(): void {
      const dataToExport = this.videodata.data.map((videodata) => ({
        Filename: videodata.filename,
      Description: videodata.description,
      Filesize: videodata.filesize,
      Mediatype: videodata.media_type,
      PatientName: videodata.patient_name,
      }));
  
      const worksheet = XLSX.utils.json_to_sheet(dataToExport);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Doctors');
  
      const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      
      saveAs(data, 'Patients_List.xlsx');
    }


    refresh(){
      console.log("refresh----")
      this.FetchVideoMedia();
      // window.location.reload();
    }
  
    addpatientdialog(){
        // const dialogRef = this._matDialog.open(AddpatientdialogComponent);
      }



      deletebtn(){
      
          const dialogRef = this._matDialog.open(DeldialogComponent);
          // dialogRef.afterClosed().subscribe((result) => {
          //     console.log('dialog was closed!');
          // });
      
          console.log("delete.....")
        }


        viewVideoDetails(media_row_id: string) {
          console.log("viewdata",media_row_id)
          this.router.navigate(['viewVideodetails', media_row_id]);
          // this.router.navigate(['patientpanel', patient_rowId]);

          
        }
}
