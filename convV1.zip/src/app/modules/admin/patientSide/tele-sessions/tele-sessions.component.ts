import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { provideNativeDateAdapter } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatTimepickerModule } from '@angular/material/timepicker';
import { ActivatedRoute } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

interface appointment {
  apt_row_id: string;
  date_of_apt: string;
  // date_of_req:string;
  doctor_name: string;
  user_contact_number: string;
  time_of_apt: string;
  // time_of_req:string;
  appointment_details: any;
  // appointment_details:{appt_status:any,appt_type:any,virtual_link:any};
  // updatedby_user_name:any
}


interface Patient {
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name: string;
  user_contact_number: string;
  user_password: string;
  row_id: string;
}

@Component({
  selector: 'app-tele-sessions',
  imports: [
    MatButtonModule,
    MatIconModule,
    MatDividerModule,
    FormsModule,
    MatInputModule,
    MatTableModule,
    MatPaginatorModule,
    MatTimepickerModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatFormFieldModule,
    MatSelectModule,
    CommonModule
  ],
  templateUrl: './tele-sessions.component.html',
  // changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [provideNativeDateAdapter()],
})
export class TeleSessionsComponent {
  value: Date;
  patients: Patient[] = [];

  selectedvalue: string;
  app_type: string = '';

  // slot: string = '';
  availableslot: string[] = ['Physical', 'Virtual'];


  isclicked = false;
  isviewbtn = false;

  row_id: any = '';
  toggle = false;

  timevalue:any;
  datevalue:any;

  isAddNewClicked: boolean = false;

  addnewbtn() {
    this.isclicked = true;
    this.isviewbtn = false; // Hide view when adding a new one
    //  this.toggle = true
    this.isAddNewClicked = !this.isAddNewClicked; // Toggle the button color
    this.selectedRow = null;


  }


  exitbtn() {
    this.isclicked = false;
    this.isviewbtn = false;

    this.isAddNewClicked = false;
  }

  selectedRow: any = null;


  viewbtn(appointmentdata: any, e: Event) {
    this.row_id = appointmentdata.apt_row_id;
    this.isviewbtn = true;
    this.isclicked = false; // Hide add new when viewing
    this.selectedRow = appointmentdata;

    this.isAddNewClicked = false;




  }


  patientsId!: string | null; // Holds the patientsId ID from the route
  appointmentdata: appointment[] = [];

  // appointment_details: appointmentDetails[]=[]

  appointmentColumns: string[] = [
    'apt_row_id',
    'date_of_apt',
    // 'date_of_req',
    'doctor_name',
    'user_contact_number',
    'time_of_apt',
    // 'time_of_req',
    'appointment_status',
    'updatedby_user_type',

    'appointment_Type',
    'Action'


  ];

  patientDetails: Patient | null = null;

  constructor(
    private route: ActivatedRoute,
    private apiController: ApicontrollerService,
  ) {
    this.patientsId = this.route.snapshot.paramMap.get('id');
    this.viewappointment();

    const userData = localStorage.getItem('userDeatials');

    this.patientDetails = JSON.parse(userData);
  }

  ngOnInit() {
    // console.log("patientsId",this.patientsId)   
    this.patientsId = this.route.snapshot.paramMap.get('id');
    this.viewappointment();

    const userData = localStorage.getItem('userDeatials');

    this.patientDetails = JSON.parse(userData);

  }








  async viewappointment() {
    const resp1 = await this.apiController.fetchappointment();
    this.appointmentdata = resp1.data || []


    console.log("view patients appointments resp ",resp1)
  }

 async requestAppointment(){
    console.log("time value-",this.timevalue.toTimeString().split(' ')[0], "date value-",this.datevalue.toDateString())

    var data ={
      time_of_apt:this.timevalue.toTimeString().split(' ')[0],
      date_of_apt:this.datevalue.toDateString(),
      appt_type:this.app_type
    }

    const resp = await this.apiController.requestappintment(data);
    console.log("response",resp)
  }

  refresh() {
    console.log("refresh----")
    this.viewappointment();
    // window.location.reload();
  }
}
