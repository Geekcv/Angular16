import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { EditPatientsInfoComponent } from 'app/modules/admin/dialog/edit-patients-info/edit-patients-info.component';
import { SchedulePatientsappointComponent } from 'app/modules/admin/dialog/schedule-patientsappoint/schedule-patientsappoint.component';
import { SuspendPatientComponent } from 'app/modules/admin/dialog/suspend-patient/suspend-patient.component';

interface Patient {
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name: string;
  user_contact_number: string;
  user_password: string;
  row_id: string;
}

interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  doctor_name: string;
  user_contact_number: string;
  user_password: string;
  row_id: string;
}

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [
    MatButtonModule,
    MatIconModule,
    CommonModule,
    MatCardModule,
    FormsModule
  ],
  templateUrl: './profile.component.html',
})
export class ProfileComponent implements OnInit {
  patient: Patient[] = [];
  patientname: string = '';
  patientStatus: string = '';
  patientsId: string | null = null;
  role: number;
  userDetails: Doctor | null = null;
  patientDetails: Patient | null = null;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private apiController: ApicontrollerService,
    private _matDialog: MatDialog
  ) {
    this.patientsId = this.route.snapshot.paramMap.get('id');
    this.role = Number(localStorage.getItem('role')) || 0; // Convert role to a number
    this.loadUserDetails();
    this.refresh();
  }

  ngOnInit() {
    this.patientsId = this.route.snapshot.paramMap.get('id');
    this.fetchSefesficpatients();
    this.fetchSefesficpatientsname();
  }

  /** Load User Details from localStorage */
  private loadUserDetails(): void {
    const userData = localStorage.getItem('userDeatials');
    if (userData) {
      if (this.role === 1) {
        this.userDetails = JSON.parse(userData);
      } else {
        this.patientDetails = JSON.parse(userData);
      }
    }
  }

  async fetchSefesficpatients(): Promise<void> {
    try {
      const response = await this.apiController.fetchSefesficpatients(this.patientsId);
      this.patient = response.data || []; // Ensure `data` exists in the API response
      this.patientStatus = response.data[0]?.active;
    } catch (error) {
      console.error('Error fetching patients:', error);
    }
  }

  async fetchSefesficpatientsname(): Promise<void> {
    try {
      const response = await this.apiController.fetchSefesficpatients(this.patientsId);
      this.patientname = response.data[0]?.patient_name || ''; // Ensure `data` exists in the API response
    } catch (error) {
      console.error('Error fetching patients:', error);
    }
  }

  editProfile(patient: any) {
    const dialogRef = this._matDialog.open(EditPatientsInfoComponent, { data: { patient } });
  }

  suspendPatient(patient: any) {
    const dialogRef = this._matDialog.open(SuspendPatientComponent, { data: { patient } });
  }

  rescheduleAppointment(patient: any) {
    const dialogRef = this._matDialog.open(SchedulePatientsappointComponent, { data: { patient } });
  }

  refresh() {
    this.fetchSefesficpatients();
  }

  goback() {
    this.router.navigate(['/Viewpatients']);
  }
}
