import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { DiagnosisComponent } from 'app/modules/admin/dialog/doctor/video/diagnosis/diagnosis.component';
import { FormulationComponent } from 'app/modules/admin/dialog/doctor/video/formulation/formulation.component';
import { HistoryComponent } from 'app/modules/admin/dialog/doctor/video/history/history.component';
import { RateComponent } from 'app/modules/admin/dialog/doctor/video/rate/rate.component';



interface Patient {
 
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name:string;
  user_contact_number:string;
  user_password:string;
  user_row_id:string;
  }


@Component({
  selector: 'app-telepsychiatry-sessions',
  imports: [
    MatButtonModule,
    MatIconModule,
    MatTableModule, 
    MatInputModule,
    MatPaginatorModule
  ],
  templateUrl: './telepsychiatry-sessions.component.html',
  styleUrl:'./telepsychiatry-sessions.component.css'
})
export class TelepsychiatrySessionsComponent {




  uploadbtn(){
  this.isclicked = true;

  this.isratebtn=false;
  this.isdiagnosisbtn=false;
  this.isformulationbtn=false;
  this.ishistorybtn=false;
  this.isviewchatboxbtn=false;

        // const dialogRef = this._matDialog.open(UploadComponent);

  }


   patient: any;
    patientname: any;
    row_id: any;
  
  isclicked = false;
      
    
  
     constructor(     
            private _matDialog: MatDialog,
                 private Apicontroller: ApicontrollerService,
                  private route: ActivatedRoute,
                         private router: Router,
            
          ) {      
          
          }
  
  
          displayedColumns: string[] = [
            // 'user_row_id',
            'patient_name',
            // 'patient_email',
            // 'user_contact_number',
            // 'patient_gender',    
            
      
            'actions'
          ];
  
  
    patientsId!: string | null; // Holds the patientsId ID from the route
  
    isviewbtn:any = false;
  
  
    isviewchatboxbtn:any =false;
    ishistorybtn:any=false;
    isformulationbtn:any=false
    isdiagnosisbtn:any =false;
  isratebtn:any=false;
  
    selectedRow: any = null;
    selectedAction: string | null = null; // Store selected action separately
    
    viewchatboxbtn(Patient: any) {
      this.selectedRow = Patient;
      this.selectedAction = 'view';
  
      this.isviewchatboxbtn=true;
      this.ishistorybtn=false;
      this.isformulationbtn=false;
      this.isdiagnosisbtn=false;
      this.isratebtn=false;

  this.isclicked = false;

  
      this.row_id= Patient.patient_name
  
  
    }
    
    historybtn(Patient: any) {
      this.selectedRow = Patient;
      this.selectedAction = 'history';
  
      this.ishistorybtn=true;
      this.isviewchatboxbtn=false;
      this.isformulationbtn=false;
      this.isdiagnosisbtn=false;
      this.isratebtn=false;
  
  this.isclicked = false;

      this.row_id= Patient.patient_age
  
  
    }
    
    formulationbtn(Patient: any) {
      this.selectedRow = Patient;
      this.selectedAction = 'formulation';
      
      this.isformulationbtn=true;
      this.ishistorybtn=false;
      this.isviewchatboxbtn=false;
      this.isdiagnosisbtn=false;
      this.isratebtn=false;
  this.isclicked = false;

  
      this.row_id= Patient.patient_gender
  
  
    }
    
    diagnosisbtn(Patient: any) {
      this.selectedRow = Patient;
      this.selectedAction = 'diagnosis';
  
      this.isdiagnosisbtn=true;
      this.isformulationbtn=false;
      this.ishistorybtn=false;
      this.isviewchatboxbtn=false;
      this.isratebtn=false;
  this.isclicked = false;

  
      this.row_id= Patient.user_contact_number
    }
    
    ratebtn(Patient: any) {
      this.selectedRow = Patient;
      this.selectedAction = 'rate';
  
      this.isratebtn=true;
      this.isdiagnosisbtn=false;
      this.isformulationbtn=false;
      this.ishistorybtn=false;
      this.isviewchatboxbtn=false;
  this.isclicked = false;

  
      this.row_id= Patient.user_row_id
    }
    
  
  
  
      ngOnInit(): void {
        this.Patients();
  
        this.patientsId = this.route.snapshot.paramMap.get('id');
        // console.log("patientsId",this.patientsId)
    
        this.fetchSefesficpatients();  
      }
  
  
      async fetchSefesficpatients(): Promise<void> {
        try {
          const response = await this.Apicontroller.fetchSefesficpatients(this.patientsId);
          this.patientname = response.data[0].patient_name || []; // Ensure `data` exists in the API response
          console.log("patient----",response.data[0].patient_name)
  
        } catch (error) {
          // console.error('Error fetching clients:', error);
        }
      }
  
      page: number = 1; // Default to first page
      async Patients() {
        try {
          const resp = await this.Apicontroller.fetchPatients('common',this.page);
         //  console.log("Patients", resp);
          this.patient = resp.data as Patient[]; // Type assert to Doctor[]
        } catch (error) {
          console.error("Error fetching doctors:", error);
        }
    
      }
  
  
  
      viewchatsdialogboxbtn(){
        //  const dialogRef = this._matDialog.open(ViewChatComponent,{data: {patient:  this.row_id}});
      }
  
      historychatsdialogboxbtn(){
        const dialogRef = this._matDialog.open(HistoryComponent,{data: {patient:  this.row_id}});
  
      }
  
      formulationdialogboxbtn(){
        const dialogRef = this._matDialog.open(FormulationComponent,{data: {patient:  this.row_id}});
  
      }
  
      diagnosisdialogboxbtn(){
        const dialogRef = this._matDialog.open(DiagnosisComponent,{data: {patient:  this.row_id}});
  
      }
  
      ratedialogboxbtn(){
        const dialogRef = this._matDialog.open(RateComponent,{data: {patient:  this.row_id}});
  
      }
      goback(){
        // console.log("click this button")
        this.router.navigate(['/Viewpatients'])
      }
}
