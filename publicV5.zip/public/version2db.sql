--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8
-- Dumped by pg_dump version 16.8

-- Started on 2025-04-27 17:11:07

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS shikshanboard;
--
-- TOC entry 5024 (class 1262 OID 417894)
-- Name: shikshanboard; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE shikshanboard WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_India.1252';


ALTER DATABASE shikshanboard OWNER TO postgres;

\connect shikshanboard

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 6 (class 2615 OID 417895)
-- Name: sb; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA sb;


ALTER SCHEMA sb OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 216 (class 1259 OID 417896)
-- Name: attendance; Type: TABLE; Schema: sb; Owner: postgres
--

CREATE TABLE sb.attendance (
    id integer NOT NULL,
    row_id text NOT NULL,
    student_row_id text,
    exam_session text,
    class text,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    status integer,
    center_code integer
);


ALTER TABLE sb.attendance OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 417903)
-- Name: attendance_id_seq; Type: SEQUENCE; Schema: sb; Owner: postgres
--

CREATE SEQUENCE sb.attendance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE sb.attendance_id_seq OWNER TO postgres;

--
-- TOC entry 5025 (class 0 OID 0)
-- Dependencies: 217
-- Name: attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: sb; Owner: postgres
--

ALTER SEQUENCE sb.attendance_id_seq OWNED BY sb.attendance.id;


--
-- TOC entry 218 (class 1259 OID 417904)
-- Name: bandals; Type: TABLE; Schema: sb; Owner: postgres
--

CREATE TABLE sb.bandals (
    id integer NOT NULL,
    row_id text NOT NULL,
    bandal_no integer NOT NULL,
    exam_session text,
    class text,
    copy_checker_id text,
    student_row_id text,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE sb.bandals OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 417911)
-- Name: bandals_id_seq; Type: SEQUENCE; Schema: sb; Owner: postgres
--

CREATE SEQUENCE sb.bandals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE sb.bandals_id_seq OWNER TO postgres;

--
-- TOC entry 5026 (class 0 OID 0)
-- Dependencies: 219
-- Name: bandals_id_seq; Type: SEQUENCE OWNED BY; Schema: sb; Owner: postgres
--

ALTER SEQUENCE sb.bandals_id_seq OWNED BY sb.bandals.id;


--
-- TOC entry 220 (class 1259 OID 417912)
-- Name: branch; Type: TABLE; Schema: sb; Owner: postgres
--

CREATE TABLE sb.branch (
    id integer NOT NULL,
    row_id text NOT NULL,
    branch_name text,
    branch_head_name text,
    address text,
    city integer,
    mobile_no text,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE sb.branch OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 417919)
-- Name: branch_id_seq; Type: SEQUENCE; Schema: sb; Owner: postgres
--

CREATE SEQUENCE sb.branch_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE sb.branch_id_seq OWNER TO postgres;

--
-- TOC entry 5027 (class 0 OID 0)
-- Dependencies: 221
-- Name: branch_id_seq; Type: SEQUENCE OWNED BY; Schema: sb; Owner: postgres
--

ALTER SEQUENCE sb.branch_id_seq OWNED BY sb.branch.id;


--
-- TOC entry 222 (class 1259 OID 417920)
-- Name: centers; Type: TABLE; Schema: sb; Owner: postgres
--

CREATE TABLE sb.centers (
    id integer NOT NULL,
    row_id text NOT NULL,
    branch_id text,
    center text NOT NULL,
    center_head_name text,
    email text,
    address text,
    date_of_birth date,
    state integer,
    city integer,
    std_code text,
    phone_no text,
    mobile_no text,
    account_no text,
    account_name text,
    bank_name text,
    branch_name text,
    ifsc_code text,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    center_code integer,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE sb.centers OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 417927)
-- Name: centers_id_seq; Type: SEQUENCE; Schema: sb; Owner: postgres
--

CREATE SEQUENCE sb.centers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE sb.centers_id_seq OWNER TO postgres;

--
-- TOC entry 5028 (class 0 OID 0)
-- Dependencies: 223
-- Name: centers_id_seq; Type: SEQUENCE OWNED BY; Schema: sb; Owner: postgres
--

ALTER SEQUENCE sb.centers_id_seq OWNED BY sb.centers.id;


--
-- TOC entry 224 (class 1259 OID 417928)
-- Name: classes; Type: TABLE; Schema: sb; Owner: postgres
--

CREATE TABLE sb.classes (
    id integer NOT NULL,
    row_id text NOT NULL,
    faculty integer,
    class_name text NOT NULL,
    first_price real,
    second_price real,
    third_price real,
    merit_list_upto_10_price real,
    marks_greater_equal_to_90 real,
    marks_70_to_less_then_90 real,
    marks_50_to_less_then_70 real,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE sb.classes OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 417935)
-- Name: classes_id_seq; Type: SEQUENCE; Schema: sb; Owner: postgres
--

CREATE SEQUENCE sb.classes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE sb.classes_id_seq OWNER TO postgres;

--
-- TOC entry 5029 (class 0 OID 0)
-- Dependencies: 225
-- Name: classes_id_seq; Type: SEQUENCE OWNED BY; Schema: sb; Owner: postgres
--

ALTER SEQUENCE sb.classes_id_seq OWNED BY sb.classes.id;


--
-- TOC entry 226 (class 1259 OID 417936)
-- Name: copy_checkers; Type: TABLE; Schema: sb; Owner: postgres
--

CREATE TABLE sb.copy_checkers (
    id integer NOT NULL,
    row_id text NOT NULL,
    name text,
    address text,
    mobile text,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE sb.copy_checkers OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 417943)
-- Name: copy_checkers_id_seq; Type: SEQUENCE; Schema: sb; Owner: postgres
--

CREATE SEQUENCE sb.copy_checkers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE sb.copy_checkers_id_seq OWNER TO postgres;

--
-- TOC entry 5030 (class 0 OID 0)
-- Dependencies: 227
-- Name: copy_checkers_id_seq; Type: SEQUENCE OWNED BY; Schema: sb; Owner: postgres
--

ALTER SEQUENCE sb.copy_checkers_id_seq OWNED BY sb.copy_checkers.id;


--
-- TOC entry 228 (class 1259 OID 417944)
-- Name: exam_sessions; Type: TABLE; Schema: sb; Owner: postgres
--

CREATE TABLE sb.exam_sessions (
    id integer NOT NULL,
    row_id text NOT NULL,
    session_name text,
    exam_date date,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE sb.exam_sessions OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 417951)
-- Name: exam_sessions_id_seq; Type: SEQUENCE; Schema: sb; Owner: postgres
--

CREATE SEQUENCE sb.exam_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE sb.exam_sessions_id_seq OWNER TO postgres;

--
-- TOC entry 5031 (class 0 OID 0)
-- Dependencies: 229
-- Name: exam_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: sb; Owner: postgres
--

ALTER SEQUENCE sb.exam_sessions_id_seq OWNED BY sb.exam_sessions.id;


--
-- TOC entry 230 (class 1259 OID 417952)
-- Name: marks; Type: TABLE; Schema: sb; Owner: postgres
--

CREATE TABLE sb.marks (
    id integer NOT NULL,
    row_id text NOT NULL,
    student_row_id text,
    exam_session text,
    copy_checker_id text,
    marks integer,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE sb.marks OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 417959)
-- Name: marks_id_seq; Type: SEQUENCE; Schema: sb; Owner: postgres
--

CREATE SEQUENCE sb.marks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE sb.marks_id_seq OWNER TO postgres;

--
-- TOC entry 5032 (class 0 OID 0)
-- Dependencies: 231
-- Name: marks_id_seq; Type: SEQUENCE OWNED BY; Schema: sb; Owner: postgres
--

ALTER SEQUENCE sb.marks_id_seq OWNED BY sb.marks.id;


--
-- TOC entry 232 (class 1259 OID 417960)
-- Name: merit_list; Type: TABLE; Schema: sb; Owner: postgres
--

CREATE TABLE sb.merit_list (
    id integer NOT NULL,
    row_id text NOT NULL,
    student_row_id text,
    marks integer,
    rank integer,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE sb.merit_list OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 417967)
-- Name: merit_list_id_seq; Type: SEQUENCE; Schema: sb; Owner: postgres
--

CREATE SEQUENCE sb.merit_list_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE sb.merit_list_id_seq OWNER TO postgres;

--
-- TOC entry 5033 (class 0 OID 0)
-- Dependencies: 233
-- Name: merit_list_id_seq; Type: SEQUENCE OWNED BY; Schema: sb; Owner: postgres
--

ALTER SEQUENCE sb.merit_list_id_seq OWNED BY sb.merit_list.id;


--
-- TOC entry 234 (class 1259 OID 417968)
-- Name: online_forms; Type: TABLE; Schema: sb; Owner: postgres
--

CREATE TABLE sb.online_forms (
    id integer NOT NULL,
    row_id text NOT NULL,
    student_row_id text,
    form_name text,
    form_data jsonb,
    status text,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE sb.online_forms OWNER TO postgres;

--
-- TOC entry 235 (class 1259 OID 417975)
-- Name: online_forms_id_seq; Type: SEQUENCE; Schema: sb; Owner: postgres
--

CREATE SEQUENCE sb.online_forms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE sb.online_forms_id_seq OWNER TO postgres;

--
-- TOC entry 5034 (class 0 OID 0)
-- Dependencies: 235
-- Name: online_forms_id_seq; Type: SEQUENCE OWNED BY; Schema: sb; Owner: postgres
--

ALTER SEQUENCE sb.online_forms_id_seq OWNED BY sb.online_forms.id;


--
-- TOC entry 241 (class 1259 OID 426270)
-- Name: samplebook; Type: TABLE; Schema: sb; Owner: postgres
--

CREATE TABLE sb.samplebook (
    id integer NOT NULL,
    row_id text NOT NULL,
    title text,
    photo_path text,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE sb.samplebook OWNER TO postgres;

--
-- TOC entry 240 (class 1259 OID 426269)
-- Name: samplebook_id_seq; Type: SEQUENCE; Schema: sb; Owner: postgres
--

CREATE SEQUENCE sb.samplebook_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE sb.samplebook_id_seq OWNER TO postgres;

--
-- TOC entry 5035 (class 0 OID 0)
-- Dependencies: 240
-- Name: samplebook_id_seq; Type: SEQUENCE OWNED BY; Schema: sb; Owner: postgres
--

ALTER SEQUENCE sb.samplebook_id_seq OWNED BY sb.samplebook.id;


--
-- TOC entry 243 (class 1259 OID 426283)
-- Name: samplepaper; Type: TABLE; Schema: sb; Owner: postgres
--

CREATE TABLE sb.samplepaper (
    id integer NOT NULL,
    row_id text NOT NULL,
    class_id text,
    title text,
    photo_path text,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE sb.samplepaper OWNER TO postgres;

--
-- TOC entry 242 (class 1259 OID 426282)
-- Name: samplepaper_id_seq; Type: SEQUENCE; Schema: sb; Owner: postgres
--

CREATE SEQUENCE sb.samplepaper_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE sb.samplepaper_id_seq OWNER TO postgres;

--
-- TOC entry 5036 (class 0 OID 0)
-- Dependencies: 242
-- Name: samplepaper_id_seq; Type: SEQUENCE OWNED BY; Schema: sb; Owner: postgres
--

ALTER SEQUENCE sb.samplepaper_id_seq OWNED BY sb.samplepaper.id;


--
-- TOC entry 236 (class 1259 OID 417976)
-- Name: students; Type: TABLE; Schema: sb; Owner: postgres
--

CREATE TABLE sb.students (
    id integer NOT NULL,
    row_id text NOT NULL,
    student_name text NOT NULL,
    father_name text NOT NULL,
    dob date,
    mobile_no text,
    address text,
    zip_code text,
    ahhar_no text,
    phone_r text,
    phone_o text,
    medium text,
    education text,
    account_no text,
    account_name text,
    bank_name text,
    branch_name text,
    ifsc_code text,
    remarks text,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL,
    gender text,
    state integer,
    city integer,
    exam_sessions text,
    class_id text,
    center integer,
    roll_no integer,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE sb.students OWNER TO postgres;

--
-- TOC entry 237 (class 1259 OID 417983)
-- Name: students_id_seq; Type: SEQUENCE; Schema: sb; Owner: postgres
--

CREATE SEQUENCE sb.students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE sb.students_id_seq OWNER TO postgres;

--
-- TOC entry 5037 (class 0 OID 0)
-- Dependencies: 237
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: sb; Owner: postgres
--

ALTER SEQUENCE sb.students_id_seq OWNED BY sb.students.id;


--
-- TOC entry 238 (class 1259 OID 417984)
-- Name: users; Type: TABLE; Schema: sb; Owner: postgres
--

CREATE TABLE sb.users (
    id integer NOT NULL,
    row_id text NOT NULL,
    user_name text NOT NULL,
    user_password text NOT NULL,
    cr_on timestamp without time zone DEFAULT now() NOT NULL,
    up_on timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE sb.users OWNER TO postgres;

--
-- TOC entry 239 (class 1259 OID 417991)
-- Name: users_id_seq; Type: SEQUENCE; Schema: sb; Owner: postgres
--

CREATE SEQUENCE sb.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE sb.users_id_seq OWNER TO postgres;

--
-- TOC entry 5038 (class 0 OID 0)
-- Dependencies: 239
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: sb; Owner: postgres
--

ALTER SEQUENCE sb.users_id_seq OWNED BY sb.users.id;


--
-- TOC entry 4754 (class 2604 OID 417992)
-- Name: attendance id; Type: DEFAULT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.attendance ALTER COLUMN id SET DEFAULT nextval('sb.attendance_id_seq'::regclass);


--
-- TOC entry 4757 (class 2604 OID 417993)
-- Name: bandals id; Type: DEFAULT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.bandals ALTER COLUMN id SET DEFAULT nextval('sb.bandals_id_seq'::regclass);


--
-- TOC entry 4760 (class 2604 OID 417994)
-- Name: branch id; Type: DEFAULT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.branch ALTER COLUMN id SET DEFAULT nextval('sb.branch_id_seq'::regclass);


--
-- TOC entry 4765 (class 2604 OID 417995)
-- Name: centers id; Type: DEFAULT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.centers ALTER COLUMN id SET DEFAULT nextval('sb.centers_id_seq'::regclass);


--
-- TOC entry 4770 (class 2604 OID 417996)
-- Name: classes id; Type: DEFAULT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.classes ALTER COLUMN id SET DEFAULT nextval('sb.classes_id_seq'::regclass);


--
-- TOC entry 4775 (class 2604 OID 417997)
-- Name: copy_checkers id; Type: DEFAULT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.copy_checkers ALTER COLUMN id SET DEFAULT nextval('sb.copy_checkers_id_seq'::regclass);


--
-- TOC entry 4780 (class 2604 OID 417998)
-- Name: exam_sessions id; Type: DEFAULT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.exam_sessions ALTER COLUMN id SET DEFAULT nextval('sb.exam_sessions_id_seq'::regclass);


--
-- TOC entry 4785 (class 2604 OID 417999)
-- Name: marks id; Type: DEFAULT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.marks ALTER COLUMN id SET DEFAULT nextval('sb.marks_id_seq'::regclass);


--
-- TOC entry 4788 (class 2604 OID 418000)
-- Name: merit_list id; Type: DEFAULT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.merit_list ALTER COLUMN id SET DEFAULT nextval('sb.merit_list_id_seq'::regclass);


--
-- TOC entry 4791 (class 2604 OID 418001)
-- Name: online_forms id; Type: DEFAULT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.online_forms ALTER COLUMN id SET DEFAULT nextval('sb.online_forms_id_seq'::regclass);


--
-- TOC entry 4802 (class 2604 OID 426273)
-- Name: samplebook id; Type: DEFAULT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.samplebook ALTER COLUMN id SET DEFAULT nextval('sb.samplebook_id_seq'::regclass);


--
-- TOC entry 4807 (class 2604 OID 426286)
-- Name: samplepaper id; Type: DEFAULT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.samplepaper ALTER COLUMN id SET DEFAULT nextval('sb.samplepaper_id_seq'::regclass);


--
-- TOC entry 4794 (class 2604 OID 418002)
-- Name: students id; Type: DEFAULT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.students ALTER COLUMN id SET DEFAULT nextval('sb.students_id_seq'::regclass);


--
-- TOC entry 4799 (class 2604 OID 418003)
-- Name: users id; Type: DEFAULT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.users ALTER COLUMN id SET DEFAULT nextval('sb.users_id_seq'::regclass);


--
-- TOC entry 4991 (class 0 OID 417896)
-- Dependencies: 216
-- Data for Name: attendance; Type: TABLE DATA; Schema: sb; Owner: postgres
--

INSERT INTO sb.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code) VALUES (20, '1745648188148_rKfJ', '1745647456823_SSj4', '1745644843887_zvs8', '1745645191576_m05v', '2025-04-26 11:46:28.132935', '2025-04-26 11:46:28.132935', 2, 8723) ON CONFLICT DO NOTHING;
INSERT INTO sb.attendance (id, row_id, student_row_id, exam_session, class, cr_on, up_on, status, center_code) VALUES (19, '1745648128343_Ds8d', '1745647253445_ABkz', '1745644843887_zvs8', '1745645191576_m05v', '2025-04-26 11:45:28.316599', '2025-04-26 11:45:28.316599', 2, 8723) ON CONFLICT DO NOTHING;


--
-- TOC entry 4993 (class 0 OID 417904)
-- Dependencies: 218
-- Data for Name: bandals; Type: TABLE DATA; Schema: sb; Owner: postgres
--

INSERT INTO sb.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on) VALUES (32, '1745648568326_OaWc', 500, '1745644843887_zvs8', '1745645191576_m05v', '1745647804441_8XIq', '1745647253445_ABkz', '2025-04-26 11:52:48.328664', '2025-04-26 11:52:48.328664') ON CONFLICT DO NOTHING;
INSERT INTO sb.bandals (id, row_id, bandal_no, exam_session, class, copy_checker_id, student_row_id, cr_on, up_on) VALUES (33, '1745648568341_J0uI', 500, '1745644843887_zvs8', '1745645191576_m05v', '1745647804441_8XIq', '1745647456823_SSj4', '2025-04-26 11:52:48.343093', '2025-04-26 11:52:48.343093') ON CONFLICT DO NOTHING;


--
-- TOC entry 4995 (class 0 OID 417912)
-- Dependencies: 220
-- Data for Name: branch; Type: TABLE DATA; Schema: sb; Owner: postgres
--

INSERT INTO sb.branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted) VALUES (2, '1745645617371_YEuX', 'North Branch', 'Mr. Suresh Patil', 'MG Road, Pune', 1, '9876543210', '2025-04-26 11:03:37.455095', '2025-04-26 11:03:37.455095', true, false) ON CONFLICT DO NOTHING;
INSERT INTO sb.branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted) VALUES (3, '1745645699092_5fga', 'South Branch', 'Mr. Anjali Desai', 'Anna Nagar, Chennai', 2, '9765432109', '2025-04-26 11:04:59.180955', '2025-04-26 11:04:59.180955', true, false) ON CONFLICT DO NOTHING;
INSERT INTO sb.branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted) VALUES (4, '1745645759329_TaDl', 'East Branch', 'Mr. Ravi Sharma', 'Salt Lake, Kolkata', 3, '9123456780', '2025-04-26 11:06:01.460727', '2025-04-26 11:06:01.460727', true, false) ON CONFLICT DO NOTHING;
INSERT INTO sb.branch (id, row_id, branch_name, branch_head_name, address, city, mobile_no, cr_on, up_on, is_active, is_deleted) VALUES (5, '1745680258703_Bsg9', 'string500', 'string_head_name600', 'stringaddrdss700', 5, '777678901234', '2025-04-26 20:41:00.920147', '2025-04-26 15:41:03.597', true, false) ON CONFLICT DO NOTHING;


--
-- TOC entry 4997 (class 0 OID 417920)
-- Dependencies: 222
-- Data for Name: centers; Type: TABLE DATA; Schema: sb; Owner: postgres
--

INSERT INTO sb.centers (id, row_id, branch_id, center, center_head_name, email, address, date_of_birth, state, city, std_code, phone_no, mobile_no, account_no, account_name, bank_name, branch_name, ifsc_code, cr_on, up_on, center_code, is_active, is_deleted) VALUES (9, '1745646575983_1SdF', '1745645617371_YEuX', 'PuneCenter', 'Mr. Vinod Kale', 'pune.center@example.com', 'Shivaji Nagar, Pune', '1980-05-15', 21, 1, '020', '24345678', '9876543211', '123456789012', 'Vinod Kale', 'SBI', 'Shivaji Nagar', 'SBIN0000456', '2025-04-26 11:19:36.061005', '2025-04-26 11:19:36.061005', 8723, true, false) ON CONFLICT DO NOTHING;
INSERT INTO sb.centers (id, row_id, branch_id, center, center_head_name, email, address, date_of_birth, state, city, std_code, phone_no, mobile_no, account_no, account_name, bank_name, branch_name, ifsc_code, cr_on, up_on, center_code, is_active, is_deleted) VALUES (10, '1745646873325_JX3Z', '1745645699092_5fga', 'Chennai Center', 'Ms. Kavya Nair', 'chennai.center@example.com', 'T. Nagar, Chennai', '1975-11-23', 33, 2, '044', '27451234', '9765432198', '234567890123', 'Kavya Nair', 'ICICI', 'T Nagar Branch', 'ICIC0000123', '2025-04-26 11:24:35.604467', '2025-04-26 11:24:35.604467', 1050, true, false) ON CONFLICT DO NOTHING;
INSERT INTO sb.centers (id, row_id, branch_id, center, center_head_name, email, address, date_of_birth, state, city, std_code, phone_no, mobile_no, account_no, account_name, bank_name, branch_name, ifsc_code, cr_on, up_on, center_code, is_active, is_deleted) VALUES (11, '1745684143944_cDLr', '1745645699092_5fga', 'string600', 'string100', 'string200', 'string300', '2002-12-08', 3, 4, 'string500', 'string600', 'string700', 'string', 'string', 'string', 'string', 'string', '2025-04-26 21:45:44.124715', '2025-04-26 16:16:59.403', 841, true, false) ON CONFLICT DO NOTHING;


--
-- TOC entry 4999 (class 0 OID 417928)
-- Dependencies: 224
-- Data for Name: classes; Type: TABLE DATA; Schema: sb; Owner: postgres
--

INSERT INTO sb.classes (id, row_id, faculty, class_name, first_price, second_price, third_price, merit_list_upto_10_price, marks_greater_equal_to_90, marks_70_to_less_then_90, marks_50_to_less_then_70, cr_on, up_on, is_active, is_deleted) VALUES (3, '1745645191576_m05v', 1, 'Class 10', 1000, 800, 600, 500, 450, 300, 150, '2025-04-26 10:56:33.829915', '2025-04-26 10:56:33.829915', true, false) ON CONFLICT DO NOTHING;
INSERT INTO sb.classes (id, row_id, faculty, class_name, first_price, second_price, third_price, merit_list_upto_10_price, marks_greater_equal_to_90, marks_70_to_less_then_90, marks_50_to_less_then_70, cr_on, up_on, is_active, is_deleted) VALUES (4, '1745645297097_J8n0', 1, 'Class 12', 1200, 1000, 800, 600, 350, 200, 150, '2025-04-26 10:58:17.188141', '2025-04-26 10:58:17.188141', true, false) ON CONFLICT DO NOTHING;
INSERT INTO sb.classes (id, row_id, faculty, class_name, first_price, second_price, third_price, merit_list_upto_10_price, marks_greater_equal_to_90, marks_70_to_less_then_90, marks_50_to_less_then_70, cr_on, up_on, is_active, is_deleted) VALUES (5, '1745645378912_vbQE', 2, 'Class 11', 1100, 1000, 700, 600, 250, 100, 50, '2025-04-26 10:59:38.994581', '2025-04-26 10:59:38.994581', true, false) ON CONFLICT DO NOTHING;
INSERT INTO sb.classes (id, row_id, faculty, class_name, first_price, second_price, third_price, merit_list_upto_10_price, marks_greater_equal_to_90, marks_70_to_less_then_90, marks_50_to_less_then_70, cr_on, up_on, is_active, is_deleted) VALUES (6, '1745717946199_9Jv1', 6, 'bca', 17000, 5000, 4000, 3000, 2000, 1000, 500, '2025-04-27 07:09:08.405153', '2025-04-27 01:59:40.941', true, false) ON CONFLICT DO NOTHING;


--
-- TOC entry 5001 (class 0 OID 417936)
-- Dependencies: 226
-- Data for Name: copy_checkers; Type: TABLE DATA; Schema: sb; Owner: postgres
--

INSERT INTO sb.copy_checkers (id, row_id, name, address, mobile, cr_on, up_on, is_active, is_deleted) VALUES (3, '1745647804441_8XIq', 'Mr. Verma', 'jodhpur', '9876543210', '2025-04-26 11:40:04.600267', '2025-04-26 11:40:04.600267', true, false) ON CONFLICT DO NOTHING;
INSERT INTO sb.copy_checkers (id, row_id, name, address, mobile, cr_on, up_on, is_active, is_deleted) VALUES (4, '1745647849559_ndhC', 'Ms. Rani', 'kota', '9123456789', '2025-04-26 11:40:51.704451', '2025-04-26 11:40:51.704451', true, false) ON CONFLICT DO NOTHING;


--
-- TOC entry 5003 (class 0 OID 417944)
-- Dependencies: 228
-- Data for Name: exam_sessions; Type: TABLE DATA; Schema: sb; Owner: postgres
--

INSERT INTO sb.exam_sessions (id, row_id, session_name, exam_date, cr_on, up_on, is_active, is_deleted) VALUES (3, '1745644843887_zvs8', 'March 2025', '2025-03-15', '2025-04-26 10:50:47.720402', '2025-04-26 10:50:47.720402', true, false) ON CONFLICT DO NOTHING;
INSERT INTO sb.exam_sessions (id, row_id, session_name, exam_date, cr_on, up_on, is_active, is_deleted) VALUES (4, '1745644905256_vAqG', 'July 2025', '2025-07-20', '2025-04-26 10:51:45.41272', '2025-04-26 10:51:45.41272', true, false) ON CONFLICT DO NOTHING;
INSERT INTO sb.exam_sessions (id, row_id, session_name, exam_date, cr_on, up_on, is_active, is_deleted) VALUES (5, '1745719598041_hOId', 'april hello 2025', '2002-08-12', '2025-04-27 07:36:38.284586', '2025-04-27 02:08:58.777', true, false) ON CONFLICT DO NOTHING;


--
-- TOC entry 5005 (class 0 OID 417952)
-- Dependencies: 230
-- Data for Name: marks; Type: TABLE DATA; Schema: sb; Owner: postgres
--

INSERT INTO sb.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on) VALUES (30, '1745658166838_oAum', '1745647253445_ABkz', '1745644843887_zvs8', '1745647804441_8XIq', 40, '2025-04-26 14:32:50.29407', '2025-04-26 14:32:50.29407') ON CONFLICT DO NOTHING;
INSERT INTO sb.marks (id, row_id, student_row_id, exam_session, copy_checker_id, marks, cr_on, up_on) VALUES (31, '1745659628401_YjYz', '1745647456823_SSj4', '1745644843887_zvs8', '1745647804441_8XIq', 90, '2025-04-26 14:57:08.582801', '2025-04-26 14:57:08.582801') ON CONFLICT DO NOTHING;


--
-- TOC entry 5007 (class 0 OID 417960)
-- Dependencies: 232
-- Data for Name: merit_list; Type: TABLE DATA; Schema: sb; Owner: postgres
--



--
-- TOC entry 5009 (class 0 OID 417968)
-- Dependencies: 234
-- Data for Name: online_forms; Type: TABLE DATA; Schema: sb; Owner: postgres
--



--
-- TOC entry 5016 (class 0 OID 426270)
-- Dependencies: 241
-- Data for Name: samplebook; Type: TABLE DATA; Schema: sb; Owner: postgres
--

INSERT INTO sb.samplebook (id, row_id, title, photo_path, cr_on, up_on, is_active, is_deleted) VALUES (1, '1745724277951_vpk4', 'new photo 1', 'uploads/application/1745724338812_Screenshot 2023-07-10 102532.png', '2025-04-27 03:24:37.953', '2025-04-27 03:26:22.402', true, false) ON CONFLICT DO NOTHING;


--
-- TOC entry 5018 (class 0 OID 426283)
-- Dependencies: 243
-- Data for Name: samplepaper; Type: TABLE DATA; Schema: sb; Owner: postgres
--

INSERT INTO sb.samplepaper (id, row_id, class_id, title, photo_path, cr_on, up_on, is_active, is_deleted) VALUES (1, '1745725150678_BcxS', '1745645378912_vbQE', 'screen shot', 'uploads/application/1745725109546_Screenshot 2023-07-14 105021.png', '2025-04-27 03:39:10.678', '2025-04-27 03:39:10.679', true, false) ON CONFLICT DO NOTHING;


--
-- TOC entry 5011 (class 0 OID 417976)
-- Dependencies: 236
-- Data for Name: students; Type: TABLE DATA; Schema: sb; Owner: postgres
--

INSERT INTO sb.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, center, roll_no, is_active, is_deleted) VALUES (21, '1745647552912_ws82', 'Rohit Das', 'Anil Das', '2004-12-20', '0117654321', 'Ellisbridge, Ahmedabad', '110092', '123456789012', '0111234567', '0117654321', 'English', '10th', '234567890123', 'Rohit Das', 'HDFC', 'Navrangpura', 'ICIC0000456', 'Good student', '2025-04-26 11:35:53.087899', '2025-04-26 11:35:53.087899', 'Male', 19, 103, NULL, NULL, NULL, 1002, true, false) ON CONFLICT DO NOTHING;
INSERT INTO sb.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, center, roll_no, is_active, is_deleted) VALUES (20, '1745647456823_SSj4', 'Sneha Patel', 'Mahesh Patel', '2006-04-12', '0117654321', 'Ellisbridge, Ahmedabad', '110092', '123456789012', '0111234567', '0117654321', 'Gujarati', '10th', '234567890123', 'Sneha Patel', 'ICICI', 'Navrangpura', 'ICIC0000456', 'Good student', '2025-04-26 11:34:17.005365', '2025-04-26 11:34:17.005365', 'Female', 24, 102, '1745644843887_zvs8', '1745645191576_m05v', 8723, 1001, true, false) ON CONFLICT DO NOTHING;
INSERT INTO sb.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, center, roll_no, is_active, is_deleted) VALUES (19, '1745647253445_ABkz', 'Amit Sharma', 'Rajesh Sharma', '2005-06-15', '9876543210', 'Laxmi Nagar, Delhi', '110092', '123456789012', '0111234567', '0117654321', 'English', '10th', '123456789012', 'Amit Sharma', 'SBI', 'Laxmi Nagar', 'SBIN0000123', 'Good student', '2025-04-26 11:30:53.615506', '2025-04-26 11:30:53.615506', 'Male', 9, 101, '1745644843887_zvs8', '1745645191576_m05v', 8723, 1000, true, false) ON CONFLICT DO NOTHING;
INSERT INTO sb.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, center, roll_no, is_active, is_deleted) VALUES (22, '1745647641972_zgPu', 'Priya Nair', 'Suresh Nair', '2004-10-20', '0117654321', 'Ellisbridge, Ahmedabad', '110092', '123456789012', '0111234567', '0117654321', 'English', '10th', '234567890123', 'Priya Nair', 'Axis Bank', 'Navrangpura', 'ICIC0000456', 'Good student', '2025-04-26 11:37:22.160655', '2025-04-26 11:37:22.160655', 'Female', 33, 104, NULL, NULL, NULL, 1003, true, false) ON CONFLICT DO NOTHING;
INSERT INTO sb.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, center, roll_no, is_active, is_deleted) VALUES (23, '1745747885485_BwdT', 'rohan123', 'string', '2002-03-12', '7890345678', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', '2025-04-27 15:28:07.755191', '2025-04-27 15:28:07.755191', 'male', 1, 22, NULL, NULL, NULL, 1004, true, false) ON CONFLICT DO NOTHING;
INSERT INTO sb.students (id, row_id, student_name, father_name, dob, mobile_no, address, zip_code, ahhar_no, phone_r, phone_o, medium, education, account_no, account_name, bank_name, branch_name, ifsc_code, remarks, cr_on, up_on, gender, state, city, exam_sessions, class_id, center, roll_no, is_active, is_deleted) VALUES (24, '1745747982697_V3wz', 'rohan8000', 'string', '2002-03-12', '7890345678', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', '2025-04-27 15:29:42.885725', '2025-04-27 10:00:52.872', 'male', 2, 22, NULL, NULL, NULL, 1005, true, false) ON CONFLICT DO NOTHING;


--
-- TOC entry 5013 (class 0 OID 417984)
-- Dependencies: 238
-- Data for Name: users; Type: TABLE DATA; Schema: sb; Owner: postgres
--

INSERT INTO sb.users (id, row_id, user_name, user_password, cr_on, up_on) VALUES (2, '1745746793263_tFfH', 'rahul', 'rahul123', '2025-04-27 15:09:53.466531', '2025-04-27 15:09:53.466531') ON CONFLICT DO NOTHING;
INSERT INTO sb.users (id, row_id, user_name, user_password, cr_on, up_on) VALUES (1, '1745304026572_qLJa', 'abhishek', '1234', '2025-04-21 23:40:26.632186', '2025-04-27 09:47:53.368') ON CONFLICT DO NOTHING;


--
-- TOC entry 5039 (class 0 OID 0)
-- Dependencies: 217
-- Name: attendance_id_seq; Type: SEQUENCE SET; Schema: sb; Owner: postgres
--

SELECT pg_catalog.setval('sb.attendance_id_seq', 20, true);


--
-- TOC entry 5040 (class 0 OID 0)
-- Dependencies: 219
-- Name: bandals_id_seq; Type: SEQUENCE SET; Schema: sb; Owner: postgres
--

SELECT pg_catalog.setval('sb.bandals_id_seq', 33, true);


--
-- TOC entry 5041 (class 0 OID 0)
-- Dependencies: 221
-- Name: branch_id_seq; Type: SEQUENCE SET; Schema: sb; Owner: postgres
--

SELECT pg_catalog.setval('sb.branch_id_seq', 5, true);


--
-- TOC entry 5042 (class 0 OID 0)
-- Dependencies: 223
-- Name: centers_id_seq; Type: SEQUENCE SET; Schema: sb; Owner: postgres
--

SELECT pg_catalog.setval('sb.centers_id_seq', 11, true);


--
-- TOC entry 5043 (class 0 OID 0)
-- Dependencies: 225
-- Name: classes_id_seq; Type: SEQUENCE SET; Schema: sb; Owner: postgres
--

SELECT pg_catalog.setval('sb.classes_id_seq', 6, true);


--
-- TOC entry 5044 (class 0 OID 0)
-- Dependencies: 227
-- Name: copy_checkers_id_seq; Type: SEQUENCE SET; Schema: sb; Owner: postgres
--

SELECT pg_catalog.setval('sb.copy_checkers_id_seq', 4, true);


--
-- TOC entry 5045 (class 0 OID 0)
-- Dependencies: 229
-- Name: exam_sessions_id_seq; Type: SEQUENCE SET; Schema: sb; Owner: postgres
--

SELECT pg_catalog.setval('sb.exam_sessions_id_seq', 5, true);


--
-- TOC entry 5046 (class 0 OID 0)
-- Dependencies: 231
-- Name: marks_id_seq; Type: SEQUENCE SET; Schema: sb; Owner: postgres
--

SELECT pg_catalog.setval('sb.marks_id_seq', 31, true);


--
-- TOC entry 5047 (class 0 OID 0)
-- Dependencies: 233
-- Name: merit_list_id_seq; Type: SEQUENCE SET; Schema: sb; Owner: postgres
--

SELECT pg_catalog.setval('sb.merit_list_id_seq', 1, false);


--
-- TOC entry 5048 (class 0 OID 0)
-- Dependencies: 235
-- Name: online_forms_id_seq; Type: SEQUENCE SET; Schema: sb; Owner: postgres
--

SELECT pg_catalog.setval('sb.online_forms_id_seq', 1, false);


--
-- TOC entry 5049 (class 0 OID 0)
-- Dependencies: 240
-- Name: samplebook_id_seq; Type: SEQUENCE SET; Schema: sb; Owner: postgres
--

SELECT pg_catalog.setval('sb.samplebook_id_seq', 1, true);


--
-- TOC entry 5050 (class 0 OID 0)
-- Dependencies: 242
-- Name: samplepaper_id_seq; Type: SEQUENCE SET; Schema: sb; Owner: postgres
--

SELECT pg_catalog.setval('sb.samplepaper_id_seq', 1, true);


--
-- TOC entry 5051 (class 0 OID 0)
-- Dependencies: 237
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: sb; Owner: postgres
--

SELECT pg_catalog.setval('sb.students_id_seq', 24, true);


--
-- TOC entry 5052 (class 0 OID 0)
-- Dependencies: 239
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: sb; Owner: postgres
--

SELECT pg_catalog.setval('sb.users_id_seq', 2, true);


--
-- TOC entry 4813 (class 2606 OID 418005)
-- Name: attendance attendance_pkey; Type: CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.attendance
    ADD CONSTRAINT attendance_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4815 (class 2606 OID 418007)
-- Name: bandals bandals_pkey; Type: CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.bandals
    ADD CONSTRAINT bandals_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4817 (class 2606 OID 418009)
-- Name: branch branch_pkey; Type: CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.branch
    ADD CONSTRAINT branch_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4819 (class 2606 OID 418011)
-- Name: centers centers_pkey; Type: CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.centers
    ADD CONSTRAINT centers_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4821 (class 2606 OID 418013)
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4823 (class 2606 OID 418015)
-- Name: copy_checkers copy_checkers_pkey; Type: CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.copy_checkers
    ADD CONSTRAINT copy_checkers_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4825 (class 2606 OID 418017)
-- Name: exam_sessions exam_sessions_pkey; Type: CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.exam_sessions
    ADD CONSTRAINT exam_sessions_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4827 (class 2606 OID 418019)
-- Name: marks marks_pkey; Type: CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.marks
    ADD CONSTRAINT marks_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4829 (class 2606 OID 418021)
-- Name: merit_list merit_list_pkey; Type: CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.merit_list
    ADD CONSTRAINT merit_list_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4831 (class 2606 OID 418023)
-- Name: online_forms online_forms_pkey; Type: CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.online_forms
    ADD CONSTRAINT online_forms_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4837 (class 2606 OID 426281)
-- Name: samplebook samplebook_pkey; Type: CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.samplebook
    ADD CONSTRAINT samplebook_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4839 (class 2606 OID 426294)
-- Name: samplepaper samplepaper_pkey; Type: CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.samplepaper
    ADD CONSTRAINT samplepaper_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4833 (class 2606 OID 418025)
-- Name: students students_pkey; Type: CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4835 (class 2606 OID 418027)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (row_id);


--
-- TOC entry 4840 (class 2606 OID 418028)
-- Name: attendance attendance_student_row_id_fkey; Type: FK CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.attendance
    ADD CONSTRAINT attendance_student_row_id_fkey FOREIGN KEY (student_row_id) REFERENCES sb.students(row_id) ON DELETE CASCADE;


--
-- TOC entry 4841 (class 2606 OID 418033)
-- Name: bandals bandals_copy_checker_id_fkey; Type: FK CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.bandals
    ADD CONSTRAINT bandals_copy_checker_id_fkey FOREIGN KEY (copy_checker_id) REFERENCES sb.copy_checkers(row_id) ON DELETE SET NULL;


--
-- TOC entry 4842 (class 2606 OID 418038)
-- Name: bandals bandals_student_row_id_fkey; Type: FK CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.bandals
    ADD CONSTRAINT bandals_student_row_id_fkey FOREIGN KEY (student_row_id) REFERENCES sb.students(row_id) ON DELETE CASCADE;


--
-- TOC entry 4843 (class 2606 OID 418043)
-- Name: centers centers_branch_id_fkey; Type: FK CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.centers
    ADD CONSTRAINT centers_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES sb.branch(row_id) ON DELETE CASCADE;


--
-- TOC entry 4844 (class 2606 OID 418048)
-- Name: marks marks_copy_checker_id_fkey; Type: FK CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.marks
    ADD CONSTRAINT marks_copy_checker_id_fkey FOREIGN KEY (copy_checker_id) REFERENCES sb.copy_checkers(row_id) ON DELETE SET NULL;


--
-- TOC entry 4845 (class 2606 OID 418053)
-- Name: marks marks_student_row_id_fkey; Type: FK CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.marks
    ADD CONSTRAINT marks_student_row_id_fkey FOREIGN KEY (student_row_id) REFERENCES sb.students(row_id) ON DELETE CASCADE;


--
-- TOC entry 4846 (class 2606 OID 418058)
-- Name: merit_list merit_list_student_row_id_fkey; Type: FK CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.merit_list
    ADD CONSTRAINT merit_list_student_row_id_fkey FOREIGN KEY (student_row_id) REFERENCES sb.students(row_id) ON DELETE CASCADE;


--
-- TOC entry 4847 (class 2606 OID 418063)
-- Name: online_forms online_forms_student_row_id_fkey; Type: FK CONSTRAINT; Schema: sb; Owner: postgres
--

ALTER TABLE ONLY sb.online_forms
    ADD CONSTRAINT online_forms_student_row_id_fkey FOREIGN KEY (student_row_id) REFERENCES sb.students(row_id) ON DELETE CASCADE;


-- Completed on 2025-04-27 17:11:08

--
-- PostgreSQL database dump complete
--

