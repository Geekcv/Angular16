import { Component, OnInit } from '@angular/core';
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service'; // Adjust path
import { UtiltiesService } from 'src/app/services/utilties.service'; // Adjust path

@Component({
  selector: 'app-merit-list',
  templateUrl: './merit-list.component.html',
  styleUrls: ['./merit-list.component.css']
})
export class MeritListComponent implements OnInit {

  // Dropdown options
  examSessions: any[] = [];
  classes: any[] = [];

  // Selected filter values
  selectedFaculty: any = null;
  selectedExamSession: any = null;
  selectedClass: any = null;

  // Data for the report table
  meritListData: any[] = []; // e.g., [{ studentName: '...', fatherHusbandName: '...', ..., position: 1 }, ...]
  submitted: boolean = false; // To track if submit was clicked
    faculty:any[]=[];


  constructor(
    private apiController: ApicontrollerService,
    private utiltiesService: UtiltiesService, // For export
    public jsonlist: JsonListService // For dropdown data
  ) { }

  ngOnInit(): void {
    this.loadInitialData();
    this.fetchClasses(); // Fetch initial classes based on default faculty
  }

  async loadInitialData() {
    // Fetch exam sessions
    this.examSessions = []; // Adapt API call
    // Map data if needed to {name: '...', id: '...'} format for dropdowns
    this.faculty = []

    this.fetchExams();
    this.fetchfaculty();

  }

  async fetchExams(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fetchExameByFaculty(this.selectedFaculty,page, limit);
    if (tempClientDAta != false) {
      this.examSessions = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.examSessions.push(
          {
            name: tempClientDAta[i].session_name, // Changed to 'name' for consistency with HTML
            data: tempClientDAta[i],
            id: tempClientDAta[i].row_id // Changed to 'id' for consistency with HTML
          }
        );
      }
    }
    if (tempClientDAta === false) {
      this.examSessions = []; // Clear existing students
      
    }
  }

  async fetchClasses(page = 1, limit = 500) {
    this.selectedClass = null; // Reset class when faculty changes
    this.classes = [];
    this.meritListData = []; // Clear previous results
    this.submitted = false;
    var tempClientDAta = await this.apiController.fetchClassesByFaculty(this.selectedFaculty, page, limit) || [];
    console.log("temp-->",tempClientDAta,this.selectedFaculty)
     if (tempClientDAta != false) {
      this.classes = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.classes.push({
          title: tempClientDAta[i].class_name,
          data: tempClientDAta[i],
          value: tempClientDAta[i].row_id
        });
      }
    }

    this.fetchExams()

    if (tempClientDAta===false) {
      this.classes = []; // Clear existing students      
    }

    
  }

  async fetchMeritList() {
    this.submitted = true;
    this.meritListData = []; // Clear previous results
    if (!this.selectedFaculty || !this.selectedExamSession || !this.selectedClass) {
      console.error("Please select Faculty, Exam Session, and Class.");
      return;
    }
    console.log('Fetching merit list for:', this.selectedFaculty, this.selectedExamSession, this.selectedClass);

    // Call API to fetch merit list based on filters
    const fetchedData = await this.apiController.fetchMeritListReport(
        this.selectedFaculty,
        this.selectedExamSession,
        this.selectedClass
    ) || []; // Create this API call

    // Assuming API returns data sorted by position/marks
    // Map fetchedData to the structure needed by the table
    this.meritListData = fetchedData.map((item: any) => ({
        studentName: item.student_name,
        fatherHusbandName: item.father_name,
        address: item.address,
        centerCode: item.center_code,
        centerName: item.center,
        className: item.class_name,
        rollNo: item.roll_no,
        marks: item.marks,
        position: item.position, // Assuming API provides position
        id: item.row_id // Or another unique identifier
    }));
    console.log('Fetched merit list:', this.meritListData);
  }

     async fetchfaculty(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchfaculty(page, limit);
    if (tempClientDAta != false) {
    // console.log("exams========",tempClientDAta);
      this.faculty = []; // Clear existing students
      for (var i = 0; i < tempClientDAta.length; i++) {
        // Map fetched data to the structure expected by the table/dialog
        // Ensure 'name' and 'rollNo' properties exist for the template
        this.faculty.push(
          {
            title: tempClientDAta[i].faculty_name, 
            data: tempClientDAta[i], // Keep original data if needed
            value: tempClientDAta[i].row_id
          }
        );
      }
    }
  }

  // --- Helper methods for display ---
  getFacultyName(id: any): string | null {
    const item = this.jsonlist.faculty.find(e => e.value === id);
    return item ? item.title : null;
  }
  getSessionName(id: any): string | null {
    const item = this.examSessions.find(e => e.id === id);
    return item ? item.name : null;
  }

  getClassName(id: any): string | null {
    const item = this.classes.find(c => c.row_id === id);
    return item ? item.class_name : null;
  }
  // --- End Helper methods ---

  exportData() {
    if (this.meritListData && this.meritListData.length > 0) {
      console.log("Exporting data...", this.meritListData);
      this.meritListData.forEach((item: any) => {
        delete item.id;
      });
      this.utiltiesService.exportAsExcelFile(this.meritListData, 'MeritListReport');
    } else {
      console.warn("No data to export.");
    }
  }

  printReport() {
    this.utiltiesService.printReport('report', 'MeritListReport'); // Adjust the ID of the report section
  }

  
}
