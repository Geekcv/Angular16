import { Component, ElementRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormsService } from 'src/app/constants/forms.service';
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from 'src/app/custom-components/form-builder/form-builder.component';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent {
  @ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;
  @ViewChild('student_name') studentNameRef!: ElementRef;

  savedForm: any = {};
  selectedRowId: string | null = null;

  tableData: any[] = [];
  totalRecords: number = 100;
  limit: number = 5;
  noofpage: number = 1;

  searchFields: any = this.formsService.studentTableData.searchFields;
  tableDataHeader: any = this.formsService.studentTableData.tableDataHeader;
  tableTitle: string = this.formsService.studentTableData.title;

  isFormValid: boolean = false;
  studentId: string | null = null;

  constructor(
    public formsService: FormsService,
    private apiController: ApicontrollerService,
    public utiltiesService: UtiltiesService,
    private router: Router,
    private route: ActivatedRoute,
    private jsonList: JsonListService
  ) {}

  async ngOnInit() {
    this.studentId = this.route.snapshot.paramMap.get('id');

    if (this.studentId) {
      await this.loadStudentById(this.studentId);
    } else {
      await this.fetchCount();
      await this.fetchStudents();
      this.initializeFormDefaults();
    }
  }

  initializeFormDefaults() {
    this.savedForm['medium'] = 'hindi';
    this.savedForm['dob'] = new Date();
    this.savedForm['gender'] = 'm';

    setTimeout(() => {
      const mediumOption = this.jsonList.medium.find((m: any) => m.value === 'hindi');
      if (mediumOption && this.formBuilderComponent) {
        this.formBuilderComponent.searchValues['medium'] = mediumOption.title;
      }
    }, 0);
  }

  formatDateDDMMYYYY(dateStr: string): string {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    return `${day}-${month}-${year}`;
  }
  

  async loadStudentById(id: string) {
    const studentData = await this.apiController.fetchStudentById(id);
    console.log("stud", studentData);
    if (!studentData) {
      console.error('Student not found for id:', id);
      this.router.navigate(['/list-students']);
      return;
    }
  
    // Format dob for input type="date"
     // Convert dob string to Date object (for p-calendar)
  if (studentData.dob) {
    studentData.dob = new Date(studentData.dob);
    console.log("dadta",studentData.dob)
  }

  
    this.savedForm = studentData;
    this.selectedRowId = id;
    this.formBuilderComponent.formdata = { ...studentData };
  
    const stateOption = this.jsonList.state.find((s: any) => s.value == studentData.state);
    if (stateOption) {
      this.formBuilderComponent.searchValues['state'] = stateOption.title;
    }
  
    this.formBuilderComponent.updateCityOptions(studentData.state);
  
    const cityOption = this.formBuilderComponent.filteredOptions['city']
      ?.find((c: any) => c.value == studentData.city);
    if (cityOption) {
      this.formBuilderComponent.searchValues['city'] = cityOption.title;
    }
  
    const mediumOption = this.jsonList.medium.find((m: any) => m.value == studentData.medium);
    if (mediumOption) {
      this.formBuilderComponent.searchValues['medium'] = mediumOption.title;
    }
  }
  

  

  async saveQuestion() {
    const data = this.savedForm;

    const mobile = data.mobile_no?.toString().trim() || '';
    const phoneO = data.phone_o?.toString().trim() || '';
    const phoneR = data.phone_r?.toString().trim() || '';
    const ifsc = data.ifsc_code?.toString().trim() || '';

    const isMobileValid = !mobile || /^\d{10}$/.test(mobile);
    const isPhoneOValid = !phoneO || /^\d{10}$/.test(phoneO);
    const isPhoneRValid = !phoneR || /^\d{10}$/.test(phoneR);
    const isIFSCValid = !ifsc || /^[A-Za-z0-9]{11}$/.test(ifsc);

    if (!isMobileValid || !isPhoneOValid || !isPhoneRValid || !isIFSCValid) {
      console.error("Validation failed: Phone numbers must be 10 digits. IFSC must be 11 alphanumeric characters.");
      return;
    }

    await this.apiController.savestudent(data, this.selectedRowId);
    this.resetForm();
    await this.fetchStudents();
    this.initializeFormDefaults();
    this.listStudents();
  }

  onFormValidityChange(isValid: boolean) {
    this.isFormValid = isValid;
  }

  resetForm() {
    this.savedForm = {};
    this.selectedRowId = null;
  }

  async fetchStudents(page = 1, limit = this.limit) {
    const students = await this.apiController.fetchStudents(page, limit);
    if (students) {
      this.tableData = students.map((item: any) => ({
        student_name: item.student_name,
        father_name: item.father_name,
        dob: new Date(item.dob).toLocaleDateString(),
        address: item.address,
        mobile: item.mobile_no,
        data: item,
        rowId: item.row_id,
        zip_code: item.zip_code,
        ahhar_no: item.ahhar_no,
        phone_r: item.phone_r,
        phone_o: item.phone_o,
        medium: item.medium,
        account_no: item.account_no,
        account_name: item.account_name,
        bank_name: item.bank_name,
        roll_no: item.roll_no,
        state: item.state,
        city: item.city,
        ifsc_code: item.ifsc_code,
        education: item.education,
        center_code: item.center_code,
        cr_on: new Date(item.cr_on).toDateString()
      }));
    }
  }

  editClient(row: any) {
    this.router.navigate(['/students', row.rowId]);
  }

  deleteClient(row: any) {
    // Implement deletion logic here
  }

  fetchNextData(pagination: any) {
    this.fetchStudents(pagination.page, pagination.limit);
  }

  async fetchCount() {
    const total = await this.apiController.fetchCount('students');
    if (total !== false) {
      this.totalRecords = total;
      this.noofpage = Math.ceil(this.totalRecords / this.limit);
    }
  }

  listStudents() {
    this.router.navigate(['/list-students']);
  }
}
