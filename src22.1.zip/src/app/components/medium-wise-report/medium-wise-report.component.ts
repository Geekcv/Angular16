import { Component } from '@angular/core';
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-medium-wise-report',
  templateUrl: './medium-wise-report.component.html',
  styleUrls: ['./medium-wise-report.component.css']
})
export class MediumWiseReportComponent {
// Dropdown options
  examSessions: any[] = [];
  classes: any[] = [];
  centers: any[] = [];
  transposedData: any[] = [];
  reportData: any[] = []; 
  selectedAccount: any = 'All'; // Default to 'All'


  // Selected filter values
  selectedFaculty: string = '0'; // Default value
  selectedExamSession: any = null;
  selectedClass: any = null; // Optional filter
  selectedCenter: any = null; // Optional filter
 

  // Data for the report table
  filteredMarksData: any[] = [];
  submitted: boolean = false;

  constructor(
    private apiController: ApicontrollerService,
    private utiltiesService: UtiltiesService,
    public jsonlist: JsonListService // For dropdown data
  ) { }

  ngOnInit(): void {
    this.loadInitialData();
    this.fetchClasses(); // Fetch initial classes based on default faculty
  }

  async loadInitialData() {
    // Fetch exam sessions
    this.examSessions = [];
    // Fetch centers (assuming you want all centers initially)
    this.centers =  [];
    this.fetchExams();
    this.fetchExamCenter();
  }

  async fetchExams(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fechExam(page, limit);
    if (tempClientDAta != false) {
      this.examSessions = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.examSessions.push(
          {
            name: tempClientDAta[i].session_name, // Changed to 'name' for consistency with HTML
            data: tempClientDAta[i],
            id: tempClientDAta[i].row_id // Changed to 'id' for consistency with HTML
          }
        );
      }
    }
  }


  async fetchExamCenter(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fetchExamCenter(page, limit);
    if (tempClientDAta != false) {
      this.centers = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.centers.push(
          {
            name: tempClientDAta[i].center, // Changed to 'name' for consistency with HTML
            data: tempClientDAta[i], // Keep original data if needed (e.g., for code)
            id: tempClientDAta[i].row_id // Changed to 'id' for consistency with HTML
          }
        );
      }
    }
  }


  async fetchClasses() {
    this.selectedClass = null; // Reset class when faculty changes
    this.classes = [];
    this.submitted = false;
    if (this.selectedFaculty) {
      console.log(`Fetching classes for faculty: ${this.selectedFaculty}`);
      // Fetch classes based on selectedFaculty ('Board' or 'Thokra')
      // You might need separate API calls or pass the faculty type
      this.classes = await this.apiController.fetchClassesByFaculty(this.selectedFaculty,1,100) || []; // Adapt/Create this API call
      // Map data if needed
      console.log('Fetched classes:', this.classes);
    }
  }


  async fetchFilteredMarks() {
    this.submitted = true;
    this.filteredMarksData = []; // Clear previous results
    if (!this.selectedExamSession) {
      console.error("Please select Exam Session.");
      return;
    }

    console.log('Fetching filtered marks for:',  this.selectedExamSession,  this.selectedCenter);

    // Call API to fetch filtered marks list
    const fetchedData = await this.apiController.CenterWiseAmountReport(     
        this.selectedExamSession, 
        this.selectedCenter, // Pass null if not selected     
        this.selectedAccount,     
    ) || []; // Create this API call

    console.log("fetchded ----->",fetchedData)
    // Map fetchedData to the structure needed by the table
    this.filteredMarksData = fetchedData.data.map((item: any) => ({
        rollNo: item.roll_no,
        studentname: item.student_name,
        fathername: item.father_name, // Adjust field name based on API     
        address: item.address,
        classname: item.class_name, 
        centerCode: item.center_code, 
        mobile_no:item.mobile_no,     
        marks:item.marks, 
        prize:item.prize, 
        centerheadAcNo:item.center_head_ac_no, 
        centerheadName:item.center_head_name, 
        centerheadifsccode:item.center_head_ifsc_code,  
        marksPercentage:item.marksPercentage,     
        id: item.row_id // Or another unique identifier
    }));
    console.log('fetchedData:', fetchedData);

    for(var i=0;i<fetchedData.marks_wise_count.length;i++){
      this.reportData.push(
        {
          "Marks":fetchedData.marks_wise_count[i]['marks'],
          "Total marks":fetchedData.marks_wise_count[i]['total_marks']
        }
      );
    }
    const keys = Object.keys(this.reportData[0]);
    this.transposedData = keys.map(key => {
      return {
        key,
        values: this.reportData.map(item => item[key])
      };
    });
  }

  // --- Helper methods for display ---
  getSessionName(id: any): string | null {
    const item = this.examSessions.find(e => e.id === id);
    return item ? item.name : null;
  }

  getClassName(id: any): string | null {
    const item = this.classes.find(c => c.id === id);
    return item ? item.name : null;
  }

  getCenterName(id: any): string | null {
    const item = this.centers.find(c => c.id === id);
    return item ? item.name : null;
  }
  // --- End Helper methods ---

  exportData() {
    if (this.filteredMarksData && this.filteredMarksData.length > 0) {
      console.log("Exporting data...", this.filteredMarksData);
      this.filteredMarksData.forEach((item: any) => {
        delete item.id;

      });
      this.utiltiesService.exportAsExcelFile(this.filteredMarksData, 'FilteredMarksReport');
    } else {
      console.warn("No data to export.");
    }
  }

  printReport() {
    this.utiltiesService.printReport('report', 'StudentMarksFilterReport'); // Adjust the ID of the report section
  }
}
